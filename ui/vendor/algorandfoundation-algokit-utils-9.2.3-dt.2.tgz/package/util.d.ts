import { ABIReturnType, ABIType, ABIValue } from 'algosdk';
/**
 * Converts a value which might be a number or a bigint into a number to be used with apis that don't support bigint.
 *
 * Throws an UnsafeConversionError if the conversion would result in an unsafe integer for the Number type
 * @param value
 */
export declare const toNumber: (value: number | bigint) => number;
export declare class UnsafeConversionError extends Error {
}
/**
 * Calculates the amount of funds to add to a wallet to bring it up to the minimum spending balance.
 * @param minSpendingBalance The minimum spending balance for the wallet
 * @param currentSpendingBalance The current spending balance for the wallet
 * @param minFundingIncrement The minimum amount of funds that can be added to the wallet
 * @returns The amount of funds to add to the wallet or null if the wallet is already above the minimum spending balance
 */
export declare const calculateFundAmount: (minSpendingBalance: bigint, currentSpendingBalance: bigint, minFundingIncrement: bigint) => bigint | null;
/**
 * Checks if the current environment is Node.js
 *
 * @returns A boolean indicating whether the current environment is Node.js
 */
export declare const isNode: () => boolean;
/**
 * Returns the given array split into chunks of `batchSize` batches.
 * @param array The array to chunk
 * @param batchSize The size of batches to split the array into
 * @returns A generator that yields the array split into chunks of `batchSize` batches
 */
export declare function chunkArray<T>(array: T[], batchSize: number): Generator<T[], void>;
/**
 * Memoize calls to the given function in an in-memory map.
 * @param fn The function to memoize
 * @returns The memoized function
 */
export declare const memoize: <T = unknown, R = unknown>(fn: (val: T) => R) => (val: T) => R;
export declare const binaryStartsWith: (base: Uint8Array, startsWith: Uint8Array) => boolean;
export declare const defaultJsonValueReplacer: (key: string, value: unknown) => unknown;
export declare const asJson: (value: unknown, replacer?: (key: string, value: unknown) => unknown, space?: string | number) => string;
/** Calculate minimum number of extra program pages required for provided approval and clear state programs */
export declare const calculateExtraProgramPages: (approvalProgram: Uint8Array, clearStateProgram?: Uint8Array) => number;
/** Take a decoded ABI value and convert all byte arrays (including nested ones) from number[] to Uint8Arrays */
export declare function convertAbiByteArrays(value: ABIValue, type: ABIReturnType): ABIValue;
/**
 * Convert bigint values to numbers for uint types with bit size < 53
 */
export declare const convertABIDecodedBigIntToNumber: (value: ABIValue, type: ABIType) => ABIValue;
