const require_runtime = require("./_virtual/_rolldown/runtime.js");
const require_util = require("./util.js");
const require_transaction = require("./transaction/transaction.js");
const require_app_manager = require("./types/app-manager.js");
const require_legacy_bridge = require("./transaction/legacy-bridge.js");
let algosdk = require("algosdk");
algosdk = require_runtime.__toESM(algosdk);
//#region src/app.ts
var ABIMethod = algosdk.default.ABIMethod;
var OnApplicationComplete = algosdk.default.OnApplicationComplete;
/**
* @deprecated Use `algorand.send.appCreate()` / `algorand.createTransaction.appCreate()` / `algorand.send.appCreateMethodCall()`
* / `algorand.createTransaction.appCreateMethodCall()` instead
*
* Creates a smart contract app, returns the details of the created app.
* @param create The parameters to create the app with
* @param algod An algod client
* @returns The details of the created app, or the transaction to create it if `skipSending` and the compilation result
*/
async function createApp(create, algod) {
	const onComplete = getAppOnCompleteAction(create.onCompleteAction);
	if (onComplete === algosdk.default.OnApplicationComplete.ClearStateOC) throw new Error("Cannot create an app with on-complete action of ClearState");
	const result = create.args?.method ? await require_legacy_bridge.legacySendAppTransactionBridge(algod, create.from, create.args, create, {
		sender: require_transaction.getSenderAddress(create.from),
		onComplete,
		approvalProgram: create.approvalProgram,
		clearStateProgram: create.clearStateProgram,
		method: create.args.method instanceof ABIMethod ? create.args.method : new ABIMethod(create.args.method),
		extraProgramPages: create.schema.extraPages,
		schema: create.schema
	}, (c) => c.appCreateMethodCall, (c) => c.appCreateMethodCall) : await require_legacy_bridge.legacySendAppTransactionBridge(algod, create.from, create.args, create, {
		sender: require_transaction.getSenderAddress(create.from),
		onComplete,
		approvalProgram: create.approvalProgram,
		clearStateProgram: create.clearStateProgram,
		extraProgramPages: create.schema.extraPages,
		schema: create.schema
	}, (c) => c.appCreate, (c) => c.appCreate);
	return {
		...result,
		appId: "appId" in result ? Number(result.appId) : 0,
		appAddress: "appAddress" in result ? result.appAddress.toString() : ""
	};
}
/**
* @deprecated Use `algorand.send.appUpdate()` / `algorand.createTransaction.appUpdate()` / `algorand.send.appUpdateMethodCall()`
* / `algorand.createTransaction.appUpdateMethodCall()` instead
*
* Updates a smart contract app.
* @param update The parameters to update the app with
* @param algod An algod client
* @returns The transaction send result and the compilation result
*/
async function updateApp(update, algod) {
	return update.args?.method ? await require_legacy_bridge.legacySendAppTransactionBridge(algod, update.from, update.args, update, {
		appId: BigInt(update.appId),
		sender: require_transaction.getSenderAddress(update.from),
		onComplete: algosdk.default.OnApplicationComplete.UpdateApplicationOC,
		approvalProgram: update.approvalProgram,
		clearStateProgram: update.clearStateProgram,
		method: update.args.method instanceof ABIMethod ? update.args.method : new ABIMethod(update.args.method)
	}, (c) => c.appUpdateMethodCall, (c) => c.appUpdateMethodCall) : await require_legacy_bridge.legacySendAppTransactionBridge(algod, update.from, update.args, update, {
		appId: BigInt(update.appId),
		sender: require_transaction.getSenderAddress(update.from),
		onComplete: algosdk.default.OnApplicationComplete.UpdateApplicationOC,
		approvalProgram: update.approvalProgram,
		clearStateProgram: update.clearStateProgram
	}, (c) => c.appUpdate, (c) => c.appUpdate);
}
/**
* @deprecated Use `algosdk.OnApplicationComplete` directly instead.
*
* Returns a `algosdk.OnApplicationComplete` for the given onCompleteAction.
*
* If given `undefined` will return `OnApplicationComplete.NoOpOC`.
*
* If given an `AppCallType` will convert the string enum to the correct underlying `algosdk.OnApplicationComplete`.
*
* @param onCompletionAction The on completion action
* @returns The `algosdk.OnApplicationComplete`
*/
function getAppOnCompleteAction(onCompletionAction) {
	switch (onCompletionAction) {
		case void 0:
		case "no_op":
		case OnApplicationComplete.NoOpOC: return OnApplicationComplete.NoOpOC;
		case "opt_in":
		case OnApplicationComplete.OptInOC: return OnApplicationComplete.OptInOC;
		case "close_out":
		case OnApplicationComplete.CloseOutOC: return OnApplicationComplete.CloseOutOC;
		case "clear_state":
		case OnApplicationComplete.ClearStateOC: return OnApplicationComplete.ClearStateOC;
		case "update_application":
		case OnApplicationComplete.UpdateApplicationOC: return OnApplicationComplete.UpdateApplicationOC;
		case "delete_application":
		case OnApplicationComplete.DeleteApplicationOC: return OnApplicationComplete.DeleteApplicationOC;
	}
}
/**
* @deprecated Use `algorand.send.appUpdate()` / `algorand.createTransaction.appUpdate()` / `algorand.send.appUpdateMethodCall()`
* / `algorand.createTransaction.appUpdateMethodCall()` instead
*
* Issues a call to a given app.
* @param call The call details.
* @param algod An algod client
* @returns The result of the call
*/
async function callApp(call, algod) {
	const onComplete = getAppOnCompleteAction(call.callType);
	if (onComplete === algosdk.default.OnApplicationComplete.UpdateApplicationOC) throw new Error("Cannot execute an app call with on-complete action of Update");
	if (call.args?.method && onComplete === algosdk.default.OnApplicationComplete.ClearStateOC) throw new Error("Cannot execute an ABI method call with on-complete action of ClearState");
	return call.args?.method ? await require_legacy_bridge.legacySendAppTransactionBridge(algod, call.from, call.args, call, {
		appId: BigInt(call.appId),
		sender: require_transaction.getSenderAddress(call.from),
		onComplete,
		method: call.args.method instanceof ABIMethod ? call.args.method : new ABIMethod(call.args.method)
	}, (c) => c.appCallMethodCall, (c) => c.appCallMethodCall) : await require_legacy_bridge.legacySendAppTransactionBridge(algod, call.from, call.args, call, {
		appId: BigInt(call.appId),
		sender: require_transaction.getSenderAddress(call.from),
		onComplete
	}, (c) => c.appCall, (c) => c.appCall);
}
/**
* @deprecated Use `AppManager.getABIReturn` instead.
*
* Returns any ABI return values for the given app call arguments and transaction confirmation.
* @param args The arguments that were used for the call
* @param confirmation The transaction confirmation from algod
* @returns The return value for the method call
*/
function getABIReturn(args, confirmation) {
	if (!args || !args.method) return;
	const method = "txnCount" in args.method ? args.method : new ABIMethod(args.method);
	return require_app_manager.AppManager.getABIReturn(confirmation, method);
}
/**
* @deprecated Use `algorand.app.getGlobalState` instead.
*
* Returns the current global state values for the given app ID
* @param appId The ID of the app return global state for
* @param algod An algod client instance
* @returns The current global state
*/
async function getAppGlobalState(appId, algod) {
	return await new require_app_manager.AppManager(algod).getGlobalState(BigInt(appId));
}
/**
* @deprecated Use `algorand.app.getLocalState` instead.
*
* Returns the current global state values for the given app ID and account
* @param appId The ID of the app return global state for
* @param account Either the string address of an account or an account object for the account to get local state for the given app
* @param algod An algod client instance
* @returns The current local state for the given (app, account) combination
*/
async function getAppLocalState(appId, account, algod) {
	return new require_app_manager.AppManager(algod).getLocalState(BigInt(appId), require_transaction.getSenderAddress(account));
}
/**
* @deprecated Use `algorand.app.getBoxNames` instead.
* Returns the names of the boxes for the given app.
* @param appId The ID of the app return box names for
* @param algod An algod client instance
* @returns The current box names
*/
async function getAppBoxNames(appId, algod) {
	return new require_app_manager.AppManager(algod).getBoxNames(BigInt(appId));
}
/**
* @deprecated Use `algorand.app.getBoxValue` instead.
* Returns the value of the given box name for the given app.
* @param appId The ID of the app return box names for
* @param boxName The name of the box to return either as a string, binary array or `BoxName`
* @param algod An algod client instance
* @returns The current box value as a byte array
*/
async function getAppBoxValue(appId, boxName, algod) {
	return new require_app_manager.AppManager(algod).getBoxValue(BigInt(appId), typeof boxName !== "string" && "name" in boxName ? boxName.nameRaw : boxName);
}
/**
* @deprecated Use `algorand.app.getBoxValues` instead.
* Returns the value of the given box names for the given app.
* @param appId The ID of the app return box names for
* @param boxNames The names of the boxes to return either as a string, binary array or `BoxName`
* @param algod An algod client instance
* @returns The current box values as a byte array in the same order as the passed in box names
*/
async function getAppBoxValues(appId, boxNames, algod) {
	return new require_app_manager.AppManager(algod).getBoxValues(BigInt(appId), boxNames.map((b) => typeof b !== "string" && "name" in b ? b.nameRaw : b));
}
/**
* @deprecated Use `algorand.app.getBoxValueFromABIType` instead.
* Returns the value of the given box name for the given app decoded based on the given ABI type.
* @param request The parameters for the box value request
* @param algod An algod client instance
* @returns The current box value as an ABI value
*/
async function getAppBoxValueFromABIType(request, algod) {
	return new require_app_manager.AppManager(algod).getBoxValueFromABIType({
		appId: BigInt(request.appId),
		boxName: typeof request.boxName !== "string" && "name" in request.boxName ? request.boxName.nameRaw : request.boxName,
		type: request.type
	});
}
/**
* @deprecated Use `algorand.app.getBoxValuesFromABIType` instead.
* Returns the value of the given box names for the given app decoded based on the given ABI type.
* @param request The parameters for the box value request
* @param algod An algod client instance
* @returns The current box values as an ABI value in the same order as the passed in box names
*/
async function getAppBoxValuesFromABIType(request, algod) {
	return new require_app_manager.AppManager(algod).getBoxValuesFromABIType({
		appId: BigInt(request.appId),
		boxNames: request.boxNames.map((b) => typeof b !== "string" && "name" in b ? b.nameRaw : b),
		type: request.type
	});
}
/**
* @deprecated Use `AppManager.decodeAppState` instead.
*
* Converts an array of global/local state values from the algod api to a more friendly
* generic object keyed by the UTF-8 value of the key.
* @param state A `global-state`, `local-state`, `global-state-deltas` or `local-state-deltas`
* @returns An object keyeed by the UTF-8 representation of the key with various parsings of the values
*/
function decodeAppState(state) {
	return require_app_manager.AppManager.decodeAppState(state.map(({ key, value }) => ({
		key: Buffer.from(key, "utf-8"),
		value
	})));
}
/**
* @deprecated Use `TransactionComposer` methods to construct transactions instead.
*
* Returns the app args ready to load onto an app `Transaction` object
* @param args The app call args
* @returns The args ready to load into a `Transaction`
*/
function getAppArgsForTransaction(args) {
	if (!args) return void 0;
	const encoder = new TextEncoder();
	return {
		accounts: args?.accounts?.map(_getAccountAddress),
		appArgs: args?.appArgs?.map((a) => typeof a === "string" ? encoder.encode(a) : a),
		boxes: args.boxes?.map(getBoxReference),
		foreignApps: args?.apps,
		foreignAssets: args?.assets,
		lease: require_transaction.encodeLease(args?.lease)
	};
}
/**
* @deprecated Use `TransactionComposer` methods to construct transactions instead.
*
* Returns the app args ready to load onto an ABI method call in `AtomicTransactionComposer`
* @param args The ABI app call args
* @param from The transaction signer
* @returns The parameters ready to pass into `addMethodCall` within AtomicTransactionComposer
*/
async function getAppArgsForABICall(args, from) {
	return require_legacy_bridge._getAppArgsForABICall(args, from);
}
/**
* @deprecated Use `AppManager.getBoxReference()` instead.
*
* Returns a `algosdk.BoxReference` given a `BoxIdentifier` or `BoxReference`.
* @param box The box to return a reference for
* @returns The box reference ready to pass into a `Transaction`
*/
function getBoxReference(box) {
	return require_legacy_bridge._getBoxReference(box);
}
function _getAccountAddress(account) {
	return typeof account === "string" ? account : algosdk.default.encodeAddress(account.publicKey);
}
/**
* @deprecated Use `algorand.app.getById` instead.
*
* Gets the current data for the given app from algod.
*
* @param appId The id of the app
* @param algod An algod client
* @returns The data about the app
*/
async function getAppById(appId, algod) {
	return await algod.getApplicationByID(require_util.toNumber(appId)).do();
}
/**
* @deprecated Use `algorand.app.compileTeal` instead.
*
* Compiles the given TEAL using algod and returns the result, including source map.
*
* @param algod An algod client
* @param tealCode The TEAL code
* @returns The information about the compiled file
*/
async function compileTeal(tealCode, algod) {
	return await new require_app_manager.AppManager(algod).compileTeal(tealCode);
}
/**
* @deprecated Use `abiMethod.getSignature()` or `new ABIMethod(abiMethodParams).getSignature()` instead.
*
* Returns the encoded ABI spec for a given ABI Method
* @param method The method to return a signature for
* @returns The encoded ABI method spec e.g. `method_name(uint64,string)string`
*/
const getABIMethodSignature = (method) => {
	return "getSignature" in method ? method.getSignature() : new ABIMethod(method).getSignature();
};
//#endregion
exports.callApp = callApp;
exports.compileTeal = compileTeal;
exports.createApp = createApp;
exports.decodeAppState = decodeAppState;
exports.getABIMethodSignature = getABIMethodSignature;
exports.getABIReturn = getABIReturn;
exports.getAppArgsForABICall = getAppArgsForABICall;
exports.getAppArgsForTransaction = getAppArgsForTransaction;
exports.getAppBoxNames = getAppBoxNames;
exports.getAppBoxValue = getAppBoxValue;
exports.getAppBoxValueFromABIType = getAppBoxValueFromABIType;
exports.getAppBoxValues = getAppBoxValues;
exports.getAppBoxValuesFromABIType = getAppBoxValuesFromABIType;
exports.getAppById = getAppById;
exports.getAppGlobalState = getAppGlobalState;
exports.getAppLocalState = getAppLocalState;
exports.getAppOnCompleteAction = getAppOnCompleteAction;
exports.getBoxReference = getBoxReference;
exports.updateApp = updateApp;

//# sourceMappingURL=app.js.map