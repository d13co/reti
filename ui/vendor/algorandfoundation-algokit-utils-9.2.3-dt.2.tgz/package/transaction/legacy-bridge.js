const require_runtime = require("../_virtual/_rolldown/runtime.js");
const require_transaction = require("./transaction.js");
const require_app_manager = require("../types/app-manager.js");
const require_composer = require("../types/composer.js");
const require_algorand_client_transaction_creator = require("../types/algorand-client-transaction-creator.js");
const require_algorand_client_transaction_sender = require("../types/algorand-client-transaction-sender.js");
const require_asset_manager = require("../types/asset-manager.js");
let algosdk = require("algosdk");
algosdk = require_runtime.__toESM(algosdk);
//#region src/transaction/legacy-bridge.ts
var ABIMethod = algosdk.default.ABIMethod;
/** @deprecated Bridges between legacy `sendTransaction` behaviour and new `AlgorandClient` behaviour. */
async function legacySendTransactionBridge(algod, from, sendParams, params, txn, send, suggestedParams) {
	const appManager = new require_app_manager.AppManager(algod);
	const newGroup = () => new require_composer.TransactionComposer({
		algod,
		getSigner: () => require_transaction.getSenderTransactionSigner(from),
		getSuggestedParams: async () => suggestedParams ? { ...suggestedParams } : await algod.getTransactionParams().do(),
		appManager
	});
	const transactionSender = new require_algorand_client_transaction_sender.AlgorandClientTransactionSender(newGroup, new require_asset_manager.AssetManager(algod, newGroup), appManager);
	const transactionCreator = new require_algorand_client_transaction_creator.AlgorandClientTransactionCreator(newGroup);
	if (sendParams.fee) params.staticFee = sendParams.fee;
	if (sendParams.maxFee) params.maxFee = sendParams.maxFee;
	if (sendParams.atc || sendParams.skipSending) {
		const transaction = await txn(transactionCreator)(params);
		const txns = "transactions" in transaction ? transaction.transactions : [transaction];
		if (sendParams.atc) {
			const baseIndex = sendParams.atc.count();
			txns.map((txn, i) => ({
				txn,
				signer: "signers" in transaction ? transaction.signers.get(i) ?? require_transaction.getSenderTransactionSigner(from) : require_transaction.getSenderTransactionSigner(from)
			})).forEach((t) => sendParams.atc.addTransaction(t));
			if ("transactions" in transaction) transaction.methodCalls.forEach((m, i) => sendParams.atc["methodCalls"].set(i + baseIndex, m));
		}
		return {
			transaction: txns.at(-1),
			transactions: txns
		};
	}
	return { ...await send(transactionSender)({
		...sendParams,
		...params
	}) };
}
/** @deprecated Bridges between legacy `sendTransaction` behaviour for app transactions and new `AlgorandClient` behaviour. */
async function legacySendAppTransactionBridge(algod, from, appArgs, sendParams, params, txn, send, suggestedParams) {
	const encoder = new TextEncoder();
	return await legacySendTransactionBridge(algod, from, sendParams, {
		...params,
		accountReferences: appArgs?.accounts?.map((a) => typeof a === "string" ? a : algosdk.default.encodeAddress(a.publicKey)),
		appReferences: appArgs?.apps?.map((a) => BigInt(a)),
		assetReferences: appArgs?.assets?.map((a) => BigInt(a)),
		boxReferences: appArgs?.boxes?.map(_getBoxReference)?.map((r) => ({
			appId: BigInt(r.appIndex),
			name: r.name
		})),
		lease: appArgs?.lease,
		rekeyTo: appArgs?.rekeyTo ? require_transaction.getSenderAddress(appArgs?.rekeyTo) : void 0,
		args: appArgs ? "methodArgs" in appArgs ? (await _getAppArgsForABICall(appArgs, from)).methodArgs : appArgs?.appArgs?.map((a) => typeof a === "string" ? encoder.encode(a) : a) : void 0,
		note: require_transaction.encodeTransactionNote(sendParams?.note)
	}, txn, send, suggestedParams);
}
/**
* @deprecated
*/
async function _getAppArgsForABICall(args, from) {
	const signer = require_transaction.getSenderTransactionSigner(from);
	const methodArgs = await Promise.all(("methodArgs" in args ? args.methodArgs : args)?.map(async (a, index) => {
		if (a === void 0) throw new Error(`Argument at position ${index} does not have a value`);
		if (typeof a !== "object") return a;
		return "txn" in a ? a : a instanceof Promise ? {
			txn: (await a).transaction,
			signer
		} : "transaction" in a ? {
			txn: a.transaction,
			signer: "signer" in a ? require_transaction.getSenderTransactionSigner(a.signer) : signer
		} : "txID" in a ? {
			txn: a,
			signer
		} : a;
	}));
	return {
		method: "txnCount" in args.method ? args.method : new ABIMethod(args.method),
		sender: require_transaction.getSenderAddress(from),
		signer,
		boxes: args.boxes?.map(_getBoxReference),
		lease: require_transaction.encodeLease(args.lease),
		appForeignApps: args.apps,
		appForeignAssets: args.assets,
		appAccounts: args.accounts?.map(_getAccountAddress),
		methodArgs,
		rekeyTo: args?.rekeyTo ? typeof args.rekeyTo === "string" ? args.rekeyTo : require_transaction.getSenderAddress(args.rekeyTo) : void 0
	};
}
function _getAccountAddress(account) {
	return typeof account === "string" ? account : algosdk.default.encodeAddress(account.publicKey);
}
/** @deprecated */
function _getBoxReference(box) {
	const encoder = new TextEncoder();
	if (typeof box === "object" && "appIndex" in box) return box;
	const ref = typeof box === "object" && "appId" in box ? box : {
		appId: 0,
		name: box
	};
	return {
		appIndex: ref.appId,
		name: typeof ref.name === "string" ? encoder.encode(ref.name) : "length" in ref.name ? ref.name : algosdk.default.decodeAddress(require_transaction.getSenderAddress(ref.name)).publicKey
	};
}
//#endregion
exports._getAppArgsForABICall = _getAppArgsForABICall;
exports._getBoxReference = _getBoxReference;
exports.legacySendAppTransactionBridge = legacySendAppTransactionBridge;
exports.legacySendTransactionBridge = legacySendTransactionBridge;

//# sourceMappingURL=legacy-bridge.js.map