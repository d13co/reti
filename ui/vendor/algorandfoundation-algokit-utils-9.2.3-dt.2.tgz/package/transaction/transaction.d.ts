import algosdk, { ABIReturnType } from 'algosdk';
import { AlgoAmount } from '../types/amount';
import { ABIReturn } from '../types/app';
import { AdditionalAtomicTransactionComposerContext, AtomicTransactionComposerToSend, SendAtomicTransactionComposerResults, SendParams, SendTransactionFrom, SendTransactionParams, SendTransactionResult, TransactionGroupToSend, TransactionNote, TransactionToSign } from '../types/transaction';
import Algodv2 = algosdk.Algodv2;
import AtomicTransactionComposer = algosdk.AtomicTransactionComposer;
import modelsv2 = algosdk.modelsv2;
import SuggestedParams = algosdk.SuggestedParams;
import Transaction = algosdk.Transaction;
import TransactionWithSigner = algosdk.TransactionWithSigner;
export declare const MAX_TRANSACTION_GROUP_SIZE = 16;
export declare const MAX_APP_CALL_FOREIGN_REFERENCES = 8;
export declare const MAX_APP_CALL_ACCOUNT_REFERENCES = 8;
/**
 * @deprecated Convert your data to a `string` or `Uint8Array`, if using ARC-2 use `TransactionComposer.arc2Note`.
 *
 * Encodes a transaction note into a byte array ready to be included in an Algorand transaction.
 *
 * @param note The transaction note
 * @returns the transaction note ready for inclusion in a transaction
 *
 *  Case on the value of `data` this either be:
 *   * `null` | `undefined`: `undefined`
 *   * `string`: The string value
 *   * Uint8Array: passthrough
 *   * Arc2TransactionNote object: ARC-0002 compatible transaction note
 *   * Else: The object/value converted into a JSON string representation
 */
export declare function encodeTransactionNote(note?: TransactionNote): Uint8Array | undefined;
/** Encodes a transaction lease into a 32-byte array ready to be included in an Algorand transaction.
 *
 * @param lease The transaction lease as a string or binary array or null/undefined if there is no lease
 * @returns the transaction lease ready for inclusion in a transaction or `undefined` if there is no lease
 * @throws if the length of the data is > 32 bytes or empty
 * @example algokit.encodeLease('UNIQUE_ID')
 * @example algokit.encodeLease(new Uint8Array([1, 2, 3]))
 */
export declare function encodeLease(lease?: string | Uint8Array): Uint8Array | undefined;
/**
 * @deprecated Use `algorand.client` to interact with accounts, and use `.addr` to get the address
 * and/or move from using `SendTransactionFrom` to `TransactionSignerAccount` and use `.addr` instead.
 *
 * Returns the public address of the given transaction sender.
 * @param sender A transaction sender
 * @returns The public address
 */
export declare const getSenderAddress: (sender: string | SendTransactionFrom) => string;
/**
 * @deprecated Use `AlgorandClient` / `TransactionComposer` to construct transactions instead or
 * construct an `algosdk.TransactionWithSigner` manually instead.
 *
 * Given a transaction in a variety of supported formats, returns a TransactionWithSigner object ready to be passed to an
 * AtomicTransactionComposer's addTransaction method.
 * @param transaction One of: A TransactionWithSigner object (returned as is), a TransactionToSign object (signer is obtained from the
 * signer property), a Transaction object (signer is extracted from the defaultSender parameter), an async SendTransactionResult returned by
 * one of algokit utils' helpers (signer is obtained from the defaultSender parameter)
 * @param defaultSender The default sender to be used to obtain a signer where the object provided to the transaction parameter does not
 * include a signer.
 * @returns A TransactionWithSigner object.
 */
export declare const getTransactionWithSigner: (transaction: TransactionWithSigner | TransactionToSign | Transaction | Promise<SendTransactionResult>, defaultSender?: SendTransactionFrom) => Promise<TransactionWithSigner>;
/**
 * @deprecated Use `TransactionSignerAccount` instead of `SendTransactionFrom` or use
 * `algosdk.makeBasicAccountTransactionSigner` / `algosdk.makeLogicSigAccountTransactionSigner`.
 *
 * Returns a `TransactionSigner` for the given transaction sender.
 * This function has memoization, so will return the same transaction signer for a given sender.
 * @param sender A transaction sender
 * @returns A transaction signer
 */
export declare const getSenderTransactionSigner: (val: SendTransactionFrom) => algosdk.TransactionSigner;
/**
 * @deprecated Use `AlgorandClient` / `TransactionComposer` to sign transactions
 * or use the relevant underlying `account.signTxn` / `algosdk.signLogicSigTransactionObject`
 * / `multiSigAccount.sign` / `TransactionSigner` methods directly.
 *
 * Signs a single transaction by the given signer.
 * @param transaction The transaction to sign
 * @param signer The signer to sign
 * @returns The signed transaction as a `Uint8Array`
 */
export declare const signTransaction: (transaction: Transaction, signer: SendTransactionFrom) => Promise<Uint8Array<ArrayBufferLike>>;
/**
 * @deprecated Use `AlgorandClient` / `TransactionComposer` to send transactions.
 *
 * Prepares a transaction for sending and then (if instructed) signs and sends the given transaction to the chain.
 *
 * @param send The details for the transaction to prepare/send, including:
 *   * `transaction`: The unsigned transaction
 *   * `from`: The account to sign the transaction with: either an account with private key loaded or a logic signature account
 *   * `config`: The sending configuration for this transaction
 * @param algod An algod client
 *
 * @returns An object with transaction (`transaction`) and (if `skipWaiting` is `false` or `undefined`) confirmation (`confirmation`)
 */
export declare const sendTransaction: (send: {
    transaction: Transaction;
    from: SendTransactionFrom;
    sendParams?: SendTransactionParams;
}, algod: Algodv2) => Promise<SendTransactionResult>;
/**
 * Take an existing Atomic Transaction Composer and return a new one with the required
 * app call resources populated into it
 *
 * @param algod The algod client to use for the simulation
 * @param atc The ATC containing the txn group
 * @returns A new ATC with the resources populated into the transactions
 *
 * @privateRemarks
 *
 * This entire function will eventually be implemented in simulate upstream in algod. The simulate endpoint will return
 * an array of reference arrays for each transaction, so this will eventually just call simulate and set the
 * reference arrays in the transactions to the reference arrays returned by simulate.
 *
 * See https://github.com/algorand/go-algorand/pull/5684
 *
 */
export declare function populateAppCallResources(atc: algosdk.AtomicTransactionComposer, algod: algosdk.Algodv2): Promise<algosdk.AtomicTransactionComposer>;
/**
 * Take an existing Atomic Transaction Composer and return a new one with changes applied to the transactions
 * based on the supplied sendParams to prepare it for sending.
 * Please note, that before calling `.execute()` on the returned ATC, you must call `.buildGroup()`.
 *
 * @param algod The algod client to use for the simulation
 * @param atc The ATC containing the txn group
 * @param sendParams The send params for the transaction group
 * @param additionalAtcContext Additional ATC context used to determine how best to change the transactions in the group
 * @returns A new ATC with the changes applied
 *
 * @privateRemarks
 * Parts of this function will eventually be implemented in algod. Namely:
 * - Simulate will return information on how to populate reference arrays, see https://github.com/algorand/go-algorand/pull/6015
 */
export declare function prepareGroupForSending(atc: algosdk.AtomicTransactionComposer, algod: algosdk.Algodv2, sendParams: SendParams, additionalAtcContext?: AdditionalAtomicTransactionComposerContext): Promise<algosdk.AtomicTransactionComposer>;
/**
 * Signs and sends transactions that have been collected by an `AtomicTransactionComposer`.
 * @param atcSend The parameters controlling the send, including `atc` The `AtomicTransactionComposer` and params to control send behaviour
 * @param algod An algod client
 * @returns An object with transaction IDs, transactions, group transaction ID (`groupTransactionId`) if more than 1 transaction sent, and (if `skipWaiting` is `false` or unset) confirmation (`confirmation`)
 */
export declare const sendAtomicTransactionComposer: (atcSend: AtomicTransactionComposerToSend, algod: Algodv2) => Promise<SendAtomicTransactionComposerResults>;
/**
 * Takes an algosdk `ABIResult` and converts it to an `ABIReturn`.
 * Converts `bigint`'s for Uint's < 64 to `number` for easier use.
 * @param result The `ABIReturn`
 */
export declare function getABIReturnValue(result: algosdk.ABIResult, type: ABIReturnType): ABIReturn;
/**
 * @deprecated Use `TransactionComposer` (`algorand.newGroup()`) or `AtomicTransactionComposer` to construct and send group transactions instead.
 *
 * Signs and sends a group of [up to 16](https://dev.algorand.co/concepts/transactions/atomic-txn-groups/#create-transactions) transactions to the chain
 *
 * @param groupSend The group details to send, with:
 *   * `transactions`: The array of transactions to send along with their signing account
 *   * `sendParams`: The parameters to dictate how the group is sent
 * @param algod An algod client
 * @returns An object with transaction IDs, transactions, group transaction ID (`groupTransactionId`) if more than 1 transaction sent, and (if `skipWaiting` is `false` or unset) confirmation (`confirmation`)
 */
export declare const sendGroupOfTransactions: (groupSend: TransactionGroupToSend, algod: Algodv2) => Promise<Omit<SendAtomicTransactionComposerResults, "returns">>;
/**
 * Wait until the transaction is confirmed or rejected, or until `timeout`
 * number of rounds have passed.
 *
 * @param algod An algod client
 * @param transactionId The transaction ID to wait for
 * @param maxRoundsToWait Maximum number of rounds to wait
 *
 * @return Pending transaction information
 * @throws Throws an error if the transaction is not confirmed or rejected in the next `timeout` rounds
 */
export declare const waitForConfirmation: (transactionId: string, maxRoundsToWait: number | bigint, algod: Algodv2) => Promise<modelsv2.PendingTransactionResponse>;
/**
 * @deprecated Use `TransactionComposer` and the `maxFee` field in the transaction params instead.
 *
 * Limit the acceptable fee to a defined amount of µAlgo.
 * This also sets the transaction to be flatFee to ensure the transaction only succeeds at
 * the estimated rate.
 * @param transaction The transaction to cap or suggested params object about to be used to create a transaction
 * @param maxAcceptableFee The maximum acceptable fee to pay
 */
export declare function capTransactionFee(transaction: algosdk.Transaction | SuggestedParams, maxAcceptableFee: AlgoAmount): void;
/**
 * @deprecated Use `TransactionComposer` and the `maxFee` and `staticFee` fields in the transaction params instead.
 *
 * Allows for control of fees on a `Transaction` or `SuggestedParams` object
 * @param transaction The transaction or suggested params
 * @param feeControl The fee control parameters
 */
export declare function controlFees<T extends SuggestedParams | Transaction>(transaction: T, feeControl: {
    fee?: AlgoAmount;
    maxFee?: AlgoAmount;
}): T;
/**
 * @deprecated Use `suggestedParams ? { ...suggestedParams } : await algod.getTransactionParams().do()` instead
 *
 * Returns suggested transaction parameters from algod unless some are already provided.
 * @param params Optionally provide parameters to use
 * @param algod Algod algod
 * @returns The suggested transaction parameters
 */
export declare function getTransactionParams(params: SuggestedParams | undefined, algod: Algodv2): Promise<SuggestedParams>;
/**
 * @deprecated Use `atc.clone().buildGroup()` instead.
 *
 * Returns the array of transactions currently present in the given `AtomicTransactionComposer`
 * @param atc The atomic transaction composer
 * @returns The array of transactions with signers
 */
export declare function getAtomicTransactionComposerTransactions(atc: AtomicTransactionComposer): algosdk.TransactionWithSigner[];
