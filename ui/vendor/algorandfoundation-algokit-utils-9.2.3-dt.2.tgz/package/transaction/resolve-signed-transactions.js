const require_runtime = require("../_virtual/_rolldown/runtime.js");
let algosdk = require("algosdk");
algosdk = require_runtime.__toESM(algosdk);
//#region src/transaction/resolve-signed-transactions.ts
/**
* Resolve the transactions as they were signed.
*
* Signers (e.g. wallets) can mutate the transactions they are given, so the signed transactions are the source of truth
* for what is actually sent to the network. Without this, a mutated transaction would be reported (and waited for)
* under the transaction ID of the transaction that was built, which was never sent.
*
* The built transaction is returned when it wasn't mutated, so callers keep the exact transaction they built.
*
* @param builtTransactions The transactions that were given to the signers
* @param encodedSignedTransactions The signed transactions returned by the signers
* @returns The transactions as they were signed
*/
function resolveSignedTransactions(builtTransactions, encodedSignedTransactions) {
	return encodedSignedTransactions.map((encodedSignedTransaction, index) => {
		const { txn } = algosdk.default.decodeSignedTransaction(encodedSignedTransaction);
		const builtTransaction = builtTransactions[index];
		return builtTransaction !== void 0 && builtTransaction.txID() === txn.txID() ? builtTransaction : txn;
	});
}
//#endregion
exports.resolveSignedTransactions = resolveSignedTransactions;

//# sourceMappingURL=resolve-signed-transactions.js.map