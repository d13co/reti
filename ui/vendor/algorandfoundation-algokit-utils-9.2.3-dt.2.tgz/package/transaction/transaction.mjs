import { Config } from "../config.mjs";
import "../types/lifecycle-events.mjs";
import { asJson, convertABIDecodedBigIntToNumber, convertAbiByteArrays, toNumber } from "../util.mjs";
import { performAtomicTransactionComposerSimulate } from "./perform-atomic-transaction-composer-simulate.mjs";
import { resolveSignedTransactions } from "./resolve-signed-transactions.mjs";
import algosdk, { Address, TransactionType, stringifyJSON } from "algosdk";
import { Buffer } from "buffer";
//#region src/transaction/transaction.ts
var AtomicTransactionComposer = algosdk.AtomicTransactionComposer;
const MAX_TRANSACTION_GROUP_SIZE = 16;
const MAX_APP_CALL_FOREIGN_REFERENCES = 8;
const MAX_APP_CALL_ACCOUNT_REFERENCES = 8;
/**
* @deprecated Convert your data to a `string` or `Uint8Array`, if using ARC-2 use `TransactionComposer.arc2Note`.
*
* Encodes a transaction note into a byte array ready to be included in an Algorand transaction.
*
* @param note The transaction note
* @returns the transaction note ready for inclusion in a transaction
*
*  Case on the value of `data` this either be:
*   * `null` | `undefined`: `undefined`
*   * `string`: The string value
*   * Uint8Array: passthrough
*   * Arc2TransactionNote object: ARC-0002 compatible transaction note
*   * Else: The object/value converted into a JSON string representation
*/
function encodeTransactionNote(note) {
	if (note == null || typeof note === "undefined") return;
	else if (typeof note === "object" && note.constructor === Uint8Array) return note;
	else if (typeof note === "object" && "dAppName" in note) {
		const arc2Payload = `${note.dAppName}:${note.format}${typeof note.data === "string" ? note.data : asJson(note.data)}`;
		return new TextEncoder().encode(arc2Payload);
	} else {
		const n = typeof note === "string" ? note : asJson(note);
		return new TextEncoder().encode(n);
	}
}
/** Encodes a transaction lease into a 32-byte array ready to be included in an Algorand transaction.
*
* @param lease The transaction lease as a string or binary array or null/undefined if there is no lease
* @returns the transaction lease ready for inclusion in a transaction or `undefined` if there is no lease
* @throws if the length of the data is > 32 bytes or empty
* @example algokit.encodeLease('UNIQUE_ID')
* @example algokit.encodeLease(new Uint8Array([1, 2, 3]))
*/
function encodeLease(lease) {
	if (lease === null || typeof lease === "undefined") return;
	else if (typeof lease === "object" && lease.constructor === Uint8Array) {
		if (lease.length === 0 || lease.length > 32) throw new Error(`Received invalid lease; expected something with length between 1 and 32, but received bytes with length ${lease.length}`);
		if (lease.length === 32) return lease;
		const lease32 = /* @__PURE__ */ new Uint8Array(32);
		lease32.set(lease, 0);
		return lease32;
	} else if (typeof lease === "string") {
		if (lease.length === 0 || lease.length > 32) throw new Error(`Received invalid lease; expected something with length between 1 and 32, but received '${lease}' with length ${lease.length}`);
		const encoder = new TextEncoder();
		const lease32 = /* @__PURE__ */ new Uint8Array(32);
		lease32.set(encoder.encode(lease), 0);
		return lease32;
	} else throw new Error(`Unknown lease type received of ${typeof lease}`);
}
/**
* @deprecated Use `algorand.client` to interact with accounts, and use `.addr` to get the address
* and/or move from using `SendTransactionFrom` to `TransactionSignerAccount` and use `.addr` instead.
*
* Returns the public address of the given transaction sender.
* @param sender A transaction sender
* @returns The public address
*/
const getSenderAddress = function(sender) {
	return typeof sender === "string" ? sender : "addr" in sender ? sender.addr.toString() : sender.address().toString();
};
/**
* @deprecated Use `AlgorandClient` / `TransactionComposer` to construct transactions instead or
* construct an `algosdk.TransactionWithSigner` manually instead.
*
* Given a transaction in a variety of supported formats, returns a TransactionWithSigner object ready to be passed to an
* AtomicTransactionComposer's addTransaction method.
* @param transaction One of: A TransactionWithSigner object (returned as is), a TransactionToSign object (signer is obtained from the
* signer property), a Transaction object (signer is extracted from the defaultSender parameter), an async SendTransactionResult returned by
* one of algokit utils' helpers (signer is obtained from the defaultSender parameter)
* @param defaultSender The default sender to be used to obtain a signer where the object provided to the transaction parameter does not
* include a signer.
* @returns A TransactionWithSigner object.
*/
const getTransactionWithSigner = async (transaction, defaultSender) => {
	if ("txn" in transaction) return transaction;
	if (defaultSender === void 0) throw new Error("Default sender must be provided when passing in a transaction object that does not contain its own signer");
	return transaction instanceof Promise ? {
		txn: (await transaction).transaction,
		signer: getSenderTransactionSigner(defaultSender)
	} : "transaction" in transaction ? {
		txn: transaction.transaction,
		signer: getSenderTransactionSigner(transaction.signer)
	} : {
		txn: transaction,
		signer: getSenderTransactionSigner(defaultSender)
	};
};
const memoize = (fn) => {
	const cache = /* @__PURE__ */ new Map();
	const cached = function(val) {
		return cache.has(val) ? cache.get(val) : cache.set(val, fn.call(this, val)) && cache.get(val);
	};
	cached.cache = cache;
	return cached;
};
/**
* @deprecated Use `TransactionSignerAccount` instead of `SendTransactionFrom` or use
* `algosdk.makeBasicAccountTransactionSigner` / `algosdk.makeLogicSigAccountTransactionSigner`.
*
* Returns a `TransactionSigner` for the given transaction sender.
* This function has memoization, so will return the same transaction signer for a given sender.
* @param sender A transaction sender
* @returns A transaction signer
*/
const getSenderTransactionSigner = memoize(function(sender) {
	return "signer" in sender ? sender.signer : "lsig" in sender ? algosdk.makeLogicSigAccountTransactionSigner(sender) : algosdk.makeBasicAccountTransactionSigner(sender);
});
/**
* @deprecated Use `AlgorandClient` / `TransactionComposer` to sign transactions
* or use the relevant underlying `account.signTxn` / `algosdk.signLogicSigTransactionObject`
* / `multiSigAccount.sign` / `TransactionSigner` methods directly.
*
* Signs a single transaction by the given signer.
* @param transaction The transaction to sign
* @param signer The signer to sign
* @returns The signed transaction as a `Uint8Array`
*/
const signTransaction = async (transaction, signer) => {
	return "sk" in signer ? transaction.signTxn(signer.sk) : "lsig" in signer ? algosdk.signLogicSigTransactionObject(transaction, signer).blob : "sign" in signer ? signer.sign(transaction) : (await signer.signer([transaction], [0]))[0];
};
/**
* @deprecated Use `AlgorandClient` / `TransactionComposer` to send transactions.
*
* Prepares a transaction for sending and then (if instructed) signs and sends the given transaction to the chain.
*
* @param send The details for the transaction to prepare/send, including:
*   * `transaction`: The unsigned transaction
*   * `from`: The account to sign the transaction with: either an account with private key loaded or a logic signature account
*   * `config`: The sending configuration for this transaction
* @param algod An algod client
*
* @returns An object with transaction (`transaction`) and (if `skipWaiting` is `false` or `undefined`) confirmation (`confirmation`)
*/
const sendTransaction = async function(send, algod) {
	const { transaction, from, sendParams } = send;
	const { skipSending, skipWaiting, fee, maxFee, suppressLog, maxRoundsToWaitForConfirmation, atc } = sendParams ?? {};
	controlFees(transaction, {
		fee,
		maxFee
	});
	if (atc) {
		atc.addTransaction({
			txn: transaction,
			signer: getSenderTransactionSigner(from)
		});
		return { transaction };
	}
	if (skipSending) return { transaction };
	let txnToSend = transaction;
	const populateAppCallResources = sendParams?.populateAppCallResources ?? Config.populateAppCallResources;
	if (txnToSend.type === algosdk.TransactionType.appl && populateAppCallResources) {
		const newAtc = new AtomicTransactionComposer();
		newAtc.addTransaction({
			txn: txnToSend,
			signer: getSenderTransactionSigner(from)
		});
		txnToSend = (await prepareGroupForSending(newAtc, algod, {
			...sendParams,
			populateAppCallResources
		})).buildGroup()[0].txn;
	}
	const signedTransaction = await signTransaction(txnToSend, from);
	txnToSend = resolveSignedTransactions([txnToSend], [signedTransaction])[0];
	await algod.sendRawTransaction(signedTransaction).do();
	Config.getLogger(suppressLog).verbose(`Sent transaction ID ${txnToSend.txID()} ${txnToSend.type} from ${getSenderAddress(from)}`);
	let confirmation = void 0;
	if (!skipWaiting) confirmation = await waitForConfirmation(txnToSend.txID(), maxRoundsToWaitForConfirmation ?? 5, algod);
	return {
		transaction: txnToSend,
		confirmation
	};
};
/**
* Get the execution info of a transaction group for the given ATC
* The function uses the simulate endpoint and depending on the sendParams can return the following:
* - The unnamed resources accessed by the group
* - The unnamed resources accessed by each transaction in the group
* - The required fee delta for each transaction in the group. A positive value indicates a fee deficit, a negative value indicates a surplus.
*
* @param atc The ATC containing the txn group
* @param algod The algod client to use for the simulation
* @param sendParams The send params for the transaction group
* @param additionalAtcContext Additional ATC context used to determine how best to alter transactions in the group
* @returns The execution info for the group
*/
async function getGroupExecutionInfo(atc, algod, sendParams, additionalAtcContext) {
	const simulateRequest = new algosdk.modelsv2.SimulateRequest({
		txnGroups: [],
		allowUnnamedResources: true,
		allowEmptySignatures: true,
		fixSigners: true
	});
	const nullSigner = algosdk.makeEmptyTransactionSigner();
	const emptySignerAtc = atc.clone();
	const appCallIndexesWithoutMaxFees = [];
	emptySignerAtc["transactions"].forEach((t, i) => {
		t.signer = nullSigner;
		if (sendParams.coverAppCallInnerTransactionFees && t.txn.type === TransactionType.appl) {
			if (!additionalAtcContext?.suggestedParams) throw Error(`Please provide additionalAtcContext.suggestedParams when coverAppCallInnerTransactionFees is enabled`);
			const maxFee = additionalAtcContext?.maxFees?.get(i)?.microAlgo;
			if (maxFee === void 0) appCallIndexesWithoutMaxFees.push(i);
			else t.txn.fee = maxFee;
		}
	});
	if (sendParams.coverAppCallInnerTransactionFees && appCallIndexesWithoutMaxFees.length > 0) throw Error(`Please provide a maxFee for each app call transaction when coverAppCallInnerTransactionFees is enabled. Required for transaction ${appCallIndexesWithoutMaxFees.join(", ")}`);
	const perByteTxnFee = BigInt(additionalAtcContext?.suggestedParams.fee ?? 0n);
	const minTxnFee = BigInt(additionalAtcContext?.suggestedParams.minFee ?? 1000n);
	const groupResponse = (await emptySignerAtc.simulate(algod, simulateRequest)).simulateResponse.txnGroups[0];
	if (groupResponse.failureMessage) {
		if (sendParams.coverAppCallInnerTransactionFees && groupResponse.failureMessage.match(/fee ([\w.]+\s+)?too small/)) throw Error(`Fees were too small to resolve execution info via simulate. You may need to increase an app call transaction maxFee.`);
		throw Error(`Error resolving execution info via simulate in transaction ${groupResponse.failedAt}: ${groupResponse.failureMessage}`);
	}
	const sortedResources = groupResponse.unnamedResourcesAccessed;
	const compare = (a, b) => a < b ? -1 : a > b ? 1 : 0;
	if (sortedResources) {
		sortedResources.accounts?.sort((a, b) => compare(a.toString(), b.toString()));
		sortedResources.assets?.sort(compare);
		sortedResources.apps?.sort(compare);
		sortedResources.boxes?.sort((a, b) => {
			const aStr = `${a.app}-${a.name}`;
			const bStr = `${b.app}-${b.name}`;
			return compare(aStr, bStr);
		});
		sortedResources.appLocals?.sort((a, b) => {
			const aStr = `${a.app}-${a.account}`;
			const bStr = `${b.app}-${b.account}`;
			return compare(aStr, bStr);
		});
		sortedResources.assetHoldings?.sort((a, b) => {
			const aStr = `${a.asset}-${a.account}`;
			const bStr = `${b.asset}-${b.account}`;
			return compare(aStr, bStr);
		});
	}
	return {
		groupUnnamedResourcesAccessed: sendParams.populateAppCallResources ? sortedResources : void 0,
		txns: groupResponse.txnResults.map((txn, i) => {
			const originalTxn = atc["transactions"][i].txn;
			let requiredFeeDelta = 0n;
			if (sendParams.coverAppCallInnerTransactionFees) {
				const parentPerByteFee = perByteTxnFee * BigInt(originalTxn.toByte().length + 75);
				const parentFeeDelta = (parentPerByteFee < minTxnFee ? minTxnFee : parentPerByteFee) - originalTxn.fee;
				if (originalTxn.type === TransactionType.appl) {
					const calculateInnerFeeDelta = (itxns, acc = 0n) => {
						return itxns.reverse().reduce((acc, itxn) => {
							const currentFeeDelta = (itxn.innerTxns && itxn.innerTxns.length > 0 ? calculateInnerFeeDelta(itxn.innerTxns, acc) : acc) + (minTxnFee - itxn.txn.txn.fee);
							return currentFeeDelta < 0n ? 0n : currentFeeDelta;
						}, acc);
					};
					requiredFeeDelta = calculateInnerFeeDelta(txn.txnResult.innerTxns ?? []) + parentFeeDelta;
				} else requiredFeeDelta = parentFeeDelta;
			}
			return {
				unnamedResourcesAccessed: sendParams.populateAppCallResources ? txn.unnamedResourcesAccessed : void 0,
				requiredFeeDelta
			};
		})
	};
}
/**
* Take an existing Atomic Transaction Composer and return a new one with the required
* app call resources populated into it
*
* @param algod The algod client to use for the simulation
* @param atc The ATC containing the txn group
* @returns A new ATC with the resources populated into the transactions
*
* @privateRemarks
*
* This entire function will eventually be implemented in simulate upstream in algod. The simulate endpoint will return
* an array of reference arrays for each transaction, so this will eventually just call simulate and set the
* reference arrays in the transactions to the reference arrays returned by simulate.
*
* See https://github.com/algorand/go-algorand/pull/5684
*
*/
async function populateAppCallResources(atc, algod) {
	return await prepareGroupForSending(atc, algod, { populateAppCallResources: true });
}
/**
* Take an existing Atomic Transaction Composer and return a new one with changes applied to the transactions
* based on the supplied sendParams to prepare it for sending.
* Please note, that before calling `.execute()` on the returned ATC, you must call `.buildGroup()`.
*
* @param algod The algod client to use for the simulation
* @param atc The ATC containing the txn group
* @param sendParams The send params for the transaction group
* @param additionalAtcContext Additional ATC context used to determine how best to change the transactions in the group
* @returns A new ATC with the changes applied
*
* @privateRemarks
* Parts of this function will eventually be implemented in algod. Namely:
* - Simulate will return information on how to populate reference arrays, see https://github.com/algorand/go-algorand/pull/6015
*/
async function prepareGroupForSending(atc, algod, sendParams, additionalAtcContext) {
	const executionInfo = await getGroupExecutionInfo(atc, algod, sendParams, additionalAtcContext);
	const group = atc.buildGroup();
	const [_, additionalTransactionFees] = sendParams.coverAppCallInnerTransactionFees ? executionInfo.txns.map((txn, i) => {
		const groupIndex = i;
		const txnInGroup = group[groupIndex].txn;
		const maxFee = additionalAtcContext?.maxFees?.get(i)?.microAlgo;
		const priorityMultiplier = txn.requiredFeeDelta > 0n && (maxFee !== void 0 && maxFee === txnInGroup.fee || txnInGroup.type !== algosdk.TransactionType.appl) ? 1000n : 1n;
		return {
			...txn,
			groupIndex,
			surplusFeePriorityLevel: txn.requiredFeeDelta > 0n ? txn.requiredFeeDelta * priorityMultiplier : -1n
		};
	}).sort((a, b) => {
		return a.surplusFeePriorityLevel > b.surplusFeePriorityLevel ? -1 : a.surplusFeePriorityLevel < b.surplusFeePriorityLevel ? 1 : 0;
	}).reduce((acc, { groupIndex, requiredFeeDelta }) => {
		if (requiredFeeDelta > 0n) {
			let surplusGroupFees = acc[0];
			const additionalTransactionFees = acc[1];
			const additionalFeeDelta = requiredFeeDelta - surplusGroupFees;
			if (additionalFeeDelta <= 0n) surplusGroupFees = -additionalFeeDelta;
			else {
				additionalTransactionFees.set(groupIndex, additionalFeeDelta);
				surplusGroupFees = 0n;
			}
			return [surplusGroupFees, additionalTransactionFees];
		}
		return acc;
	}, [executionInfo.txns.reduce((acc, { requiredFeeDelta }) => {
		if (requiredFeeDelta < 0n) return acc + -requiredFeeDelta;
		return acc;
	}, 0n), /* @__PURE__ */ new Map()]) : [0n, /* @__PURE__ */ new Map()];
	const appCallHasAccessReferences = (txn) => {
		return txn.type === TransactionType.appl && txn.applicationCall?.access && txn.applicationCall?.access.length > 0;
	};
	const indexesWithAccessReferences = [];
	executionInfo.txns.forEach(({ unnamedResourcesAccessed: r }, i) => {
		if (sendParams.populateAppCallResources && group[i].txn.type === TransactionType.appl) {
			const hasAccessReferences = appCallHasAccessReferences(group[i].txn);
			if (hasAccessReferences && (r || executionInfo.groupUnnamedResourcesAccessed)) indexesWithAccessReferences.push(i);
			if (r && !hasAccessReferences) {
				if (r.boxes || r.extraBoxRefs) throw Error("Unexpected boxes at the transaction level");
				if (r.appLocals) throw Error("Unexpected app local at the transaction level");
				if (r.assetHoldings) throw Error("Unexpected asset holding at the transaction level");
				group[i].txn["applicationCall"] = {
					...group[i].txn.applicationCall,
					accounts: [...group[i].txn?.applicationCall?.accounts ?? [], ...r.accounts ?? []],
					foreignApps: [...group[i].txn?.applicationCall?.foreignApps ?? [], ...r.apps ?? []],
					foreignAssets: [...group[i].txn?.applicationCall?.foreignAssets ?? [], ...r.assets ?? []],
					boxes: [...group[i].txn?.applicationCall?.boxes ?? [], ...r.boxes ?? []]
				};
				const accounts = group[i].txn.applicationCall?.accounts?.length ?? 0;
				if (accounts > 8) throw Error(`Account reference limit of 8 exceeded in transaction ${i}`);
				const assets = group[i].txn.applicationCall?.foreignAssets?.length ?? 0;
				const apps = group[i].txn.applicationCall?.foreignApps?.length ?? 0;
				const boxes = group[i].txn.applicationCall?.boxes?.length ?? 0;
				if (accounts + assets + apps + boxes > 8) throw Error(`Resource reference limit of 8 exceeded in transaction ${i}`);
			}
		}
		if (sendParams.coverAppCallInnerTransactionFees) {
			const additionalTransactionFee = additionalTransactionFees.get(i);
			if (additionalTransactionFee !== void 0) {
				if (group[i].txn.type !== algosdk.TransactionType.appl) throw Error(`An additional fee of ${additionalTransactionFee} µALGO is required for non app call transaction ${i}`);
				const transactionFee = group[i].txn.fee + additionalTransactionFee;
				const maxFee = additionalAtcContext?.maxFees?.get(i)?.microAlgo;
				if (maxFee === void 0 || transactionFee > maxFee) throw Error(`Calculated transaction fee ${transactionFee} µALGO is greater than max of ${maxFee ?? "undefined"} for transaction ${i}`);
				group[i].txn.fee = transactionFee;
			}
		}
	});
	if (sendParams.populateAppCallResources) {
		if (indexesWithAccessReferences.length > 0) Config.logger.warn(`Resource population will be skipped for transaction indexes ${indexesWithAccessReferences.join(", ")} as they use access references.`);
		const populateGroupResource = (txns, reference, type) => {
			const isApplBelowLimit = (t) => {
				if (t.txn.type !== algosdk.TransactionType.appl) return false;
				if (appCallHasAccessReferences(t.txn)) return false;
				const accounts = t.txn.applicationCall?.accounts?.length ?? 0;
				const assets = t.txn.applicationCall?.foreignAssets?.length ?? 0;
				const apps = t.txn.applicationCall?.foreignApps?.length ?? 0;
				const boxes = t.txn.applicationCall?.boxes?.length ?? 0;
				return accounts + assets + apps + boxes < 8;
			};
			if (type === "assetHolding" || type === "appLocal") {
				const { account } = reference;
				let txnIndex = txns.findIndex((t) => {
					if (!isApplBelowLimit(t)) return false;
					return t.txn.applicationCall?.accounts?.map((a) => a.toString()).includes(account.toString()) || t.txn.applicationCall?.foreignApps?.map((a) => algosdk.getApplicationAddress(a).toString()).includes(account.toString()) || Object.values(t.txn).some((f) => stringifyJSON(f, (_, v) => v instanceof Address ? v.toString() : v)?.includes(account.toString()));
				});
				if (txnIndex > -1) {
					if (type === "assetHolding") {
						const { asset } = reference;
						txns[txnIndex].txn["applicationCall"] = {
							...txns[txnIndex].txn.applicationCall,
							foreignAssets: [...txns[txnIndex].txn?.applicationCall?.foreignAssets ?? [], ...[asset]]
						};
					} else {
						const { app } = reference;
						txns[txnIndex].txn["applicationCall"] = {
							...txns[txnIndex].txn.applicationCall,
							foreignApps: [...txns[txnIndex].txn?.applicationCall?.foreignApps ?? [], ...[app]]
						};
					}
					return;
				}
				txnIndex = txns.findIndex((t) => {
					if (!isApplBelowLimit(t)) return false;
					if ((t.txn.applicationCall?.accounts?.length ?? 0) >= 8) return false;
					if (type === "assetHolding") {
						const { asset } = reference;
						return t.txn.applicationCall?.foreignAssets?.includes(asset);
					} else {
						const { app } = reference;
						return t.txn.applicationCall?.foreignApps?.includes(app) || t.txn.applicationCall?.appIndex === app;
					}
				});
				if (txnIndex > -1) {
					const { account } = reference;
					txns[txnIndex].txn["applicationCall"] = {
						...txns[txnIndex].txn.applicationCall,
						accounts: [...txns[txnIndex].txn?.applicationCall?.accounts ?? [], ...[account]]
					};
					return;
				}
			}
			if (type === "box") {
				const { app, name } = reference;
				const txnIndex = txns.findIndex((t) => {
					if (!isApplBelowLimit(t)) return false;
					return t.txn.applicationCall?.foreignApps?.includes(app) || t.txn.applicationCall?.appIndex === app;
				});
				if (txnIndex > -1) {
					txns[txnIndex].txn["applicationCall"] = {
						...txns[txnIndex].txn.applicationCall,
						boxes: [...txns[txnIndex].txn?.applicationCall?.boxes ?? [], ...[{
							appIndex: app,
							name
						}]]
					};
					return;
				}
			}
			const txnIndex = txns.findIndex((t) => {
				if (t.txn.type !== algosdk.TransactionType.appl) return false;
				if (appCallHasAccessReferences(t.txn)) return false;
				const accounts = t.txn.applicationCall?.accounts?.length ?? 0;
				const assets = t.txn.applicationCall?.foreignAssets?.length ?? 0;
				const apps = t.txn.applicationCall?.foreignApps?.length ?? 0;
				const boxes = t.txn.applicationCall?.boxes?.length ?? 0;
				if (type === "account") return accounts < 8 && accounts + assets + apps + boxes < 8;
				if (type === "assetHolding" || type === "appLocal") return accounts + assets + apps + boxes < 7 && accounts < 8;
				if (type === "box" && BigInt(reference.app) !== BigInt(0)) return accounts + assets + apps + boxes < 7;
				return accounts + assets + apps + boxes < 8;
			});
			if (txnIndex === -1) throw Error("No more transactions below reference limit. Add another app call to the group.");
			if (type === "account") txns[txnIndex].txn["applicationCall"] = {
				...txns[txnIndex].txn.applicationCall,
				accounts: [...txns[txnIndex].txn?.applicationCall?.accounts ?? [], ...[reference]]
			};
			else if (type === "app") txns[txnIndex].txn["applicationCall"] = {
				...txns[txnIndex].txn.applicationCall,
				foreignApps: [...txns[txnIndex].txn?.applicationCall?.foreignApps ?? [], ...[typeof reference === "bigint" ? reference : BigInt(reference)]]
			};
			else if (type === "box") {
				const { app, name } = reference;
				txns[txnIndex].txn["applicationCall"] = {
					...txns[txnIndex].txn.applicationCall,
					boxes: [...txns[txnIndex].txn?.applicationCall?.boxes ?? [], ...[{
						appIndex: app,
						name
					}]]
				};
				if (app.toString() !== "0") txns[txnIndex].txn["applicationCall"] = {
					...txns[txnIndex].txn.applicationCall,
					foreignApps: [...txns[txnIndex].txn?.applicationCall?.foreignApps ?? [], ...[app]]
				};
			} else if (type === "assetHolding") {
				const { asset, account } = reference;
				txns[txnIndex].txn["applicationCall"] = {
					...txns[txnIndex].txn.applicationCall,
					foreignAssets: [...txns[txnIndex].txn?.applicationCall?.foreignAssets ?? [], ...[asset]],
					accounts: [...txns[txnIndex].txn?.applicationCall?.accounts ?? [], ...[account]]
				};
			} else if (type === "appLocal") {
				const { app, account } = reference;
				txns[txnIndex].txn["applicationCall"] = {
					...txns[txnIndex].txn.applicationCall,
					foreignApps: [...txns[txnIndex].txn?.applicationCall?.foreignApps ?? [], ...[app]],
					accounts: [...txns[txnIndex].txn?.applicationCall?.accounts ?? [], ...[account]]
				};
			} else if (type === "asset") txns[txnIndex].txn["applicationCall"] = {
				...txns[txnIndex].txn.applicationCall,
				foreignAssets: [...txns[txnIndex].txn?.applicationCall?.foreignAssets ?? [], ...[typeof reference === "bigint" ? reference : BigInt(reference)]]
			};
		};
		const g = executionInfo.groupUnnamedResourcesAccessed;
		if (g) {
			g.appLocals?.forEach((a) => {
				populateGroupResource(group, a, "appLocal");
				g.accounts = g.accounts?.filter((acc) => acc !== a.account);
				g.apps = g.apps?.filter((app) => BigInt(app) !== BigInt(a.app));
			});
			g.assetHoldings?.forEach((a) => {
				populateGroupResource(group, a, "assetHolding");
				g.accounts = g.accounts?.filter((acc) => acc !== a.account);
				g.assets = g.assets?.filter((asset) => BigInt(asset) !== BigInt(a.asset));
			});
			g.accounts?.forEach((a) => {
				populateGroupResource(group, a, "account");
			});
			g.boxes?.forEach((b) => {
				populateGroupResource(group, b, "box");
				g.apps = g.apps?.filter((app) => BigInt(app) !== BigInt(b.app));
			});
			g.assets?.forEach((a) => {
				populateGroupResource(group, a, "asset");
			});
			g.apps?.forEach((a) => {
				populateGroupResource(group, a, "app");
			});
			if (g.extraBoxRefs) for (let i = 0; i < g.extraBoxRefs; i += 1) populateGroupResource(group, new algosdk.modelsv2.BoxReference({
				app: 0,
				name: /* @__PURE__ */ new Uint8Array(0)
			}), "box");
		}
	}
	const newAtc = new algosdk.AtomicTransactionComposer();
	group.forEach((t) => {
		t.txn.group = void 0;
		newAtc.addTransaction(t);
	});
	newAtc["methodCalls"] = atc["methodCalls"];
	return newAtc;
}
/**
* Signs and sends transactions that have been collected by an `AtomicTransactionComposer`.
* @param atcSend The parameters controlling the send, including `atc` The `AtomicTransactionComposer` and params to control send behaviour
* @param algod An algod client
* @returns An object with transaction IDs, transactions, group transaction ID (`groupTransactionId`) if more than 1 transaction sent, and (if `skipWaiting` is `false` or unset) confirmation (`confirmation`)
*/
const sendAtomicTransactionComposer = async function(atcSend, algod) {
	const { atc: givenAtc, sendParams, additionalAtcContext, ...executeParams } = atcSend;
	let atc;
	atc = givenAtc;
	try {
		const transactionsWithSigner = atc.buildGroup();
		const populateAppCallResources = executeParams?.populateAppCallResources ?? sendParams?.populateAppCallResources ?? Config.populateAppCallResources;
		const coverAppCallInnerTransactionFees = executeParams?.coverAppCallInnerTransactionFees;
		if ((populateAppCallResources || coverAppCallInnerTransactionFees) && transactionsWithSigner.map((t) => t.txn.type).includes(algosdk.TransactionType.appl)) atc = await prepareGroupForSending(givenAtc, algod, {
			...executeParams,
			populateAppCallResources,
			coverAppCallInnerTransactionFees
		}, additionalAtcContext);
		const transactionsToSend = atc.buildGroup().map((t) => {
			return t.txn;
		});
		let groupId = void 0;
		if (transactionsToSend.length > 1) {
			groupId = transactionsToSend[0].group ? Buffer.from(transactionsToSend[0].group).toString("base64") : "";
			Config.getLogger(executeParams?.suppressLog ?? sendParams?.suppressLog).verbose(`Sending group of ${transactionsToSend.length} transactions (${groupId})`, { transactionsToSend });
			Config.getLogger(executeParams?.suppressLog ?? sendParams?.suppressLog).debug(`Transaction IDs (${groupId})`, transactionsToSend.map((t) => t.txID()));
		}
		if (Config.debug && Config.traceAll) {
			const simulateResponse = await performAtomicTransactionComposerSimulate(atc, algod);
			await Config.events.emitAsync("TxnGroupSimulated", { simulateResponse });
		}
		const result = await atc.execute(algod, executeParams?.maxRoundsToWaitForConfirmation ?? sendParams?.maxRoundsToWaitForConfirmation ?? 5);
		const sentTransactions = resolveSignedTransactions(transactionsToSend, await atc.gatherSignatures());
		if (sentTransactions.length > 1) {
			groupId = sentTransactions[0].group ? Buffer.from(sentTransactions[0].group).toString("base64") : "";
			Config.getLogger(executeParams?.suppressLog ?? sendParams?.suppressLog).verbose(`Group transaction (${groupId}) sent with ${sentTransactions.length} transactions`);
		} else Config.getLogger(executeParams?.suppressLog ?? sendParams?.suppressLog).verbose(`Sent transaction ID ${sentTransactions[0].txID()} ${sentTransactions[0].type} from ${sentTransactions[0].sender.toString()}`);
		let confirmations = void 0;
		if (!sendParams?.skipWaiting) confirmations = await Promise.all(sentTransactions.map(async (t) => await algod.pendingTransactionInformation(t.txID()).do()));
		const methodCalls = [...atc["methodCalls"].values()];
		return {
			groupId,
			confirmations,
			txIds: sentTransactions.map((t) => t.txID()),
			transactions: sentTransactions,
			returns: result.methodResults.map((r, i) => getABIReturnValue(r, methodCalls[i].returns.type))
		};
	} catch (e) {
		const err = new Error(typeof e === "object" ? e?.message : "Received error executing Atomic Transaction Composer");
		err.cause = e;
		if (typeof e === "object") {
			delete e.response?.headers;
			err.response = e.response;
			if (e.response && "body" in e.response) delete err.response.body;
			err.name = e.name;
		}
		if (Config.debug && typeof e === "object") {
			err.traces = [];
			Config.getLogger(executeParams?.suppressLog ?? sendParams?.suppressLog).error("Received error executing Atomic Transaction Composer and debug flag enabled; attempting simulation to get more information", err);
			const simulate = await performAtomicTransactionComposerSimulate(atc, algod);
			if (Config.debug && !Config.traceAll) await Config.events.emitAsync("TxnGroupSimulated", { simulateResponse: simulate });
			if (simulate && simulate.txnGroups[0].failedAt) for (const txn of simulate.txnGroups[0].txnResults) err.traces.push({
				trace: txn.execTrace?.toEncodingData(),
				appBudget: txn.appBudgetConsumed,
				logicSigBudget: txn.logicSigBudgetConsumed,
				logs: txn.txnResult.logs,
				message: simulate.txnGroups[0].failureMessage
			});
		} else Config.getLogger(executeParams?.suppressLog ?? sendParams?.suppressLog).error("Received error executing Atomic Transaction Composer, for more information enable the debug flag", err);
		let sentTransactions = atc.buildGroup().map((t) => t.txn);
		if (atc.getStatus() >= algosdk.AtomicTransactionComposerStatus.SIGNED) sentTransactions = resolveSignedTransactions(sentTransactions, await atc.gatherSignatures());
		err.sentTransactions = sentTransactions;
		throw err;
	}
};
/**
* Takes an algosdk `ABIResult` and converts it to an `ABIReturn`.
* Converts `bigint`'s for Uint's < 64 to `number` for easier use.
* @param result The `ABIReturn`
*/
function getABIReturnValue(result, type) {
	if (result.decodeError) return { decodeError: result.decodeError };
	const returnValue = convertAbiByteArrays(result.returnValue !== void 0 && result.method.returns.type !== "void" ? convertABIDecodedBigIntToNumber(result.returnValue, result.method.returns.type) : result.returnValue, type);
	return {
		method: result.method,
		rawReturnValue: result.rawReturnValue,
		decodeError: void 0,
		returnValue
	};
}
/**
* @deprecated Use `TransactionComposer` (`algorand.newGroup()`) or `AtomicTransactionComposer` to construct and send group transactions instead.
*
* Signs and sends a group of [up to 16](https://dev.algorand.co/concepts/transactions/atomic-txn-groups/#create-transactions) transactions to the chain
*
* @param groupSend The group details to send, with:
*   * `transactions`: The array of transactions to send along with their signing account
*   * `sendParams`: The parameters to dictate how the group is sent
* @param algod An algod client
* @returns An object with transaction IDs, transactions, group transaction ID (`groupTransactionId`) if more than 1 transaction sent, and (if `skipWaiting` is `false` or unset) confirmation (`confirmation`)
*/
const sendGroupOfTransactions = async function(groupSend, algod) {
	const { transactions, signer, sendParams } = groupSend;
	const defaultTransactionSigner = signer ? getSenderTransactionSigner(signer) : void 0;
	const transactionsWithSigner = await Promise.all(transactions.map(async (t) => {
		if ("signer" in t) return {
			txn: t.transaction,
			signer: getSenderTransactionSigner(t.signer),
			sender: t.signer
		};
		const txn = "then" in t ? (await t).transaction : t;
		if (!signer) throw new Error(`Attempt to send transaction ${txn.txID()} as part of a group transaction, but no signer parameter was provided.`);
		return {
			txn,
			signer: defaultTransactionSigner,
			sender: signer
		};
	}));
	const atc = new AtomicTransactionComposer();
	transactionsWithSigner.forEach((txn) => atc.addTransaction(txn));
	return await sendAtomicTransactionComposer({
		atc,
		sendParams
	}, algod);
};
/**
* Wait until the transaction is confirmed or rejected, or until `timeout`
* number of rounds have passed.
*
* @param algod An algod client
* @param transactionId The transaction ID to wait for
* @param maxRoundsToWait Maximum number of rounds to wait
*
* @return Pending transaction information
* @throws Throws an error if the transaction is not confirmed or rejected in the next `timeout` rounds
*/
const waitForConfirmation = async function(transactionId, maxRoundsToWait, algod) {
	if (maxRoundsToWait < 0) throw new Error(`Invalid timeout, received ${maxRoundsToWait}, expected > 0`);
	const status = await algod.status().do();
	if (status === void 0) throw new Error("Unable to get node status");
	const startRound = BigInt(status.lastRound) + 1n;
	let currentRound = startRound;
	while (currentRound < startRound + BigInt(maxRoundsToWait)) {
		try {
			const pendingInfo = await algod.pendingTransactionInformation(transactionId).do();
			if (pendingInfo !== void 0) {
				const confirmedRound = pendingInfo.confirmedRound;
				if (confirmedRound && confirmedRound > 0) return pendingInfo;
				else {
					const poolError = pendingInfo.poolError;
					if (poolError != null && poolError.length > 0) throw new Error(`Transaction ${transactionId} was rejected; pool error: ${poolError}`);
				}
			}
		} catch (e) {
			if (e.name === "URLTokenBaseHTTPError") {
				currentRound++;
				continue;
			}
		}
		await algod.statusAfterBlock(toNumber(currentRound)).do();
		currentRound++;
	}
	throw new Error(`Transaction ${transactionId} not confirmed after ${maxRoundsToWait} rounds`);
};
/**
* @deprecated Use `TransactionComposer` and the `maxFee` field in the transaction params instead.
*
* Limit the acceptable fee to a defined amount of µAlgo.
* This also sets the transaction to be flatFee to ensure the transaction only succeeds at
* the estimated rate.
* @param transaction The transaction to cap or suggested params object about to be used to create a transaction
* @param maxAcceptableFee The maximum acceptable fee to pay
*/
function capTransactionFee(transaction, maxAcceptableFee) {
	if (!("flatFee" in transaction) || !transaction.flatFee) {
		if (transaction.fee > maxAcceptableFee.microAlgo) throw new Error(`Cancelled transaction due to high network congestion fees. Algorand suggested fees would cause this transaction to cost ${transaction.fee} µALGO. Cap for this transaction is ${maxAcceptableFee.microAlgo} µALGO.`);
		else if (transaction.fee > 1e6) Config.logger.warn(`Algorand network congestion fees are in effect. This transaction will incur a fee of ${transaction.fee} µALGO.`);
		if ("flatFee" in transaction) transaction.flatFee = true;
	}
}
/**
* @deprecated Use `TransactionComposer` and the `maxFee` and `staticFee` fields in the transaction params instead.
*
* Allows for control of fees on a `Transaction` or `SuggestedParams` object
* @param transaction The transaction or suggested params
* @param feeControl The fee control parameters
*/
function controlFees(transaction, feeControl) {
	const { fee, maxFee } = feeControl;
	if (fee) {
		transaction.fee = Number(fee.microAlgo);
		if ("flatFee" in transaction) transaction.flatFee = true;
	}
	if (maxFee !== void 0) capTransactionFee(transaction, maxFee);
	return transaction;
}
/**
* @deprecated Use `suggestedParams ? { ...suggestedParams } : await algod.getTransactionParams().do()` instead
*
* Returns suggested transaction parameters from algod unless some are already provided.
* @param params Optionally provide parameters to use
* @param algod Algod algod
* @returns The suggested transaction parameters
*/
async function getTransactionParams(params, algod) {
	if (params) return { ...params };
	const p = await algod.getTransactionParams().do();
	return {
		fee: p.fee,
		firstValid: p.firstValid,
		lastValid: p.lastValid,
		genesisID: p.genesisID,
		genesisHash: p.genesisHash,
		minFee: p.minFee
	};
}
/**
* @deprecated Use `atc.clone().buildGroup()` instead.
*
* Returns the array of transactions currently present in the given `AtomicTransactionComposer`
* @param atc The atomic transaction composer
* @returns The array of transactions with signers
*/
function getAtomicTransactionComposerTransactions(atc) {
	try {
		return atc.clone().buildGroup();
	} catch {
		return [];
	}
}
//#endregion
export { MAX_APP_CALL_ACCOUNT_REFERENCES, MAX_APP_CALL_FOREIGN_REFERENCES, MAX_TRANSACTION_GROUP_SIZE, capTransactionFee, controlFees, encodeLease, encodeTransactionNote, getABIReturnValue, getAtomicTransactionComposerTransactions, getSenderAddress, getSenderTransactionSigner, getTransactionParams, getTransactionWithSigner, populateAppCallResources, prepareGroupForSending, sendAtomicTransactionComposer, sendGroupOfTransactions, sendTransaction, signTransaction, waitForConfirmation };

//# sourceMappingURL=transaction.mjs.map