import { UpdatableConfig } from "./types/config.mjs";
//#region src/config.ts
/** The AlgoKit config. To update it use the configure method. */
const Config = new UpdatableConfig();
//#endregion
export { Config };

//# sourceMappingURL=config.mjs.map