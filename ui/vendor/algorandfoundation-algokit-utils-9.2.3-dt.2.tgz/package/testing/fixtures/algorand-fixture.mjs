import { Config } from "../../config.mjs";
import { ClientManager } from "../../types/client-manager.mjs";
import { AlgorandClient } from "../../types/algorand-client.mjs";
import { algos } from "../../amount.mjs";
import { getTestAccount } from "../account.mjs";
import { runWhenIndexerCaughtUp } from "../indexer.mjs";
import { TransactionLogger } from "../transaction-logger.mjs";
//#region src/testing/fixtures/algorand-fixture.ts
function algorandFixture(fixtureConfig, config) {
	fixtureConfig = {
		...fixtureConfig,
		...config
	};
	if (!fixtureConfig.algod || !fixtureConfig.indexer || !fixtureConfig.kmd) fixtureConfig = {
		...ClientManager.getConfigFromEnvironmentOrLocalNet(),
		...fixtureConfig
	};
	const algod = fixtureConfig.algod ?? ClientManager.getAlgodClient(fixtureConfig.algodConfig);
	const indexer = fixtureConfig.indexer ?? ClientManager.getIndexerClient(fixtureConfig.indexerConfig);
	const kmd = fixtureConfig.kmd ?? ClientManager.getKmdClient(fixtureConfig.kmdConfig);
	let context;
	let algorand;
	const newScope = async () => {
		Config.configure({ debug: true });
		const transactionLogger = new TransactionLogger();
		const transactionLoggerAlgod = transactionLogger.capture(algod);
		algorand = AlgorandClient.fromClients({
			algod: transactionLoggerAlgod,
			indexer,
			kmd
		}).setSuggestedParamsCacheTimeout(0);
		const testAccount = await getTestAccount({
			initialFunds: fixtureConfig?.testAccountFunding ?? algos(10),
			suppressLog: true
		}, algorand);
		algorand.setSignerFromAccount(testAccount);
		if (await algorand.client.isLocalNet()) algorand.setDefaultValidityWindow(1e3);
		context = {
			algorand,
			algod: transactionLoggerAlgod,
			indexer,
			kmd,
			testAccount,
			generateAccount: async (params) => {
				const account = await getTestAccount(params, algorand);
				algorand.setSignerFromAccount(account);
				return account;
			},
			transactionLogger,
			waitForIndexer: () => transactionLogger.waitForIndexer(indexer),
			waitForIndexerTransaction: (transactionId) => runWhenIndexerCaughtUp(() => indexer.lookupTransactionByID(transactionId).do())
		};
	};
	return {
		get context() {
			if (!context) throw new Error("Context not initialised; make sure to call fixture.newScope() before accessing context.");
			return context;
		},
		get algorand() {
			return algorand;
		},
		beforeEach: newScope,
		newScope
	};
}
//#endregion
export { algorandFixture };

//# sourceMappingURL=algorand-fixture.mjs.map