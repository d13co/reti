const require_config = require("../../config.js");
const require_client_manager = require("../../types/client-manager.js");
const require_algorand_client = require("../../types/algorand-client.js");
const require_amount = require("../../amount.js");
const require_account = require("../account.js");
const require_indexer = require("../indexer.js");
const require_transaction_logger = require("../transaction-logger.js");
//#region src/testing/fixtures/algorand-fixture.ts
function algorandFixture(fixtureConfig, config) {
	fixtureConfig = {
		...fixtureConfig,
		...config
	};
	if (!fixtureConfig.algod || !fixtureConfig.indexer || !fixtureConfig.kmd) fixtureConfig = {
		...require_client_manager.ClientManager.getConfigFromEnvironmentOrLocalNet(),
		...fixtureConfig
	};
	const algod = fixtureConfig.algod ?? require_client_manager.ClientManager.getAlgodClient(fixtureConfig.algodConfig);
	const indexer = fixtureConfig.indexer ?? require_client_manager.ClientManager.getIndexerClient(fixtureConfig.indexerConfig);
	const kmd = fixtureConfig.kmd ?? require_client_manager.ClientManager.getKmdClient(fixtureConfig.kmdConfig);
	let context;
	let algorand;
	const newScope = async () => {
		require_config.Config.configure({ debug: true });
		const transactionLogger = new require_transaction_logger.TransactionLogger();
		const transactionLoggerAlgod = transactionLogger.capture(algod);
		algorand = require_algorand_client.AlgorandClient.fromClients({
			algod: transactionLoggerAlgod,
			indexer,
			kmd
		}).setSuggestedParamsCacheTimeout(0);
		const testAccount = await require_account.getTestAccount({
			initialFunds: fixtureConfig?.testAccountFunding ?? require_amount.algos(10),
			suppressLog: true
		}, algorand);
		algorand.setSignerFromAccount(testAccount);
		if (await algorand.client.isLocalNet()) algorand.setDefaultValidityWindow(1e3);
		context = {
			algorand,
			algod: transactionLoggerAlgod,
			indexer,
			kmd,
			testAccount,
			generateAccount: async (params) => {
				const account = await require_account.getTestAccount(params, algorand);
				algorand.setSignerFromAccount(account);
				return account;
			},
			transactionLogger,
			waitForIndexer: () => transactionLogger.waitForIndexer(indexer),
			waitForIndexerTransaction: (transactionId) => require_indexer.runWhenIndexerCaughtUp(() => indexer.lookupTransactionByID(transactionId).do())
		};
	};
	return {
		get context() {
			if (!context) throw new Error("Context not initialised; make sure to call fixture.newScope() before accessing context.");
			return context;
		},
		get algorand() {
			return algorand;
		},
		beforeEach: newScope,
		newScope
	};
}
//#endregion
exports.algorandFixture = algorandFixture;

//# sourceMappingURL=algorand-fixture.js.map