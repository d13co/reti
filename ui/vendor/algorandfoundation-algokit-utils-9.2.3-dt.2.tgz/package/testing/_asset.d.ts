import { Address } from 'algosdk';
import { AlgorandClient } from '../types/algorand-client';
export declare function generateTestAsset(algorand: AlgorandClient, sender: Address | string, total?: number): Promise<bigint>;
