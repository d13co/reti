const require_runtime = require("../_virtual/_rolldown/runtime.js");
const require_config = require("../config.js");
const require_algorand_client = require("../types/algorand-client.js");
let algosdk = require("algosdk");
algosdk = require_runtime.__toESM(algosdk);
//#region src/testing/account.ts
async function getTestAccount({ suppressLog, initialFunds, accountGetter }, algodOrAlgorandClient, kmd) {
	const algorand = algodOrAlgorandClient instanceof require_algorand_client.AlgorandClient ? algodOrAlgorandClient : require_algorand_client.AlgorandClient.fromClients({
		algod: algodOrAlgorandClient,
		kmd
	});
	const account = accountGetter ? await accountGetter(algorand) : algosdk.default.generateAccount();
	require_config.Config.getLogger(suppressLog).info(`New test account created with address '${account.addr}' and mnemonic '${algosdk.default.secretKeyToMnemonic(account.sk)}'.`);
	const dispenser = await algorand.account.dispenserFromEnvironment();
	await algorand.send.payment({
		sender: dispenser,
		receiver: account.addr,
		amount: initialFunds,
		note: "Funding test account",
		suppressLog
	});
	const accountInfo = await algorand.account.getInformation(account.addr);
	require_config.Config.getLogger(suppressLog).info("Test account funded; account balance: %d µALGO", accountInfo.balance.microAlgo);
	algorand.setSignerFromAccount(account);
	const address = algosdk.Address.fromString(account.addr.toString());
	address.addr = account.addr;
	address.sk = account.sk;
	address.signer = algorand.account.getSigner(address);
	return address;
}
//#endregion
exports.getTestAccount = getTestAccount;

//# sourceMappingURL=account.js.map