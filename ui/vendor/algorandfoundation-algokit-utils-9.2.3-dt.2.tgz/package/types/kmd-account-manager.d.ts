import algosdk, { Address } from 'algosdk';
import { SigningAccount, TransactionSignerAccount } from './account';
import { AlgoAmount } from './amount';
import { ClientManager } from './client-manager';
/** Provides abstractions over a [KMD](https://github.com/algorand/go-algorand/blob/master/daemon/kmd/README.md) instance
 * that makes it easier to get and manage accounts using KMD. */
export declare class KmdAccountManager {
    private _clientManager;
    private _kmd?;
    /**
     * Create a new KMD manager.
     * @param clientManager A ClientManager client to use for algod and kmd clients
     */
    constructor(clientManager: ClientManager);
    kmd(): Promise<algosdk.Kmd>;
    /**
     * Returns an Algorand signing account with private key loaded from the given KMD wallet (identified by name).
     *
     * @param walletName The name of the wallet to retrieve an account from
     * @param predicate An optional filter to use to find the account (otherwise it will return a random account from the wallet)
     * @param sender The optional sender address to use this signer for (aka a rekeyed account)
     * @example Get default funded account in a LocalNet
     *
     * ```typescript
     * const defaultDispenserAccount = await kmdAccountManager.getWalletAccount(
     *   'unencrypted-default-wallet',
     *   a => a.status !== 'Offline' && a.amount > 1_000_000_000
     * )
     * ```
     * @returns The signing account (with private key loaded) or undefined if no matching wallet or account was found
     */
    getWalletAccount(walletName: string, predicate?: (account: Record<string, any>) => boolean, sender?: string | Address): Promise<(TransactionSignerAccount & {
        account: SigningAccount;
    }) | undefined>;
    private findWalletAccount;
    /**
     * Gets an account with private key loaded from a KMD wallet of the given name, or alternatively creates one with funds in it via a KMD wallet of the given name.
     *
     * This is useful to get idempotent accounts from LocalNet without having to specify the private key (which will change when resetting the LocalNet).
     *
     * This significantly speeds up local dev time and improves experience since you can write code that *just works* first go without manual config in a fresh LocalNet.
     *
     * If this is used via `mnemonicAccountFromEnvironment`, then you can even use the same code that runs on production without changes for local development!
     *
     * @param name The name of the wallet to retrieve / create
     * @param fundWith The number of Algo to fund the account with when it gets created, if not specified then 1000 ALGO will be funded from the dispenser account
     *
     * @example
     * ```typescript
     * // Idempotently get (if exists) or create (if it doesn't exist yet) an account by name using KMD
     * // if creating it then fund it with 2 ALGO from the default dispenser account
     * const newAccount = await kmdAccountManager.getOrCreateWalletAccount('account1', (2).algo())
     * // This will return the same account as above since the name matches
     * const existingAccount = await kmdAccountManager.getOrCreateWalletAccount('account1')
     * ```
     *
     * @returns An Algorand account with private key loaded - either one that already existed in the given KMD wallet, or a new one that is funded for you
     */
    getOrCreateWalletAccount(name: string, fundWith?: AlgoAmount): Promise<TransactionSignerAccount & {
        account: SigningAccount;
    }>;
    /**
     * Returns an Algorand account with private key loaded for the default LocalNet dispenser account (that can be used to fund other accounts).
     * @example
     * ```typescript
     * const dispenser = await kmdAccountManager.getLocalNetDispenserAccount()
     * ```
     * @returns The default LocalNet dispenser account
     */
    getLocalNetDispenserAccount(): Promise<TransactionSignerAccount & {
        account: SigningAccount;
    }>;
}
