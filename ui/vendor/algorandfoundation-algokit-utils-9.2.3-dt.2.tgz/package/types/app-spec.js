Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_runtime = require("../_virtual/_rolldown/runtime.js");
let algosdk = require("algosdk");
algosdk = require_runtime.__toESM(algosdk);
//#region src/types/app-spec.ts
var ABIMethod = algosdk.default.ABIMethod;
/**
* Converts an ARC-32 Application Specification to an ARC-56 Contract
* @param appSpec The ARC-32 Application Specification
* @returns The ARC-56 Contract
* @example
* ```typescript
* const arc56AppSpec = arc32ToArc56(arc32AppSpec)
* ```
*/
function arc32ToArc56(appSpec) {
	const arc32Structs = Object.values(appSpec.hints).flatMap((hint) => Object.entries(hint.structs ?? {}));
	const structs = Object.fromEntries(arc32Structs.map(([_, struct]) => {
		const fields = struct.elements.map((e) => ({
			name: e[0],
			type: e[1]
		}));
		return [struct.name, fields];
	}));
	const hint = (m) => appSpec.hints[new ABIMethod(m).getSignature()];
	const actions = (m, type) => {
		return hint(m)?.call_config !== void 0 ? callConfigToActions(hint(m)?.call_config, type) : [];
	};
	const bareActions = (type) => {
		return callConfigToActions(appSpec.bare_call_config, type);
	};
	const callConfigToActions = (c, type) => {
		const actions = [];
		if (c.close_out && ["ALL", type].includes(c.close_out)) actions.push("CloseOut");
		if (c.delete_application && ["ALL", type].includes(c.delete_application)) actions.push("DeleteApplication");
		if (c.no_op && ["ALL", type].includes(c.no_op)) actions.push("NoOp");
		if (c.opt_in && ["ALL", type].includes(c.opt_in)) actions.push("OptIn");
		if (c.update_application && ["ALL", type].includes(c.update_application)) actions.push("UpdateApplication");
		return actions;
	};
	const getDefaultArgValue = (type, defaultArg) => {
		if (!defaultArg) return void 0;
		if (defaultArg.source === "abi-method") return {
			source: "method",
			data: defaultArg.data.name
		};
		return {
			source: defaultArg.source === "constant" ? "literal" : defaultArg.source === "global-state" ? "global" : "local",
			data: Buffer.from(typeof defaultArg.data === "number" ? algosdk.default.ABIType.from("uint64").encode(defaultArg.data) : defaultArg.data).toString("base64"),
			type: type === "string" ? "AVMString" : type
		};
	};
	return {
		arcs: [],
		name: appSpec.contract.name,
		desc: appSpec.contract.desc,
		structs,
		methods: appSpec.contract.methods.map((m) => ({
			name: m.name,
			desc: m.desc,
			args: m.args.map((a) => ({
				name: a.name,
				type: a.type,
				desc: a.desc,
				struct: a.name ? hint(m)?.structs?.[a.name]?.name : void 0,
				defaultValue: getDefaultArgValue(a.type, !a.name ? void 0 : hint(m)?.default_arguments?.[a.name])
			})),
			returns: {
				type: m.returns.type,
				desc: m.returns.desc,
				struct: hint(m)?.structs?.output?.name
			},
			events: [],
			readonly: hint(m)?.read_only,
			actions: {
				create: actions(m, "CREATE"),
				call: actions(m, "CALL")
			}
		})),
		state: {
			schema: {
				global: {
					ints: appSpec.state.global.num_uints,
					bytes: appSpec.state.global.num_byte_slices
				},
				local: {
					ints: appSpec.state.local.num_uints,
					bytes: appSpec.state.local.num_byte_slices
				}
			},
			keys: {
				global: Object.fromEntries(Object.entries(appSpec.schema.global.declared).map((s) => [s[0], {
					key: Buffer.from(s[1].key, "utf-8").toString("base64"),
					keyType: "AVMString",
					valueType: s[1].type === "uint64" ? "AVMUint64" : "AVMBytes",
					desc: s[1].descr
				}])),
				local: Object.fromEntries(Object.entries(appSpec.schema.local.declared).map((s) => [s[0], {
					key: Buffer.from(s[1].key, "utf-8").toString("base64"),
					keyType: "AVMString",
					valueType: s[1].type === "uint64" ? "AVMUint64" : "AVMBytes",
					desc: s[1].descr
				}])),
				box: {}
			},
			maps: {
				global: {},
				local: {},
				box: {}
			}
		},
		source: appSpec.source,
		bareActions: {
			create: bareActions("CREATE"),
			call: bareActions("CALL")
		},
		byteCode: void 0,
		compilerInfo: void 0,
		events: void 0,
		networks: void 0,
		scratchVariables: void 0,
		sourceInfo: void 0,
		templateVariables: void 0
	};
}
//#endregion
exports.arc32ToArc56 = arc32ToArc56;

//# sourceMappingURL=app-spec.js.map