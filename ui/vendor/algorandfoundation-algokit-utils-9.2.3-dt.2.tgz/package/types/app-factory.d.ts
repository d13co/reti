import algosdk, { Address } from 'algosdk';
import { TransactionSignerAccount } from './account';
import { type AlgorandClient } from './algorand-client';
import { AppReturn, SendAppTransactionResult, TealTemplateParams } from './app';
import { ABIStruct, Arc56Contract, Arc56Method } from './app-arc56';
import { AppClient, AppClientBareCallParams, AppClientCompilationParams, AppClientMethodCallParams, AppClientParams, AppSourceMaps, ResolveAppClientByCreatorAndName } from './app-client';
import { AppDeployParams } from './app-deployer';
import { AppSpec } from './app-spec';
import { AppMethodCall, AppMethodCallTransactionArgument } from './composer';
import { Expand } from './expand';
import { SendParams } from './transaction';
import OnApplicationComplete = algosdk.OnApplicationComplete;
import ABIValue = algosdk.ABIValue;
import TransactionSigner = algosdk.TransactionSigner;
/** Parameters to create an app client */
export interface AppFactoryParams {
    /** The ARC-56 or ARC-32 application spec as either:
     *  * Parsed JSON ARC-56 `Contract`
     *  * Parsed JSON ARC-32 `AppSpec`
     *  * Raw JSON string (in either ARC-56 or ARC-32 format)
     */
    appSpec: Arc56Contract | AppSpec | string;
    /** `AlgorandClient` instance */
    algorand: AlgorandClient;
    /**
     * Optional override for the app name; used for on-chain metadata and lookups.
     * Defaults to the ARC-32/ARC-56 app spec name.
     */
    appName?: string;
    /** Optional address to use for the account to use as the default sender for calls. */
    defaultSender?: Address | string;
    /** Optional signer to use as the default signer for default sender calls (if not specified then the signer will be resolved from `AlgorandClient`). */
    defaultSigner?: TransactionSigner;
    /** The version of app that is / will be deployed; defaults to 1.0 */
    version?: string;
    /**
     * Whether or not the contract should have deploy-time immutability control set, undefined = ignore.
     * If specified here will get used in calls to `deploy` and `create` calls unless overridden in those calls.
     *
     * Useful if you want to vend multiple contracts from the same factory without specifying this value
     * for each call.
     */
    updatable?: boolean;
    /**
     * Whether or not the contract should have deploy-time permanence control set, undefined = ignore.
     * If specified here will get used in calls to `deploy` and `create` calls unless overridden in those calls.
     *
     * Useful if you want to vend multiple contracts from the same factory without specifying this value
     * for each call.
     */
    deletable?: boolean;
    /**
     * Optional deploy-time TEAL template replacement parameters.
     * If specified here will get used in calls to `deploy` and `create` calls unless overridden in those calls.
     *
     * Useful if you want to vend multiple contracts from the same factory without specifying this value
     * for each call.
     */
    deployTimeParams?: TealTemplateParams;
}
/** onComplete parameter for a create app call */
export type CreateOnComplete = {
    onComplete?: Exclude<OnApplicationComplete, OnApplicationComplete.ClearStateOC>;
};
/** Specifies a schema used for creating an app */
export type CreateSchema = {
    /** The state schema for the app. This is immutable once the app is created. By default uses the ARC32/ARC-56 spec. */
    schema?: {
        /** The number of integers saved in global state. */
        globalInts: number;
        /** The number of byte slices saved in global state. */
        globalByteSlices: number;
        /** The number of integers saved in local state. */
        localInts: number;
        /** The number of byte slices saved in local state. */
        localByteSlices: number;
    };
    /** Number of extra pages required for the programs.
     * Defaults to the number needed for the programs in this call if not specified.
     * This is immutable once the app is created. */
    extraProgramPages?: number;
};
/** Params to specify a bare (raw) create call for an app */
export type AppFactoryCreateParams = Expand<AppClientBareCallParams & AppClientCompilationParams & CreateOnComplete & CreateSchema>;
/** Params to specify a create method call for an app */
export type AppFactoryCreateMethodCallParams = Expand<AppClientMethodCallParams & AppClientCompilationParams & CreateOnComplete & CreateSchema>;
/** Params to get an app client by ID from an app factory. */
export type AppFactoryAppClientParams = Expand<Omit<AppClientParams, 'algorand' | 'appSpec'>>;
/** Params to get an app client by creator address and name from an app factory. */
export type AppFactoryResolveAppClientByCreatorAndNameParams = Expand<Omit<ResolveAppClientByCreatorAndName, 'algorand' | 'appSpec'>>;
/** Parameters to define a deployment for an `AppFactory` */
export type AppFactoryDeployParams = Expand<Omit<AppDeployParams, 'createParams' | 'updateParams' | 'deleteParams' | 'metadata'> & {
    /** Create transaction parameters to use if a create needs to be issued as part of deployment */
    createParams?: Expand<AppClientMethodCallParams & CreateOnComplete & CreateSchema> | Expand<AppClientBareCallParams & CreateOnComplete & CreateSchema>;
    /** Update transaction parameters to use if a create needs to be issued as part of deployment */
    updateParams?: AppClientMethodCallParams | AppClientBareCallParams;
    /** Delete transaction parameters to use if a create needs to be issued as part of deployment */
    deleteParams?: AppClientMethodCallParams | AppClientBareCallParams;
    /**
     * Whether or not the contract should have deploy-time immutability control set.
     * `undefined` = use AppFactory constructor value if set or base it on the app spec.
     */
    updatable?: boolean;
    /**
     * Whether or not the contract should have deploy-time permanence control set.
     * `undefined` = use AppFactory constructor value if set or base it on the app spec.
     */
    deletable?: boolean;
    /** Override the app name for this deployment */
    appName?: string;
}>;
/**
 * ARC-56/ARC-32 app factory that, for a given app spec, allows you to create
 * and deploy one or more app instances and to create one or more app clients
 * to interact with those (or other) app instances.
 */
export declare class AppFactory {
    private _appSpec;
    private _appName;
    private _algorand;
    private _version;
    private _defaultSender?;
    private _defaultSigner?;
    private _deployTimeParams?;
    private _updatable?;
    private _deletable?;
    private _approvalSourceMap;
    private _clearSourceMap;
    private _paramsMethods;
    /**
     * Create a new app factory.
     * @param params The parameters to create the app factory
     * @returns The `AppFactory` instance
     * @example
     * ```typescript
     * const appFactory = new AppFactory({
     *   appSpec: appSpec,
     *   algorand: AlgorandClient.mainNet(),
     * })
     */
    constructor(params: AppFactoryParams);
    /** The name of the app (from the ARC-32 / ARC-56 app spec or override). */
    get appName(): string;
    /** The ARC-56 app spec being used */
    get appSpec(): Arc56Contract;
    /** Return the algorand client this factory is using. */
    get algorand(): AlgorandClient;
    /** Get parameters to create transactions (create and deploy related calls) for the current app.
     *
     * A good mental model for this is that these parameters represent a deferred transaction creation.
     * @example Create a transaction in the future using Algorand Client
     * ```typescript
     * const createAppParams = appFactory.params.create({method: 'create_method', args: [123, 'hello']})
     * // ...
     * await algorand.send.AppCreateMethodCall(createAppParams)
     * ```
     * @example Define a nested transaction as an ABI argument
     * ```typescript
     * const createAppParams = appFactory.params.create({method: 'create_method', args: [123, 'hello']})
     * await appClient.send.call({method: 'my_method', args: [createAppParams]})
     * ```
     */
    get params(): {
        /** Return params for a create ABI call, including deploy-time TEAL template replacements and compilation if provided */
        create: (params: AppFactoryCreateMethodCallParams) => Promise<{
            deployTimeParams: TealTemplateParams | undefined;
            schema: {
                /** The number of integers saved in global state. */
                globalInts: number;
                /** The number of byte slices saved in global state. */
                globalByteSlices: number;
                /** The number of integers saved in local state. */
                localInts: number;
                /** The number of byte slices saved in local state. */
                localByteSlices: number;
            };
            approvalProgram: Uint8Array<ArrayBufferLike>;
            clearStateProgram: Uint8Array<ArrayBufferLike>;
            maxFee?: import("./amount").AlgoAmount | undefined;
            note?: (Uint8Array | string) | undefined;
            signer?: (algosdk.TransactionSigner | TransactionSignerAccount) | undefined;
            onComplete?: algosdk.OnApplicationComplete.NoOpOC | algosdk.OnApplicationComplete.OptInOC | algosdk.OnApplicationComplete.CloseOutOC | algosdk.OnApplicationComplete.UpdateApplicationOC | algosdk.OnApplicationComplete.DeleteApplicationOC | undefined;
            rejectVersion?: number | undefined;
            lease?: (Uint8Array | string) | undefined;
            rekeyTo?: (string | Address) | undefined;
            staticFee?: import("./amount").AlgoAmount | undefined;
            extraFee?: import("./amount").AlgoAmount | undefined;
            validityWindow?: number | bigint | undefined;
            firstValidRound?: bigint | undefined;
            lastValidRound?: bigint | undefined;
            accountReferences?: (string | Address)[] | undefined;
            appReferences?: bigint[] | undefined;
            assetReferences?: bigint[] | undefined;
            boxReferences?: (import("./app-manager").BoxReference | import("./app-manager").BoxIdentifier)[];
            accessReferences?: import("./app-manager").ResourceReference[] | undefined;
            sender?: (Address | string) | undefined;
            method: string;
            args?: (ABIValue | ABIStruct | AppMethodCallTransactionArgument | undefined)[];
            updatable?: boolean | undefined;
            deletable?: boolean | undefined;
            extraProgramPages?: number | undefined;
        } & {
            sender: algosdk.Address;
            signer: algosdk.TransactionSigner | TransactionSignerAccount | undefined;
            method: Arc56Method;
            args: (algosdk.Transaction | algosdk.ABIValue | algosdk.TransactionWithSigner | Promise<algosdk.Transaction> | AppMethodCall<{
                sender: string | Address;
                maxFee?: import("./amount").AlgoAmount | undefined;
                note?: (Uint8Array | string) | undefined;
                args?: Uint8Array[] | undefined;
                signer?: (algosdk.TransactionSigner | TransactionSignerAccount) | undefined;
                onComplete?: algosdk.OnApplicationComplete.NoOpOC | algosdk.OnApplicationComplete.OptInOC | algosdk.OnApplicationComplete.CloseOutOC | algosdk.OnApplicationComplete.UpdateApplicationOC | algosdk.OnApplicationComplete.DeleteApplicationOC | undefined;
                rejectVersion?: number | undefined;
                lease?: (Uint8Array | string) | undefined;
                rekeyTo?: (string | Address) | undefined;
                staticFee?: import("./amount").AlgoAmount | undefined;
                extraFee?: import("./amount").AlgoAmount | undefined;
                validityWindow?: number | bigint | undefined;
                firstValidRound?: bigint | undefined;
                lastValidRound?: bigint | undefined;
                accountReferences?: (string | Address)[] | undefined;
                appReferences?: bigint[] | undefined;
                assetReferences?: bigint[] | undefined;
                boxReferences?: (import("./app-manager").BoxReference | import("./app-manager").BoxIdentifier)[] | undefined;
                accessReferences?: import("./app-manager").ResourceReference[] | undefined;
                approvalProgram: string | Uint8Array;
                clearStateProgram: string | Uint8Array;
                schema?: {
                    globalInts: number;
                    globalByteSlices: number;
                    localInts: number;
                    localByteSlices: number;
                } | undefined;
                extraProgramPages?: number | undefined;
            }> | AppMethodCall<{
                sender: string | Address;
                signer?: (algosdk.TransactionSigner | TransactionSignerAccount) | undefined;
                rekeyTo?: (string | Address) | undefined;
                note?: (Uint8Array | string) | undefined;
                lease?: (Uint8Array | string) | undefined;
                staticFee?: import("./amount").AlgoAmount | undefined;
                extraFee?: import("./amount").AlgoAmount | undefined;
                maxFee?: import("./amount").AlgoAmount | undefined;
                validityWindow?: number | bigint | undefined;
                firstValidRound?: bigint | undefined;
                lastValidRound?: bigint | undefined;
                appId: bigint;
                onComplete?: algosdk.OnApplicationComplete.UpdateApplicationOC | undefined;
                args?: Uint8Array[] | undefined;
                accountReferences?: (string | Address)[] | undefined;
                appReferences?: bigint[] | undefined;
                assetReferences?: bigint[] | undefined;
                boxReferences?: (import("./app-manager").BoxReference | import("./app-manager").BoxIdentifier)[] | undefined;
                accessReferences?: import("./app-manager").ResourceReference[] | undefined;
                rejectVersion?: number | undefined;
                approvalProgram: string | Uint8Array;
                clearStateProgram: string | Uint8Array;
            }> | AppMethodCall<import("./composer").AppMethodCallParams> | undefined)[] | undefined;
            onComplete: algosdk.OnApplicationComplete.NoOpOC | algosdk.OnApplicationComplete.OptInOC | algosdk.OnApplicationComplete.CloseOutOC | algosdk.OnApplicationComplete.UpdateApplicationOC | algosdk.OnApplicationComplete.DeleteApplicationOC;
        }>;
        /** Return params for a deployment update ABI call */
        deployUpdate: (params: AppClientMethodCallParams) => {
            maxFee?: import("./amount").AlgoAmount | undefined;
            note?: (Uint8Array | string) | undefined;
            signer?: (algosdk.TransactionSigner | TransactionSignerAccount) | undefined;
            onComplete?: algosdk.OnApplicationComplete | undefined;
            rejectVersion?: number | undefined;
            lease?: (Uint8Array | string) | undefined;
            rekeyTo?: (string | Address) | undefined;
            staticFee?: import("./amount").AlgoAmount | undefined;
            extraFee?: import("./amount").AlgoAmount | undefined;
            validityWindow?: number | bigint | undefined;
            firstValidRound?: bigint | undefined;
            lastValidRound?: bigint | undefined;
            accountReferences?: (string | Address)[] | undefined;
            appReferences?: bigint[] | undefined;
            assetReferences?: bigint[] | undefined;
            boxReferences?: (import("./app-manager").BoxReference | import("./app-manager").BoxIdentifier)[] | undefined;
            accessReferences?: import("./app-manager").ResourceReference[] | undefined;
            sender?: (Address | string) | undefined;
            method: string;
            args?: (ABIValue | ABIStruct | AppMethodCallTransactionArgument | undefined)[] | undefined;
        } & {
            sender: algosdk.Address;
            signer: algosdk.TransactionSigner | TransactionSignerAccount | undefined;
            method: Arc56Method;
            args: (algosdk.Transaction | algosdk.ABIValue | algosdk.TransactionWithSigner | Promise<algosdk.Transaction> | AppMethodCall<{
                sender: string | Address;
                maxFee?: import("./amount").AlgoAmount | undefined;
                note?: (Uint8Array | string) | undefined;
                args?: Uint8Array[] | undefined;
                signer?: (algosdk.TransactionSigner | TransactionSignerAccount) | undefined;
                onComplete?: algosdk.OnApplicationComplete.NoOpOC | algosdk.OnApplicationComplete.OptInOC | algosdk.OnApplicationComplete.CloseOutOC | algosdk.OnApplicationComplete.UpdateApplicationOC | algosdk.OnApplicationComplete.DeleteApplicationOC | undefined;
                rejectVersion?: number | undefined;
                lease?: (Uint8Array | string) | undefined;
                rekeyTo?: (string | Address) | undefined;
                staticFee?: import("./amount").AlgoAmount | undefined;
                extraFee?: import("./amount").AlgoAmount | undefined;
                validityWindow?: number | bigint | undefined;
                firstValidRound?: bigint | undefined;
                lastValidRound?: bigint | undefined;
                accountReferences?: (string | Address)[] | undefined;
                appReferences?: bigint[] | undefined;
                assetReferences?: bigint[] | undefined;
                boxReferences?: (import("./app-manager").BoxReference | import("./app-manager").BoxIdentifier)[] | undefined;
                accessReferences?: import("./app-manager").ResourceReference[] | undefined;
                approvalProgram: string | Uint8Array;
                clearStateProgram: string | Uint8Array;
                schema?: {
                    globalInts: number;
                    globalByteSlices: number;
                    localInts: number;
                    localByteSlices: number;
                } | undefined;
                extraProgramPages?: number | undefined;
            }> | AppMethodCall<{
                sender: string | Address;
                signer?: (algosdk.TransactionSigner | TransactionSignerAccount) | undefined;
                rekeyTo?: (string | Address) | undefined;
                note?: (Uint8Array | string) | undefined;
                lease?: (Uint8Array | string) | undefined;
                staticFee?: import("./amount").AlgoAmount | undefined;
                extraFee?: import("./amount").AlgoAmount | undefined;
                maxFee?: import("./amount").AlgoAmount | undefined;
                validityWindow?: number | bigint | undefined;
                firstValidRound?: bigint | undefined;
                lastValidRound?: bigint | undefined;
                appId: bigint;
                onComplete?: algosdk.OnApplicationComplete.UpdateApplicationOC | undefined;
                args?: Uint8Array[] | undefined;
                accountReferences?: (string | Address)[] | undefined;
                appReferences?: bigint[] | undefined;
                assetReferences?: bigint[] | undefined;
                boxReferences?: (import("./app-manager").BoxReference | import("./app-manager").BoxIdentifier)[] | undefined;
                accessReferences?: import("./app-manager").ResourceReference[] | undefined;
                rejectVersion?: number | undefined;
                approvalProgram: string | Uint8Array;
                clearStateProgram: string | Uint8Array;
            }> | AppMethodCall<import("./composer").AppMethodCallParams> | undefined)[] | undefined;
            onComplete: algosdk.OnApplicationComplete.UpdateApplicationOC;
        };
        /** Return params for a deployment delete ABI call */
        deployDelete: (params: AppClientMethodCallParams) => {
            maxFee?: import("./amount").AlgoAmount | undefined;
            note?: (Uint8Array | string) | undefined;
            signer?: (algosdk.TransactionSigner | TransactionSignerAccount) | undefined;
            onComplete?: algosdk.OnApplicationComplete | undefined;
            rejectVersion?: number | undefined;
            lease?: (Uint8Array | string) | undefined;
            rekeyTo?: (string | Address) | undefined;
            staticFee?: import("./amount").AlgoAmount | undefined;
            extraFee?: import("./amount").AlgoAmount | undefined;
            validityWindow?: number | bigint | undefined;
            firstValidRound?: bigint | undefined;
            lastValidRound?: bigint | undefined;
            accountReferences?: (string | Address)[] | undefined;
            appReferences?: bigint[] | undefined;
            assetReferences?: bigint[] | undefined;
            boxReferences?: (import("./app-manager").BoxReference | import("./app-manager").BoxIdentifier)[] | undefined;
            accessReferences?: import("./app-manager").ResourceReference[] | undefined;
            sender?: (Address | string) | undefined;
            method: string;
            args?: (ABIValue | ABIStruct | AppMethodCallTransactionArgument | undefined)[] | undefined;
        } & {
            sender: algosdk.Address;
            signer: algosdk.TransactionSigner | TransactionSignerAccount | undefined;
            method: Arc56Method;
            args: (algosdk.Transaction | algosdk.ABIValue | algosdk.TransactionWithSigner | Promise<algosdk.Transaction> | AppMethodCall<{
                sender: string | Address;
                maxFee?: import("./amount").AlgoAmount | undefined;
                note?: (Uint8Array | string) | undefined;
                args?: Uint8Array[] | undefined;
                signer?: (algosdk.TransactionSigner | TransactionSignerAccount) | undefined;
                onComplete?: algosdk.OnApplicationComplete.NoOpOC | algosdk.OnApplicationComplete.OptInOC | algosdk.OnApplicationComplete.CloseOutOC | algosdk.OnApplicationComplete.UpdateApplicationOC | algosdk.OnApplicationComplete.DeleteApplicationOC | undefined;
                rejectVersion?: number | undefined;
                lease?: (Uint8Array | string) | undefined;
                rekeyTo?: (string | Address) | undefined;
                staticFee?: import("./amount").AlgoAmount | undefined;
                extraFee?: import("./amount").AlgoAmount | undefined;
                validityWindow?: number | bigint | undefined;
                firstValidRound?: bigint | undefined;
                lastValidRound?: bigint | undefined;
                accountReferences?: (string | Address)[] | undefined;
                appReferences?: bigint[] | undefined;
                assetReferences?: bigint[] | undefined;
                boxReferences?: (import("./app-manager").BoxReference | import("./app-manager").BoxIdentifier)[] | undefined;
                accessReferences?: import("./app-manager").ResourceReference[] | undefined;
                approvalProgram: string | Uint8Array;
                clearStateProgram: string | Uint8Array;
                schema?: {
                    globalInts: number;
                    globalByteSlices: number;
                    localInts: number;
                    localByteSlices: number;
                } | undefined;
                extraProgramPages?: number | undefined;
            }> | AppMethodCall<{
                sender: string | Address;
                signer?: (algosdk.TransactionSigner | TransactionSignerAccount) | undefined;
                rekeyTo?: (string | Address) | undefined;
                note?: (Uint8Array | string) | undefined;
                lease?: (Uint8Array | string) | undefined;
                staticFee?: import("./amount").AlgoAmount | undefined;
                extraFee?: import("./amount").AlgoAmount | undefined;
                maxFee?: import("./amount").AlgoAmount | undefined;
                validityWindow?: number | bigint | undefined;
                firstValidRound?: bigint | undefined;
                lastValidRound?: bigint | undefined;
                appId: bigint;
                onComplete?: algosdk.OnApplicationComplete.UpdateApplicationOC | undefined;
                args?: Uint8Array[] | undefined;
                accountReferences?: (string | Address)[] | undefined;
                appReferences?: bigint[] | undefined;
                assetReferences?: bigint[] | undefined;
                boxReferences?: (import("./app-manager").BoxReference | import("./app-manager").BoxIdentifier)[] | undefined;
                accessReferences?: import("./app-manager").ResourceReference[] | undefined;
                rejectVersion?: number | undefined;
                approvalProgram: string | Uint8Array;
                clearStateProgram: string | Uint8Array;
            }> | AppMethodCall<import("./composer").AppMethodCallParams> | undefined)[] | undefined;
            onComplete: algosdk.OnApplicationComplete.DeleteApplicationOC;
        };
        bare: {
            /** Return params for a create bare call, including deploy-time TEAL template replacements and compilation if provided */
            create: (params?: AppFactoryCreateParams) => Promise<{
                approvalProgram: Uint8Array;
                clearStateProgram: Uint8Array;
                compiledApproval?: import("./app").CompiledTeal | undefined;
                compiledClear?: import("./app").CompiledTeal | undefined;
                deployTimeParams: TealTemplateParams | undefined;
                schema: {
                    /** The number of integers saved in global state. */
                    globalInts: number;
                    /** The number of byte slices saved in global state. */
                    globalByteSlices: number;
                    /** The number of integers saved in local state. */
                    localInts: number;
                    /** The number of byte slices saved in local state. */
                    localByteSlices: number;
                };
                maxFee?: import("./amount").AlgoAmount;
                note?: Uint8Array | string;
                args?: Uint8Array[];
                signer?: algosdk.TransactionSigner | TransactionSignerAccount;
                rejectVersion?: number;
                lease?: Uint8Array | string;
                rekeyTo?: string | Address;
                staticFee?: import("./amount").AlgoAmount;
                extraFee?: import("./amount").AlgoAmount;
                validityWindow?: number | bigint;
                firstValidRound?: bigint;
                lastValidRound?: bigint;
                accountReferences?: (string | Address)[];
                appReferences?: bigint[];
                assetReferences?: bigint[];
                boxReferences?: (import("./app-manager").BoxReference | import("./app-manager").BoxIdentifier)[];
                accessReferences?: import("./app-manager").ResourceReference[];
                sender?: Address | string;
                updatable?: boolean;
                deletable?: boolean;
                onComplete?: Exclude<OnApplicationComplete, OnApplicationComplete.ClearStateOC>;
                extraProgramPages?: number;
            } & {
                sender: algosdk.Address;
                signer: algosdk.TransactionSigner | TransactionSignerAccount | undefined;
                onComplete: algosdk.OnApplicationComplete.NoOpOC | algosdk.OnApplicationComplete.OptInOC | algosdk.OnApplicationComplete.CloseOutOC | algosdk.OnApplicationComplete.UpdateApplicationOC | algosdk.OnApplicationComplete.DeleteApplicationOC;
            }>;
            /** Return params for a deployment update bare call */
            deployUpdate: (params?: AppClientBareCallParams) => {
                maxFee?: import("./amount").AlgoAmount | undefined;
                note?: (Uint8Array | string) | undefined;
                args?: Uint8Array[] | undefined;
                signer?: (algosdk.TransactionSigner | TransactionSignerAccount) | undefined;
                rejectVersion?: number | undefined;
                lease?: (Uint8Array | string) | undefined;
                rekeyTo?: (string | Address) | undefined;
                staticFee?: import("./amount").AlgoAmount | undefined;
                extraFee?: import("./amount").AlgoAmount | undefined;
                validityWindow?: number | bigint | undefined;
                firstValidRound?: bigint | undefined;
                lastValidRound?: bigint | undefined;
                accountReferences?: (string | Address)[] | undefined;
                appReferences?: bigint[] | undefined;
                assetReferences?: bigint[] | undefined;
                boxReferences?: (import("./app-manager").BoxReference | import("./app-manager").BoxIdentifier)[] | undefined;
                accessReferences?: import("./app-manager").ResourceReference[] | undefined;
                sender?: (Address | string) | undefined;
            } & {
                sender: algosdk.Address;
                signer: algosdk.TransactionSigner | TransactionSignerAccount | undefined;
                onComplete: algosdk.OnApplicationComplete.UpdateApplicationOC;
            };
            /** Return params for a deployment delete bare call */
            deployDelete: (params?: AppClientBareCallParams) => {
                maxFee?: import("./amount").AlgoAmount | undefined;
                note?: (Uint8Array | string) | undefined;
                args?: Uint8Array[] | undefined;
                signer?: (algosdk.TransactionSigner | TransactionSignerAccount) | undefined;
                rejectVersion?: number | undefined;
                lease?: (Uint8Array | string) | undefined;
                rekeyTo?: (string | Address) | undefined;
                staticFee?: import("./amount").AlgoAmount | undefined;
                extraFee?: import("./amount").AlgoAmount | undefined;
                validityWindow?: number | bigint | undefined;
                firstValidRound?: bigint | undefined;
                lastValidRound?: bigint | undefined;
                accountReferences?: (string | Address)[] | undefined;
                appReferences?: bigint[] | undefined;
                assetReferences?: bigint[] | undefined;
                boxReferences?: (import("./app-manager").BoxReference | import("./app-manager").BoxIdentifier)[] | undefined;
                accessReferences?: import("./app-manager").ResourceReference[] | undefined;
                sender?: (Address | string) | undefined;
            } & {
                sender: algosdk.Address;
                signer: algosdk.TransactionSigner | TransactionSignerAccount | undefined;
                onComplete: algosdk.OnApplicationComplete.DeleteApplicationOC;
            };
        };
    };
    /** Create transactions for the current app */
    readonly createTransaction: {
        /** Create bare (raw) transactions for the current app */
        bare: {
            /**
             * Create a create app call transaction using a bare (raw) create call.
             *
             * Performs deploy-time TEAL template placeholder substitutions (if specified).
             * @param params The parameters to create the create call transaction
             * @returns The create call transaction
             */
            create: (params?: AppFactoryCreateParams) => Promise<algosdk.Transaction>;
        };
        /**
         * Create a create app call transaction using an ABI create call.
         *
         * Performs deploy-time TEAL template placeholder substitutions (if specified).
         * @param params The parameters to create the create call transaction
         * @returns The create call transaction
         */
        create: (params: AppFactoryCreateMethodCallParams) => Promise<{
            transactions: algosdk.Transaction[];
            methodCalls: Map<number, algosdk.ABIMethod>;
            signers: Map<number, algosdk.TransactionSigner>;
        }>;
    };
    /** Send transactions to the current app */
    readonly send: {
        /** Send bare (raw) transactions for the current app */
        bare: {
            /**
             * Creates an instance of the app using a bare (raw) create call and returns the result
             * of the creation transaction and an app client to interact with that app instance.
             *
             * Performs deploy-time TEAL template placeholder substitutions (if specified).
             * @param params The parameters to create the app
             * @returns The app client and the result of the creation transaction
             */
            create: (params?: AppFactoryCreateParams & SendParams) => Promise<{
                appClient: AppClient;
                result: {
                    compiledApproval?: import("./app").CompiledTeal | undefined;
                    compiledClear?: import("./app").CompiledTeal | undefined;
                    return: undefined;
                    groupId: string;
                    txIds: string[];
                    returns?: import("./app").ABIReturn[] | undefined;
                    confirmations: algosdk.modelsv2.PendingTransactionResponse[];
                    transactions: algosdk.Transaction[];
                    confirmation: algosdk.modelsv2.PendingTransactionResponse;
                    transaction: algosdk.Transaction;
                    appId: bigint;
                    appAddress: Address;
                };
            }>;
        };
        /**
         * Creates an instance of the app and returns the result of the creation
         * transaction and an app client to interact with that app instance.
         *
         * Performs deploy-time TEAL template placeholder substitutions (if specified).
         * @param params The parameters to create the app
         * @returns The app client and the result of the creation transaction
         */
        create: (params: AppFactoryCreateMethodCallParams & SendParams) => Promise<{
            appClient: AppClient;
            result: {
                compiledApproval?: import("./app").CompiledTeal | undefined;
                compiledClear?: import("./app").CompiledTeal | undefined;
                appId: bigint;
                groupId: string;
                txIds: string[];
                returns?: import("./app").ABIReturn[] | undefined;
                confirmations: algosdk.modelsv2.PendingTransactionResponse[];
                transactions: algosdk.Transaction[];
                confirmation: algosdk.modelsv2.PendingTransactionResponse;
                transaction: algosdk.Transaction;
                appAddress: Address;
                return?: Uint8Array<ArrayBufferLike> | algosdk.ABIValue | ABIStruct | undefined;
            };
        }>;
    };
    /**
     * Idempotently deploy (create if not exists, update if changed) an app against the given name for the given creator account, including deploy-time TEAL template placeholder substitutions (if specified).
     *
     * **Note:** When using the return from this function be sure to check `operationPerformed` to get access to various return properties like `transaction`, `confirmation` and `deleteResult`.
     *
     * **Note:** if there is a breaking state schema change to an existing app (and `onSchemaBreak` is set to `'replace'`) the existing app will be deleted and re-created.
     *
     * **Note:** if there is an update (different TEAL code) to an existing app (and `onUpdate` is set to `'replace'`) the existing app will be deleted and re-created.
     * @param params The arguments to control the app deployment
     * @returns The app client and the result of the deployment
     * @example
     * ```ts
     * const { appClient, result } = await factory.deploy({
     *   createParams: {
     *     sender: 'SENDER_ADDRESS',
     *     approvalProgram: 'APPROVAL PROGRAM',
     *     clearStateProgram: 'CLEAR PROGRAM',
     *     schema: {
     *       globalByteSlices: 0,
     *       globalInts: 0,
     *       localByteSlices: 0,
     *       localInts: 0
     *     }
     *   },
     *   updateParams: {
     *     sender: 'SENDER_ADDRESS'
     *   },
     *   deleteParams: {
     *     sender: 'SENDER_ADDRESS'
     *   },
     *   metadata: { name: 'my_app', version: '2.0', updatable: false, deletable: false },
     *   onSchemaBreak: 'append',
     *   onUpdate: 'append'
     *  })
     * ```
     */
    deploy(params: AppFactoryDeployParams): Promise<{
        appClient: AppClient;
        result: {
            return: string | number | bigint | boolean | algosdk.Address | Uint8Array<ArrayBufferLike> | algosdk.ABIValue[] | ABIStruct | undefined;
            deleteReturn: string | number | bigint | boolean | algosdk.Address | Uint8Array<ArrayBufferLike> | algosdk.ABIValue[] | ABIStruct | undefined;
            compiledApproval?: import("./app").CompiledTeal | undefined;
            compiledClear?: import("./app").CompiledTeal | undefined;
            operationPerformed: "create";
            version: string;
            name: string;
            createdRound: bigint;
            updatedRound: bigint;
            createdMetadata: import("./app").AppDeployMetadata;
            deleted: boolean;
            deletable?: boolean | undefined;
            updatable?: boolean | undefined;
            groupId: string;
            txIds: string[];
            returns?: import("./app").ABIReturn[] | undefined;
            confirmations: algosdk.modelsv2.PendingTransactionResponse[];
            transactions: algosdk.Transaction[];
            confirmation: algosdk.modelsv2.PendingTransactionResponse;
            transaction: algosdk.Transaction;
            appId: bigint;
            appAddress: Address;
        } | {
            return: string | number | bigint | boolean | algosdk.Address | Uint8Array<ArrayBufferLike> | algosdk.ABIValue[] | ABIStruct | undefined;
            deleteReturn: string | number | bigint | boolean | algosdk.Address | Uint8Array<ArrayBufferLike> | algosdk.ABIValue[] | ABIStruct | undefined;
            compiledApproval?: import("./app").CompiledTeal | undefined;
            compiledClear?: import("./app").CompiledTeal | undefined;
            operationPerformed: "update";
            appId: bigint;
            appAddress: Address;
            createdRound: bigint;
            updatedRound: bigint;
            createdMetadata: import("./app").AppDeployMetadata;
            deleted: boolean;
            name: string;
            version: string;
            deletable?: boolean | undefined;
            updatable?: boolean | undefined;
            groupId: string;
            txIds: string[];
            returns?: import("./app").ABIReturn[] | undefined;
            confirmations: algosdk.modelsv2.PendingTransactionResponse[];
            transactions: algosdk.Transaction[];
            confirmation: algosdk.modelsv2.PendingTransactionResponse;
            transaction: algosdk.Transaction;
        } | {
            return: string | number | bigint | boolean | algosdk.Address | Uint8Array<ArrayBufferLike> | algosdk.ABIValue[] | ABIStruct | undefined;
            deleteReturn: string | number | bigint | boolean | algosdk.Address | Uint8Array<ArrayBufferLike> | algosdk.ABIValue[] | ABIStruct | undefined;
            compiledApproval?: import("./app").CompiledTeal | undefined;
            compiledClear?: import("./app").CompiledTeal | undefined;
            operationPerformed: "replace";
            version: string;
            name: string;
            createdRound: bigint;
            updatedRound: bigint;
            createdMetadata: import("./app").AppDeployMetadata;
            deleted: boolean;
            deletable?: boolean | undefined;
            updatable?: boolean | undefined;
            groupId: string;
            txIds: string[];
            returns?: import("./app").ABIReturn[] | undefined;
            confirmations: algosdk.modelsv2.PendingTransactionResponse[];
            transactions: algosdk.Transaction[];
            confirmation: algosdk.modelsv2.PendingTransactionResponse;
            transaction: algosdk.Transaction;
            appId: bigint;
            appAddress: Address;
            deleteResult: import("./transaction").ConfirmedTransactionResult;
        } | {
            return: string | number | bigint | boolean | algosdk.Address | Uint8Array<ArrayBufferLike> | algosdk.ABIValue[] | ABIStruct | undefined;
            deleteReturn: string | number | bigint | boolean | algosdk.Address | Uint8Array<ArrayBufferLike> | algosdk.ABIValue[] | ABIStruct | undefined;
            compiledApproval?: import("./app").CompiledTeal | undefined;
            compiledClear?: import("./app").CompiledTeal | undefined;
            operationPerformed: "nothing";
            appId: bigint;
            appAddress: Address;
            createdRound: bigint;
            updatedRound: bigint;
            createdMetadata: import("./app").AppDeployMetadata;
            deleted: boolean;
            name: string;
            version: string;
            deletable?: boolean | undefined;
            updatable?: boolean | undefined;
        };
    }>;
    /**
     * Returns a new `AppClient` client for an app instance of the given ID.
     *
     * Automatically populates appName, defaultSender and source maps from the factory
     * if not specified in the params.
     * @param params The parameters to create the app client
     * @returns The `AppClient` instance
     * @example
     * ```typescript
     * const appClient = factory.getAppClientById({ appId: 12345n })
     * ```
     */
    getAppClientById(params: AppFactoryAppClientParams): AppClient;
    /**
     * Returns a new `AppClient` client, resolving the app by creator address and name
     * using AlgoKit app deployment semantics (i.e. looking for the app creation transaction note).
     *
     * Automatically populates appName, defaultSender and source maps from the factory
     * if not specified in the params.
     * @param params The parameters to create the app client
     * @returns The `AppClient` instance
     * @example
     * ```typescript
     * const appClient = factory.getAppClientByCreatorAndName({ creatorAddress: 'CREATOR_ADDRESS', appName: 'my_app' })
     * ```
     */
    getAppClientByCreatorAndName(params: AppFactoryResolveAppClientByCreatorAndNameParams): Promise<AppClient>;
    /**
     * Takes an error that may include a logic error from a call to the current app and re-exposes the
     * error to include source code information via the source map and ARC-56 spec.
     * @param e The error to parse
     * @param isClearStateProgram Whether or not the code was running the clear state program (defaults to approval program)
     * @returns The new error, or if there was no logic error or source map then the wrapped error with source details
     */
    exposeLogicError(e: Error, isClearStateProgram?: boolean): Error;
    /**
     * Export the current source maps for the app.
     * @returns The source maps
     */
    exportSourceMaps(): AppSourceMaps;
    /**
     * Import source maps for the app.
     * @param sourceMaps The source maps to import
     */
    importSourceMaps(sourceMaps: AppSourceMaps): void;
    private getDeployTimeControl;
    private getParamsMethods;
    /** Make the given call and catch any errors, augmenting with debugging information before re-throwing. */
    private handleCallErrors;
    /**
     * Compiles the approval and clear state programs (if TEAL templates provided),
     * performing any provided deploy-time parameter replacement and stores
     * the source maps.
     *
     * If no TEAL templates provided it will use any byte code provided in the app spec.
     *
     * Will store any generated source maps for later use in debugging.
     * @param compilation Optional compilation parameters to use for the compilation
     * @returns The compilation result
     * @example
     * ```typescript
     * const result = await factory.compile()
     * ```
     */
    compile(compilation?: AppClientCompilationParams): Promise<import("./app-client").AppClientCompilationResult>;
    private getBareParams;
    private getABIParams;
    private getCreateABIArgsWithDefaultValues;
    /** Returns the sender for a call, using the `defaultSender`
     * if none provided and throws an error if neither provided */
    private getSender;
    /** Returns the signer for a call, using the provided signer or the `defaultSigner`
     * if no signer was provided and the sender resolves to the default sender, the call will use default signer
     * or `undefined` otherwise (so the signer is resolved from `AlgorandClient`) */
    private getSigner;
    /**
     * Checks for decode errors on the SendAppTransactionResult and maps the return value to the specified type
     * on the ARC-56 method.
     *
     * If the return type is a struct then the struct will be returned.
     *
     * @param result The SendAppTransactionResult to be mapped
     * @param method The method that was called
     * @returns The smart contract response with an updated return value
     */
    parseMethodCallReturn<TReturn extends Uint8Array | ABIValue | ABIStruct | undefined, TResult extends SendAppTransactionResult = SendAppTransactionResult>(result: Promise<TResult> | TResult, method: Arc56Method): Promise<Omit<TResult, 'return'> & AppReturn<TReturn>>;
}
