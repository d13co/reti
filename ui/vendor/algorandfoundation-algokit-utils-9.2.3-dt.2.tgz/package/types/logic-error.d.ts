/**
 * Details about a smart contract logic error
 */
export interface LogicErrorDetails {
    /** The ID of the transaction with the logic error */
    txId: string;
    /** The program counter where the error was */
    pc: number;
    /** The error message */
    msg: string;
    /** The full error description */
    desc: string;
    /** Any trace information included in the error */
    traces: Record<string, unknown>[];
}
/** Wraps key functionality around processing logic errors */
export declare class LogicError extends Error {
    /** Takes an error message and parses out the details of any logic errors in there.
     * @param error The error message to parse
     * @returns The logic error details if any, or undefined
     */
    static parseLogicError(error: any): LogicErrorDetails | undefined;
    led: LogicErrorDetails;
    program: string[];
    lines: number;
    teal_line: number;
    stack?: string;
    /**
     * Create a new logic error object.
     * @param errorDetails The details of the logic error
     * @param program The TEAL source code, split by line
     * @param getLineForPc The source map of the TEAL source code
     */
    constructor(errorDetails: LogicErrorDetails, program: string[], getLineForPc: (pc: number) => number | undefined);
}
