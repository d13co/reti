import { fetchOptions } from "./dt-support.mjs";
import { AppManager } from "./app-manager.mjs";
import { AssetManager } from "./asset-manager.mjs";
import { accountInformationFromAlgod } from "./account-manager.mjs";
import { Buffer } from "buffer";
//#region src/types/dt-manager.ts
const boxName = (name) => ({
	nameRaw: name,
	nameBase64: Buffer.from(name).toString("base64"),
	name: Buffer.from(name).toString("utf-8")
});
const boxNameBytes = (name) => AppManager.getBoxReference(typeof name === "object" && "nameRaw" in name ? name.nameRaw : name).name;
const mapBoxVersion = (v) => ({
	round: v.round,
	timestamp: v.timestamp,
	deleted: v.deleted,
	value: v.value
});
const mapBoxesVersion = (v) => ({
	round: v.round,
	timestamp: v.timestamp,
	boxes: v.boxes.map((b) => ({
		name: boxName(b.name),
		deleted: b.deleted,
		value: b.value
	}))
});
const mapAppVersion = (v) => ({
	round: v.round,
	timestamp: v.timestamp,
	deleted: v.deleted,
	app: v.application?.params ? AppManager.appInformationFromAlgod(v.application) : void 0
});
const mapAssetVersion = (v) => ({
	round: v.round,
	timestamp: v.timestamp,
	deleted: v.deleted,
	asset: v.asset?.params ? AssetManager.assetInformationFromAlgod(v.asset) : void 0
});
const mapAccountVersion = (v) => ({
	round: v.round,
	timestamp: v.timestamp,
	base: v.base && {
		deleted: v.base.deleted,
		account: v.base.account ? accountInformationFromAlgod(v.base.account) : void 0
	},
	assets: v.assets?.map((a) => ({
		assetId: a.assetId,
		deleted: a.deleted,
		holding: a.assetHolding ? {
			balance: BigInt(a.assetHolding.amount),
			frozen: a.assetHolding.isFrozen
		} : void 0
	})),
	appsLocalState: v.appsLocalState?.map((a) => ({
		appId: a.appId,
		deleted: a.deleted,
		state: a.appLocalState ? AppManager.decodeAppState(a.appLocalState.keyValue ?? []) : void 0
	})),
	createdAssets: v.createdAssets?.map((a) => ({
		assetId: a.assetId,
		deleted: a.deleted,
		asset: a.asset?.params ? AssetManager.assetInformationFromAlgod(a.asset) : void 0
	})),
	createdApps: v.createdApps?.map((a) => ({
		appId: a.appId,
		deleted: a.deleted,
		app: a.application?.params ? AppManager.appInformationFromAlgod(a.application) : void 0
	}))
});
/**
* Time travel on a time-travel algod (dtalgod with `EnableTimeTravel`): the rounds at which boxes, apps, assets and
* accounts changed, with their values.
*
* Needs the time-travel fork of algosdk; without it every method throws a `DTNotAvailableError`. A node without
* time travel throws the fork's `DTUnsupportedError`.
*
* To read state at a past round, pass `{ round }` to the usual reads (`algorand.app.getGlobalState(appId, { round })`,
* `algorand.account.getInformation(address, { round })`, ...) or use `appClient.atRound(round)`.
*/
var DTManager = class {
	_clientManager;
	/**
	* Create a new time travel manager.
	* @param clientManager The `ClientManager` client to use for algod
	*/
	constructor(clientManager) {
		this._clientManager = clientManager;
	}
	get algod() {
		return this._clientManager.dtAlgod;
	}
	/**
	* Returns whether time travel can be used: the loaded algosdk is the time-travel fork and the node has time travel
	* enabled. The node is probed once per algod client.
	* @returns Whether time travel is supported
	* @example
	* ```typescript
	* if (await algorand.dt.supported()) { ... }
	* ```
	*/
	async supported() {
		return await this._clientManager.supportsDT();
	}
	/**
	* Returns a page of the versions of a box: the rounds at which it changed.
	* @param appId The ID of the app
	* @param name The name of the box
	* @param options The range, order, page size, whether to include values and the `next` token
	* @returns The page of versions
	* @example
	* ```typescript
	* const { versions } = await algorand.dt.getBoxVersions(appId, 'counter', { order: 'desc', limit: 10, includeValues: true })
	* ```
	*/
	async getBoxVersions(appId, name, options) {
		return await this.page(this.algod.getApplicationBoxVersions(appId, boxNameBytes(name)), options, mapBoxVersion);
	}
	/**
	* Iterates over the versions of a box, following the pages.
	* @param appId The ID of the app
	* @param name The name of the box
	* @param options The range, order, page size and whether to include values
	* @returns The versions
	* @example
	* ```typescript
	* for await (const v of algorand.dt.iterateBoxVersions(appId, 'counter', { includeValues: true })) { ... }
	* ```
	*/
	iterateBoxVersions(appId, name, options) {
		return this.iterate(() => this.algod.getApplicationBoxVersions(appId, boxNameBytes(name)), options, mapBoxVersion);
	}
	/**
	* Returns a page of an app's box change feed: the rounds at which any of its boxes changed, with the boxes that
	* changed in each.
	* @param appId The ID of the app
	* @param options The range, order, page size, whether to include values and the `next` token
	* @returns The page of versions
	* @example
	* ```typescript
	* const { versions } = await algorand.dt.getBoxesVersions(appId, { minRound: 45_000_000n })
	* ```
	*/
	async getBoxesVersions(appId, options) {
		return await this.page(this.algod.getApplicationBoxesVersions(appId), options, mapBoxesVersion);
	}
	/**
	* Iterates over an app's box change feed, following the pages.
	* @param appId The ID of the app
	* @param options The range, order, page size and whether to include values
	* @returns The versions
	* @example
	* ```typescript
	* for await (const { round, boxes } of algorand.dt.iterateBoxesVersions(appId)) { ... }
	* ```
	*/
	iterateBoxesVersions(appId, options) {
		return this.iterate(() => this.algod.getApplicationBoxesVersions(appId), options, mapBoxesVersion);
	}
	/**
	* Returns a page of the versions of an app (its params and global state).
	* @param appId The ID of the app
	* @param options The range, order, page size, whether to include values and the `next` token
	* @returns The page of versions
	* @example
	* ```typescript
	* const { versions } = await algorand.dt.getAppVersions(appId, { includeValues: true })
	* const counters = versions.map((v) => v.app?.globalState.counter?.value)
	* ```
	*/
	async getAppVersions(appId, options) {
		return await this.page(this.algod.getApplicationVersions(appId), options, mapAppVersion);
	}
	/**
	* Iterates over the versions of an app (its params and global state), following the pages.
	* @param appId The ID of the app
	* @param options The range, order, page size and whether to include values
	* @returns The versions
	* @example
	* ```typescript
	* for await (const v of algorand.dt.iterateAppVersions(appId, { includeValues: true })) { ... }
	* ```
	*/
	iterateAppVersions(appId, options) {
		return this.iterate(() => this.algod.getApplicationVersions(appId), options, mapAppVersion);
	}
	/**
	* Returns a page of the versions of an asset (its params).
	* @param assetId The ID of the asset
	* @param options The range, order, page size, whether to include values and the `next` token
	* @returns The page of versions
	* @example
	* ```typescript
	* const { versions } = await algorand.dt.getAssetVersions(assetId, { includeValues: true })
	* ```
	*/
	async getAssetVersions(assetId, options) {
		return await this.page(this.algod.getAssetVersions(assetId), options, mapAssetVersion);
	}
	/**
	* Iterates over the versions of an asset (its params), following the pages.
	* @param assetId The ID of the asset
	* @param options The range, order, page size and whether to include values
	* @returns The versions
	* @example
	* ```typescript
	* for await (const v of algorand.dt.iterateAssetVersions(assetId)) { ... }
	* ```
	*/
	iterateAssetVersions(assetId, options) {
		return this.iterate(() => this.algod.getAssetVersions(assetId), options, mapAssetVersion);
	}
	/**
	* Returns a page of the versions of an account: its base record, holdings, local states and created assets and apps.
	* @param address The address of the account
	* @param options The range, order, page size, whether to include values, what to exclude and the `next` token
	* @returns The page of versions
	* @example
	* ```typescript
	* const { versions } = await algorand.dt.getAccountVersions(address, { exclude: ['all'], includeValues: true })
	* const balances = versions.map((v) => v.base?.account?.balance)
	* ```
	*/
	async getAccountVersions(address, options) {
		return await this.page(this.accountVersionsRequest(address, options), options, mapAccountVersion);
	}
	/**
	* Iterates over the versions of an account, following the pages.
	* @param address The address of the account
	* @param options The range, order, page size, whether to include values and what to exclude
	* @returns The versions
	* @example
	* ```typescript
	* for await (const v of algorand.dt.iterateAccountVersions(address, { exclude: ['all'] })) { ... }
	* ```
	*/
	iterateAccountVersions(address, options) {
		return this.iterate(() => this.accountVersionsRequest(address, options), options, mapAccountVersion);
	}
	/**
	* Returns a page of the versions of an account's holding of one asset.
	* @param address The address of the account
	* @param assetId The ID of the asset
	* @param options The range, order, page size, whether to include values and the `next` token
	* @returns The page of versions
	* @example
	* ```typescript
	* const { versions } = await algorand.dt.getAccountAssetVersions(address, assetId, { includeValues: true })
	* ```
	*/
	async getAccountAssetVersions(address, assetId, options) {
		return await this.page(this.algod.accountAssetVersions(address, assetId), options, mapAccountVersion);
	}
	/**
	* Iterates over the versions of an account's holding of one asset, following the pages.
	* @param address The address of the account
	* @param assetId The ID of the asset
	* @param options The range, order, page size and whether to include values
	* @returns The versions
	* @example
	* ```typescript
	* for await (const v of algorand.dt.iterateAccountAssetVersions(address, assetId)) { ... }
	* ```
	*/
	iterateAccountAssetVersions(address, assetId, options) {
		return this.iterate(() => this.algod.accountAssetVersions(address, assetId), options, mapAccountVersion);
	}
	/**
	* Returns a page of the versions of an account's local state in one app (and of the app, if the account created it).
	* @param address The address of the account
	* @param appId The ID of the app
	* @param options The range, order, page size, whether to include values and the `next` token
	* @returns The page of versions
	* @example
	* ```typescript
	* const { versions } = await algorand.dt.getAccountAppVersions(address, appId, { includeValues: true })
	* ```
	*/
	async getAccountAppVersions(address, appId, options) {
		return await this.page(this.algod.accountApplicationVersions(address, appId), options, mapAccountVersion);
	}
	/**
	* Iterates over the versions of an account's local state in one app, following the pages.
	* @param address The address of the account
	* @param appId The ID of the app
	* @param options The range, order, page size and whether to include values
	* @returns The versions
	* @example
	* ```typescript
	* for await (const v of algorand.dt.iterateAccountAppVersions(address, appId)) { ... }
	* ```
	*/
	iterateAccountAppVersions(address, appId, options) {
		return this.iterate(() => this.algod.accountApplicationVersions(address, appId), options, mapAccountVersion);
	}
	accountVersionsRequest(address, options) {
		const request = this.algod.accountVersions(address);
		if (options?.exclude?.length) request.exclude(...options.exclude);
		return request;
	}
	configure(request, options) {
		if (options?.minRound !== void 0) request.minRound(options.minRound);
		if (options?.maxRound !== void 0) request.maxRound(options.maxRound);
		if (options?.order !== void 0) request.order(options.order);
		if (options?.limit !== void 0) request.limit(options.limit);
		if (options?.includeValues) request.include("values");
		return request;
	}
	async page(request, options, map) {
		this.configure(request, options);
		if (options?.next) request.next(options.next);
		const page = await request.do(void 0, fetchOptions(options));
		return {
			round: page.round,
			versions: page.versions.map(map),
			nextToken: page.nextToken || void 0
		};
	}
	async *iterate(request, options, map) {
		for await (const entry of this.configure(request(), options).iterate()) yield map(entry);
	}
};
//#endregion
export { DTManager };

//# sourceMappingURL=dt-manager.mjs.map