import algosdk, { Address } from 'algosdk';
import { TransactionSignerAccount } from './account';
import { AlgoAmount } from './amount';
import { AppManager, BoxIdentifier, BoxReference, ResourceReference } from './app-manager';
import { Expand } from './expand';
import { Arc2TransactionNote, SendAtomicTransactionComposerResults, SendParams } from './transaction';
import Transaction = algosdk.Transaction;
import TransactionSigner = algosdk.TransactionSigner;
import TransactionWithSigner = algosdk.TransactionWithSigner;
import SimulateResponse = algosdk.modelsv2.SimulateResponse;
import modelsv2 = algosdk.modelsv2;
export declare const MAX_TRANSACTION_GROUP_SIZE = 16;
/** Options to control a simulate request, that does not require transaction signing */
export type SkipSignaturesSimulateOptions = Expand<Omit<RawSimulateOptions, 'fixSigners' | 'allowEmptySignatures'> & {
    /** Whether or not to skip signatures for all built transactions and use an empty signer instead.
     * This will set `fixSigners` and `allowEmptySignatures` when sending the request to the algod API.
     */
    skipSignatures: boolean;
}>;
/** The raw API options to control a simulate request.
 * See algod API docs for more information: https://dev.algorand.co/reference/rest-api/algod/operations/simulatetransaction/
 */
export type RawSimulateOptions = Expand<Omit<ConstructorParameters<typeof modelsv2.SimulateRequest>[0], 'txnGroups'> & {
    /**
     * Aborts the request. With the time-travel simulate (`algorand.simulate.*`) it cancels the HTTP request; with
     * `composer.simulate` it is checked before and after the request (algosdk's composer can't pass it to fetch).
     * Not sent to algod.
     */
    signal?: AbortSignal;
}>;
/** All options to control a simulate request */
export type SimulateOptions = Expand<Partial<SkipSignaturesSimulateOptions> & RawSimulateOptions>;
/** Common parameters for defining a transaction. */
export type CommonTransactionParams = {
    /** The address of the account sending the transaction. */
    sender: string | Address;
    /** The function used to sign transaction(s); if not specified then
     *  an attempt will be made to find a registered signer for the
     *  given `sender` or use a default signer (if configured).
     */
    signer?: algosdk.TransactionSigner | TransactionSignerAccount;
    /** Change the signing key of the sender to the given address.
     *
     * **Warning:** Please be careful with this parameter and be sure to read the [official rekey guidance](https://dev.algorand.co/concepts/accounts/rekeying).
     */
    rekeyTo?: string | Address;
    /** Note to attach to the transaction. Max of 1000 bytes. */
    note?: Uint8Array | string;
    /** Prevent multiple transactions with the same lease being included within the validity window.
     *
     * A [lease](https://dev.algorand.co/concepts/transactions/leases)
     *  enforces a mutually exclusive transaction (useful to prevent double-posting and other scenarios).
     */
    lease?: Uint8Array | string;
    /** The static transaction fee. In most cases you want to use `extraFee` unless setting the fee to 0 to be covered by another transaction. */
    staticFee?: AlgoAmount;
    /** The fee to pay IN ADDITION to the suggested fee. Useful for manually covering inner transaction fees. */
    extraFee?: AlgoAmount;
    /** Throw an error if the fee for the transaction is more than this amount; prevents overspending on fees during high congestion periods. */
    maxFee?: AlgoAmount;
    /** How many rounds the transaction should be valid for, if not specified then the registered default validity window will be used. */
    validityWindow?: number | bigint;
    /**
     * Set the first round this transaction is valid.
     * If left undefined, the value from algod will be used.
     *
     * We recommend you only set this when you intentionally want this to be some time in the future.
     */
    firstValidRound?: bigint;
    /** The last round this transaction is valid. It is recommended to use `validityWindow` instead. */
    lastValidRound?: bigint;
};
/** Parameters to define a payment transaction. */
export type PaymentParams = CommonTransactionParams & {
    /** The address of the account that will receive the Algo */
    receiver: string | Address;
    /** Amount to send */
    amount: AlgoAmount;
    /** If given, close the sender account and send the remaining balance to this address
     *
     * *Warning:* Be careful with this parameter as it can lead to loss of funds if not used correctly.
     */
    closeRemainderTo?: string | Address;
};
/** Parameters to define an asset create transaction.
 *
 * The account that sends this transaction will automatically be opted in to the asset and will hold all units after creation.
 */
export type AssetCreateParams = CommonTransactionParams & {
    /** The total amount of the smallest divisible (decimal) unit to create.
     *
     * For example, if `decimals` is, say, 2, then for every 100 `total` there would be 1 whole unit.
     *
     * This field can only be specified upon asset creation.
     */
    total: bigint;
    /** The amount of decimal places the asset should have.
     *
     * If unspecified then the asset will be in whole units (i.e. `0`).
     *
     * * If 0, the asset is not divisible;
     * * If 1, the base unit of the asset is in tenths;
     * * If 2, the base unit of the asset is in hundredths;
     * * If 3, the base unit of the asset is in thousandths;
     * * and so on up to 19 decimal places.
     *
     * This field can only be specified upon asset creation.
     */
    decimals?: number;
    /** The optional name of the asset.
     *
     * Max size is 32 bytes.
     *
     * This field can only be specified upon asset creation.
     */
    assetName?: string;
    /** The optional name of the unit of this asset (e.g. ticker name).
     *
     * Max size is 8 bytes.
     *
     * This field can only be specified upon asset creation.
     */
    unitName?: string;
    /** Specifies an optional URL where more information about the asset can be retrieved (e.g. metadata).
     *
     * Max size is 96 bytes.
     *
     * This field can only be specified upon asset creation.
     */
    url?: string;
    /** 32-byte hash of some metadata that is relevant to your asset and/or asset holders.
     *
     * The format of this metadata is up to the application.
     *
     * This field can only be specified upon asset creation.
     */
    metadataHash?: string | Uint8Array;
    /** Whether the asset is frozen by default for all accounts.
     * Defaults to `false`.
     *
     * If `true` then for anyone apart from the creator to hold the
     * asset it needs to be unfrozen per account using an asset freeze
     * transaction from the `freeze` account, which must be set on creation.
     *
     * This field can only be specified upon asset creation.
     */
    defaultFrozen?: boolean;
    /** The address of the optional account that can manage the configuration of the asset and destroy it.
     *
     * The configuration fields it can change are `manager`, `reserve`, `clawback`, and `freeze`.
     *
     * If not set (`undefined` or `""`) at asset creation or subsequently set to empty by the `manager` the asset becomes permanently immutable.
     */
    manager?: string | Address;
    /**
     * The address of the optional account that holds the reserve (uncirculated supply) units of the asset.
     *
     * This address has no specific authority in the protocol itself and is informational only.
     *
     * Some standards like [ARC-19](https://github.com/algorandfoundation/ARCs/blob/main/ARCs/arc-0019.md)
     * rely on this field to hold meaningful data.
     *
     * It can be used in the case where you want to signal to holders of your asset that the uncirculated units
     * of the asset reside in an account that is different from the default creator account.
     *
     * If not set (`undefined` or `""`) at asset creation or subsequently set to empty by the manager the field is permanently empty.
     */
    reserve?: string | Address;
    /**
     * The address of the optional account that can be used to freeze or unfreeze holdings of this asset for any account.
     *
     * If empty, freezing is not permitted.
     *
     * If not set (`undefined` or `""`) at asset creation or subsequently set to empty by the manager the field is permanently empty.
     */
    freeze?: string | Address;
    /**
     * The address of the optional account that can clawback holdings of this asset from any account.
     *
     * **This field should be used with caution** as the clawback account has the ability to **unconditionally take assets from any account**.
     *
     * If empty, clawback is not permitted.
     *
     * If not set (`undefined` or `""`) at asset creation or subsequently set to empty by the manager the field is permanently empty.
     */
    clawback?: string | Address;
};
/** Parameters to define an asset reconfiguration transaction.
 *
 * **Note:** The manager, reserve, freeze, and clawback addresses
 * are immutably empty if they are not set. If manager is not set then
 * all fields are immutable from that point forward.
 */
export type AssetConfigParams = CommonTransactionParams & {
    /** ID of the asset to reconfigure */
    assetId: bigint;
    /** The address of the optional account that can manage the configuration of the asset and destroy it.
     *
     * The configuration fields it can change are `manager`, `reserve`, `clawback`, and `freeze`.
     *
     * If not set (`undefined` or `""`) the asset will become permanently immutable.
     */
    manager: string | Address | undefined;
    /**
     * The address of the optional account that holds the reserve (uncirculated supply) units of the asset.
     *
     * This address has no specific authority in the protocol itself and is informational only.
     *
     * Some standards like [ARC-19](https://github.com/algorandfoundation/ARCs/blob/main/ARCs/arc-0019.md)
     * rely on this field to hold meaningful data.
     *
     * It can be used in the case where you want to signal to holders of your asset that the uncirculated units
     * of the asset reside in an account that is different from the default creator account.
     *
     * If not set (`undefined` or `""`) the field will become permanently empty.
     */
    reserve?: string | Address;
    /**
     * The address of the optional account that can be used to freeze or unfreeze holdings of this asset for any account.
     *
     * If empty, freezing is not permitted.
     *
     * If not set (`undefined` or `""`) the field will become permanently empty.
     */
    freeze?: string | Address;
    /**
     * The address of the optional account that can clawback holdings of this asset from any account.
     *
     * **This field should be used with caution** as the clawback account has the ability to **unconditionally take assets from any account**.
     *
     * If empty, clawback is not permitted.
     *
     * If not set (`undefined` or `""`) the field will become permanently empty.
     */
    clawback?: string | Address;
};
/** Parameters to define an asset freeze transaction. */
export type AssetFreezeParams = CommonTransactionParams & {
    /** The ID of the asset to freeze/unfreeze */
    assetId: bigint;
    /** The address of the account to freeze or unfreeze */
    account: string | Address;
    /** Whether the assets in the account should be frozen */
    frozen: boolean;
};
/** Parameters to define an asset destroy transaction.
 *
 * Created assets can be destroyed only by the asset manager account. All of the assets must be owned by the creator of the asset before the asset can be deleted.
 */
export type AssetDestroyParams = CommonTransactionParams & {
    /** ID of the asset to destroy */
    assetId: bigint;
};
/** Parameters to define an asset transfer transaction. */
export type AssetTransferParams = CommonTransactionParams & {
    /** ID of the asset to transfer. */
    assetId: bigint;
    /** Amount of the asset to transfer (in smallest divisible (decimal) units). */
    amount: bigint;
    /** The address of the account that will receive the asset unit(s). */
    receiver: string | Address;
    /** Optional address of an account to clawback the asset from.
     *
     * Requires the sender to be the clawback account.
     *
     * **Warning:** Be careful with this parameter as it can lead to unexpected loss of funds if not used correctly.
     */
    clawbackTarget?: string | Address;
    /** Optional address of an account to close the asset position to.
     *
     * **Warning:** Be careful with this parameter as it can lead to loss of funds if not used correctly.
     */
    closeAssetTo?: string | Address;
};
/** Parameters to define an asset opt-in transaction. */
export type AssetOptInParams = CommonTransactionParams & {
    /** ID of the asset that will be opted-in to. */
    assetId: bigint;
};
/** Parameters to define an asset opt-out transaction. */
export type AssetOptOutParams = CommonTransactionParams & {
    /** ID of the asset that will be opted-out of. */
    assetId: bigint;
    /**
     * The address of the asset creator account to close the asset
     *   position to (any remaining asset units will be sent to this account).
     */
    creator: string | Address;
};
/** Parameters to define an online key registration transaction. */
export type OnlineKeyRegistrationParams = CommonTransactionParams & {
    /** The root participation public key */
    voteKey: Uint8Array;
    /** The VRF public key */
    selectionKey: Uint8Array;
    /** The first round that the participation key is valid. Not to be confused with the `firstValid` round of the keyreg transaction */
    voteFirst: bigint;
    /** The last round that the participation key is valid. Not to be confused with the `lastValid` round of the keyreg transaction */
    voteLast: bigint;
    /** This is the dilution for the 2-level participation key. It determines the interval (number of rounds) for generating new ephemeral keys */
    voteKeyDilution: bigint;
    /** The 64 byte state proof public key commitment */
    stateProofKey?: Uint8Array;
};
/** Parameters to define an offline key registration transaction. */
export type OfflineKeyRegistrationParams = CommonTransactionParams & {
    /** Prevent this account from ever participating again. The account will also no longer earn rewards */
    preventAccountFromEverParticipatingAgain?: boolean;
};
/** Common parameters for defining an application call transaction. */
export type CommonAppCallParams = CommonTransactionParams & {
    /** ID of the application; 0 if the application is being created. */
    appId: bigint;
    /** The [on-complete](https://dev.algorand.co/concepts/smart-contracts/avm#oncomplete) action of the call; defaults to no-op. */
    onComplete?: algosdk.OnApplicationComplete;
    /** Any [arguments to pass to the smart contract call](https://dev.algorand.co/concepts/smart-contracts/languages/teal/#argument-passing). */
    args?: Uint8Array[];
    /** Any account addresses to add to the [accounts array](https://dev.algorand.co/concepts/smart-contracts/resource-usage#what-are-reference-arrays). */
    accountReferences?: (string | Address)[];
    /** The ID of any apps to load to the [foreign apps array](https://dev.algorand.co/concepts/smart-contracts/resource-usage#what-are-reference-arrays). */
    appReferences?: bigint[];
    /** The ID of any assets to load to the [foreign assets array](https://dev.algorand.co/concepts/smart-contracts/resource-usage#what-are-reference-arrays). */
    assetReferences?: bigint[];
    /** Any boxes to load to the [boxes array](https://dev.algorand.co/concepts/smart-contracts/resource-usage#what-are-reference-arrays).
     *
     * Either the name identifier (which will be set against app ID of `0` i.e.
     *  the current app), or a box identifier with the name identifier and app ID.
     */
    boxReferences?: (BoxReference | BoxIdentifier)[];
    /** Access references unifies `accountReferences`, `appReferences`, `assetReferences`, and `boxReferences` under a single list. If non-empty, these other reference lists must be empty. If access is empty, those other reference lists may be non-empty. */
    accessReferences?: ResourceReference[];
    /** If set, the transaction will be rejected when the app's version is greater than or equal to this value. This can be used to prevent calling an app after it has been updated. Set to 0 or leave undefined to skip the version check. */
    rejectVersion?: number;
};
/** Parameters to define an app create transaction */
export type AppCreateParams = Expand<Omit<CommonAppCallParams, 'appId'> & {
    onComplete?: Exclude<algosdk.OnApplicationComplete, algosdk.OnApplicationComplete.ClearStateOC>;
    /** The program to execute for all OnCompletes other than ClearState as raw teal that will be compiled (string) or compiled teal (encoded as a byte array (Uint8Array)). */
    approvalProgram: string | Uint8Array;
    /** The program to execute for ClearState OnComplete as raw teal that will be compiled (string) or compiled teal (encoded as a byte array (Uint8Array)). */
    clearStateProgram: string | Uint8Array;
    /** The state schema for the app. This is immutable once the app is created. */
    schema?: {
        /** The number of integers saved in global state. */
        globalInts: number;
        /** The number of byte slices saved in global state. */
        globalByteSlices: number;
        /** The number of integers saved in local state. */
        localInts: number;
        /** The number of byte slices saved in local state. */
        localByteSlices: number;
    };
    /** Number of extra pages required for the programs.
     * Defaults to the number needed for the programs in this call if not specified.
     * This is immutable once the app is created. */
    extraProgramPages?: number;
}>;
/** Parameters to define an app update transaction */
export type AppUpdateParams = Expand<CommonAppCallParams & {
    onComplete?: algosdk.OnApplicationComplete.UpdateApplicationOC;
    /** The program to execute for all OnCompletes other than ClearState as raw teal (string) or compiled teal (base 64 encoded as a byte array (Uint8Array)) */
    approvalProgram: string | Uint8Array;
    /** The program to execute for ClearState OnComplete as raw teal (string) or compiled teal (base 64 encoded as a byte array (Uint8Array)) */
    clearStateProgram: string | Uint8Array;
}>;
/** Parameters to define an application call transaction. */
export type AppCallParams = CommonAppCallParams & {
    onComplete?: Exclude<algosdk.OnApplicationComplete, algosdk.OnApplicationComplete.UpdateApplicationOC>;
};
/** Common parameters to define an ABI method call transaction. */
export type AppMethodCallParams = CommonAppCallParams & {
    onComplete?: Exclude<algosdk.OnApplicationComplete, algosdk.OnApplicationComplete.UpdateApplicationOC | algosdk.OnApplicationComplete.ClearStateOC>;
};
/** Parameters to define an application delete call transaction. */
export type AppDeleteParams = CommonAppCallParams & {
    onComplete?: algosdk.OnApplicationComplete.DeleteApplicationOC;
};
/** Parameters to define an ABI method call create transaction. */
export type AppCreateMethodCall = AppMethodCall<AppCreateParams>;
/** Parameters to define an ABI method call update transaction. */
export type AppUpdateMethodCall = AppMethodCall<AppUpdateParams>;
/** Parameters to define an ABI method call delete transaction. */
export type AppDeleteMethodCall = AppMethodCall<AppDeleteParams>;
/** Parameters to define an ABI method call transaction. */
export type AppCallMethodCall = AppMethodCall<AppMethodCallParams>;
/** Types that can be used to define a transaction argument for an ABI call transaction. */
export type AppMethodCallTransactionArgument = TransactionWithSigner | Transaction | Promise<Transaction> | AppMethodCall<AppCreateParams> | AppMethodCall<AppUpdateParams> | AppMethodCall<AppMethodCallParams>;
/** Parameters to define an ABI method call. */
export type AppMethodCall<T> = Expand<Omit<T, 'args'>> & {
    /** The ABI method to call */
    method: algosdk.ABIMethod;
    /** Arguments to the ABI method, either:
     * * An ABI value
     * * A transaction with explicit signer
     * * A transaction (where the signer will be automatically assigned)
     * * An unawaited transaction (e.g. from algorand.createTransaction.{transactionType}())
     * * Another method call (via method call params object)
     * * undefined (this represents a placeholder transaction argument that is fulfilled by another method call argument)
     */
    args?: (algosdk.ABIValue | TransactionWithSigner | Transaction | Promise<Transaction> | AppMethodCall<AppCreateParams> | AppMethodCall<AppUpdateParams> | AppMethodCall<AppMethodCallParams> | undefined)[];
};
export type Txn = (PaymentParams & {
    type: 'pay';
}) | (AssetCreateParams & {
    type: 'assetCreate';
}) | (AssetConfigParams & {
    type: 'assetConfig';
}) | (AssetFreezeParams & {
    type: 'assetFreeze';
}) | (AssetDestroyParams & {
    type: 'assetDestroy';
}) | (AssetTransferParams & {
    type: 'assetTransfer';
}) | (AssetOptInParams & {
    type: 'assetOptIn';
}) | (AssetOptOutParams & {
    type: 'assetOptOut';
}) | ((AppCallParams | AppCreateParams | AppUpdateParams) & {
    type: 'appCall';
}) | ((OnlineKeyRegistrationParams | OfflineKeyRegistrationParams) & {
    type: 'keyReg';
}) | (algosdk.TransactionWithSigner & {
    type: 'txnWithSigner';
}) | {
    atc: algosdk.AtomicTransactionComposer;
    type: 'atc';
} | ((AppCallMethodCall | AppCreateMethodCall | AppUpdateMethodCall) & {
    type: 'methodCall';
});
/**
 * A function that transforms an error into a new error.
 *
 * In most cases, an ErrorTransformer should first check if it can or should transform the error
 * and return the input error if it cannot or should not transform it.
 */
export type ErrorTransformer = (error: Error) => Promise<Error>;
/** Parameters to create an `TransactionComposer`. */
export type TransactionComposerParams = {
    /** The algod client to use to get suggestedParams and send the transaction group */
    algod: algosdk.Algodv2;
    /** The function used to get the TransactionSigner for a given address */
    getSigner: (address: string | Address) => algosdk.TransactionSigner;
    /** The method used to get SuggestedParams for transactions in the group */
    getSuggestedParams?: () => Promise<algosdk.SuggestedParams>;
    /** How many rounds a transaction should be valid for by default; if not specified
     * then will be 10 rounds (or 1000 rounds if issuing transactions to LocalNet).
     */
    defaultValidityWindow?: bigint;
    /** An existing `AppManager` to use to manage app compilation and cache compilation results.
     *
     * If not specified then an ephemeral one will be created.
     */
    appManager?: AppManager;
    /**
     * An array of error transformers to use when an error is caught in simulate or execute
     * callbacks can later be registered with `registerErrorTransformer`
     */
    errorTransformers?: ErrorTransformer[];
};
/** Set of transactions built by `TransactionComposer`. */
export interface BuiltTransactions {
    /** The built transactions */
    transactions: algosdk.Transaction[];
    /** Any `ABIMethod` objects associated with any of the transactions in a map keyed by transaction index. */
    methodCalls: Map<number, algosdk.ABIMethod>;
    /** Any `TransactionSigner` objects associated with any of the transactions in a map keyed by transaction index. */
    signers: Map<number, algosdk.TransactionSigner>;
}
/** TransactionComposer helps you compose and execute transactions as a transaction group. */
export declare class TransactionComposer {
    /** Signer used to represent a lack of signer */
    private static NULL_SIGNER;
    /** The ATC used to compose the group */
    private atc;
    /** Map of transaction index in the atc to a max logical fee.
     * This is set using the value of either maxFee or staticFee.
     */
    private txnMaxFees;
    /** Transactions that have not yet been composed */
    private txns;
    /** The algod client used by the composer. */
    private algod;
    /** An async function that will return suggested params for the transaction. */
    private getSuggestedParams;
    /** A function that takes in an address and return a signer function for that address. */
    private getSigner;
    /** The default transaction validity window */
    private defaultValidityWindow;
    /** Whether the validity window was explicitly set on construction */
    private defaultValidityWindowIsExplicit;
    /**
     * The validity window to build with, while building for a simulate at past rounds: transactions that don't set
     * `firstValidRound` / `lastValidRound` get it instead of one based on the suggested params.
     */
    private validityOverride?;
    private appManager;
    private errorTransformers;
    private transformError;
    /**
     * Create a `TransactionComposer`.
     * @param params The configuration for this composer
     * @returns The `TransactionComposer` instance
     */
    constructor(params: TransactionComposerParams);
    /**
     * Register a function that will be used to transform an error caught when simulating or executing
     *
     * @returns The composer so you can chain method calls
     */
    registerErrorTransformer(transformer: ErrorTransformer): this;
    /**
     * Add a pre-built transaction to the transaction group.
     * @param transaction The pre-built transaction
     * @param signer Optional signer override for the transaction
     * @returns The composer so you can chain method calls
     * @example
     * ```typescript
     * composer.addTransaction(txn)
     * ```
     */
    addTransaction(transaction: Transaction, signer?: TransactionSigner): TransactionComposer;
    /**
     * Add a payment transaction to the transaction group.
     * @param params The payment transaction parameters
     * @returns The composer so you can chain method calls
     * @example Basic example
     * ```typescript
     * composer.addPayment({
     *   sender: 'SENDERADDRESS',
     *   receiver: 'RECEIVERADDRESS',
     *   amount: (4).algo(),
     * })
     * ```
     * @example Advanced example
     * ```typescript
     * composer.addPayment({
     *   amount: (4).algo(),
     *   receiver: 'RECEIVERADDRESS',
     *   sender: 'SENDERADDRESS',
     *   closeRemainderTo: 'CLOSEREMAINDERTOADDRESS',
     *   lease: 'lease',
     *   note: 'note',
     *   // Use this with caution, it's generally better to use algorand.account.rekeyAccount
     *   rekeyTo: 'REKEYTOADDRESS',
     *   // You wouldn't normally set this field
     *   firstValidRound: 1000n,
     *   validityWindow: 10,
     *   extraFee: (1000).microAlgo(),
     *   staticFee: (1000).microAlgo(),
     *   // Max fee doesn't make sense with extraFee AND staticFee
     *   //  already specified, but here for completeness
     *   maxFee: (3000).microAlgo(),
     * })
     */
    addPayment(params: PaymentParams): TransactionComposer;
    /**
     * Add an asset create transaction to the transaction group.
     * @param params The asset create transaction parameters
     * @returns The composer so you can chain method calls
     * @example Basic example
     * ```typescript
     * composer.addAssetCreate({ sender: "CREATORADDRESS", total: 100n})
     * ```
     * @example Advanced example
     * ```typescript
     * composer.addAssetCreate({
     *   sender: 'CREATORADDRESS',
     *   total: 100n,
     *   decimals: 2,
     *   assetName: 'asset',
     *   unitName: 'unit',
     *   url: 'url',
     *   metadataHash: 'metadataHash',
     *   defaultFrozen: false,
     *   manager: 'MANAGERADDRESS',
     *   reserve: 'RESERVEADDRESS',
     *   freeze: 'FREEZEADDRESS',
     *   clawback: 'CLAWBACKADDRESS',
     *   lease: 'lease',
     *   note: 'note',
     *   // You wouldn't normally set this field
     *   firstValidRound: 1000n,
     *   validityWindow: 10,
     *   extraFee: (1000).microAlgo(),
     *   staticFee: (1000).microAlgo(),
     *   // Max fee doesn't make sense with extraFee AND staticFee
     *   //  already specified, but here for completeness
     *   maxFee: (3000).microAlgo(),
     * })
     */
    addAssetCreate(params: AssetCreateParams): TransactionComposer;
    /**
     * Add an asset config transaction to the transaction group.
     * @param params The asset config transaction parameters
     * @returns The composer so you can chain method calls
     * @example Basic example
     * ```typescript
     * composer.addAssetConfig({ sender: "MANAGERADDRESS", assetId: 123456n, manager: "MANAGERADDRESS" })
     * ```
     * @example Advanced example
     * ```typescript
     * composer.addAssetConfig({
     *   sender: 'MANAGERADDRESS',
     *   assetId: 123456n,
     *   manager: 'MANAGERADDRESS',
     *   reserve: 'RESERVEADDRESS',
     *   freeze: 'FREEZEADDRESS',
     *   clawback: 'CLAWBACKADDRESS',
     *   lease: 'lease',
     *   note: 'note',
     *   // You wouldn't normally set this field
     *   firstValidRound: 1000n,
     *   validityWindow: 10,
     *   extraFee: (1000).microAlgo(),
     *   staticFee: (1000).microAlgo(),
     *   // Max fee doesn't make sense with extraFee AND staticFee
     *   //  already specified, but here for completeness
     *   maxFee: (3000).microAlgo(),
     * })
     */
    addAssetConfig(params: AssetConfigParams): TransactionComposer;
    /**
     * Add an asset freeze transaction to the transaction group.
     * @param params The asset freeze transaction parameters
     * @returns The composer so you can chain method calls
     * @example Basic example
     * ```typescript
     * composer.addAssetFreeze({ sender: "MANAGERADDRESS", assetId: 123456n, account: "ACCOUNTADDRESS", frozen: true })
     * ```
     * @example Advanced example
     * ```typescript
     * composer.addAssetFreeze({
     *   sender: 'MANAGERADDRESS',
     *   assetId: 123456n,
     *   account: 'ACCOUNTADDRESS',
     *   frozen: true,
     *   lease: 'lease',
     *   note: 'note',
     *   // You wouldn't normally set this field
     *   firstValidRound: 1000n,
     *   validityWindow: 10,
     *   extraFee: (1000).microAlgo(),
     *   staticFee: (1000).microAlgo(),
     *   // Max fee doesn't make sense with extraFee AND staticFee
     *   //  already specified, but here for completeness
     *   maxFee: (3000).microAlgo(),
     * })
     * ```
     */
    addAssetFreeze(params: AssetFreezeParams): TransactionComposer;
    /**
     * Add an asset destroy transaction to the transaction group.
     * @param params The asset destroy transaction parameters
     * @returns The composer so you can chain method calls
     * @example Basic example
     * ```typescript
     * composer.addAssetDestroy({ sender: "MANAGERADDRESS", assetId: 123456n })
     * ```
     * @example Advanced example
     * ```typescript
     * composer.addAssetDestroy({
     *   sender: 'MANAGERADDRESS',
     *   assetId: 123456n,
     *   lease: 'lease',
     *   note: 'note',
     *   // You wouldn't normally set this field
     *   firstValidRound: 1000n,
     *   validityWindow: 10,
     *   extraFee: (1000).microAlgo(),
     *   staticFee: (1000).microAlgo(),
     *   // Max fee doesn't make sense with extraFee AND staticFee
     *   //  already specified, but here for completeness
     *   maxFee: (3000).microAlgo(),
     * })
     * ```
     */
    addAssetDestroy(params: AssetDestroyParams): TransactionComposer;
    /**
     * Add an asset transfer transaction to the transaction group.
     * @param params The asset transfer transaction parameters
     * @returns The composer so you can chain method calls
     * @example Basic example
     * ```typescript
     * composer.addAssetTransfer({ sender: "HOLDERADDRESS", assetId: 123456n, amount: 1n, receiver: "RECEIVERADDRESS" })
     * ```
     * @example Advanced example (with clawback)
     * ```typescript
     * composer.addAssetTransfer({
     *   sender: 'CLAWBACKADDRESS',
     *   assetId: 123456n,
     *   amount: 1n,
     *   receiver: 'RECEIVERADDRESS',
     *   clawbackTarget: 'HOLDERADDRESS',
     *   // This field needs to be used with caution
     *   closeAssetTo: 'ADDRESSTOCLOSETO'
     *   lease: 'lease',
     *   note: 'note',
     *   // You wouldn't normally set this field
     *   firstValidRound: 1000n,
     *   validityWindow: 10,
     *   extraFee: (1000).microAlgo(),
     *   staticFee: (1000).microAlgo(),
     *   // Max fee doesn't make sense with extraFee AND staticFee
     *   //  already specified, but here for completeness
     *   maxFee: (3000).microAlgo(),
     * })
     * ```
     */
    addAssetTransfer(params: AssetTransferParams): TransactionComposer;
    /**
     * Add an asset opt-in transaction to the transaction group.
     * @param params The asset opt-in transaction parameters
     * @returns The composer so you can chain method calls
     * @example Basic example
     * ```typescript
     * composer.addAssetOptIn({ sender: "SENDERADDRESS", assetId: 123456n })
     * ```
     * @example Advanced example
     * ```typescript
     * composer.addAssetOptIn({
     *   sender: 'SENDERADDRESS',
     *   assetId: 123456n,
     *   lease: 'lease',
     *   note: 'note',
     *   // You wouldn't normally set this field
     *   firstValidRound: 1000n,
     *   validityWindow: 10,
     *   extraFee: (1000).microAlgo(),
     *   staticFee: (1000).microAlgo(),
     *   // Max fee doesn't make sense with extraFee AND staticFee
     *   //  already specified, but here for completeness
     *   maxFee: (3000).microAlgo(),
     * })
     * ```
     */
    addAssetOptIn(params: AssetOptInParams): TransactionComposer;
    /**
     * Add an asset opt-out transaction to the transaction group.
     * @param params The asset opt-out transaction parameters
     * @returns The composer so you can chain method calls
     * @example Basic example (without creator, will be retrieved from algod)
     * ```typescript
     * composer.addAssetOptOut({ sender: "SENDERADDRESS", assetId: 123456n, ensureZeroBalance: true })
     * ```
     * @example Basic example (with creator)
     * ```typescript
     * composer.addAssetOptOut({ sender: "SENDERADDRESS", creator: "CREATORADDRESS", assetId: 123456n, ensureZeroBalance: true })
     * ```
     * @example Advanced example
     * ```typescript
     * composer.addAssetOptOut({
     *   sender: 'SENDERADDRESS',
     *   assetId: 123456n,
     *   creator: 'CREATORADDRESS',
     *   ensureZeroBalance: true,
     *   lease: 'lease',
     *   note: 'note',
     *   // You wouldn't normally set this field
     *   firstValidRound: 1000n,
     *   validityWindow: 10,
     *   extraFee: (1000).microAlgo(),
     *   staticFee: (1000).microAlgo(),
     *   // Max fee doesn't make sense with extraFee AND staticFee
     *   //  already specified, but here for completeness
     *   maxFee: (3000).microAlgo(),
     * })
     * ```
     */
    addAssetOptOut(params: AssetOptOutParams): TransactionComposer;
    /**
     * Add an application create transaction to the transaction group.
     *
     * Note: we recommend using app clients to make it easier to make app calls.
     * @param params The application create transaction parameters
     * @returns The composer so you can chain method calls
     * @example Basic example
     * ```typescript
     * composer.addAppCreate({ sender: 'CREATORADDRESS', approvalProgram: 'TEALCODE', clearStateProgram: 'TEALCODE' })
     * ```
     * @example Advanced example
     * ```typescript
     * composer.addAppCreate({
     *  sender: 'CREATORADDRESS',
     *  approvalProgram: "TEALCODE",
     *  clearStateProgram: "TEALCODE",
     *  schema: {
     *    globalInts: 1,
     *    globalByteSlices: 2,
     *    localInts: 3,
     *    localByteSlices: 4
     *  },
     *  extraProgramPages: 1,
     *  onComplete: algosdk.OnApplicationComplete.OptInOC,
     *  args: [new Uint8Array(1, 2, 3, 4)]
     *  accountReferences: ["ACCOUNT_1"]
     *  appReferences: [123n, 1234n]
     *  assetReferences: [12345n]
     *  boxReferences: ["box1", {appId: 1234n, name: "box2"}]
     *  accessReferences: [{ appId: 1234n }]
     *  lease: 'lease',
     *  note: 'note',
     *  // You wouldn't normally set this field
     *  firstValidRound: 1000n,
     *  validityWindow: 10,
     *  extraFee: (1000).microAlgo(),
     *  staticFee: (1000).microAlgo(),
     *  // Max fee doesn't make sense with extraFee AND staticFee
     *  //  already specified, but here for completeness
     *  maxFee: (3000).microAlgo(),
     *  rejectVersion: 1,
     *  // Signer only needed if you want to provide one,
     *  //  generally you'd register it with AlgorandClient
     *  //  against the sender and not need to pass it in
     *  signer: transactionSigner,
     *  maxRoundsToWaitForConfirmation: 5,
     *  suppressLog: true,
     *})
     * ```
     */
    addAppCreate(params: AppCreateParams): TransactionComposer;
    /**
     * Add an application update transaction to the transaction group.
     *
     * Note: we recommend using app clients to make it easier to make app calls.
     * @param params The application update transaction parameters
     * @returns The composer so you can chain method calls
     * @example Basic example
     * ```typescript
     * composer.addAppUpdate({ sender: 'CREATORADDRESS', approvalProgram: 'TEALCODE', clearStateProgram: 'TEALCODE' })
     * ```
     * @example Advanced example
     * ```typescript
     * composer.addAppUpdate({
     *  sender: 'CREATORADDRESS',
     *  approvalProgram: "TEALCODE",
     *  clearStateProgram: "TEALCODE",
     *  onComplete: algosdk.OnApplicationComplete.UpdateApplicationOC,
     *  args: [new Uint8Array(1, 2, 3, 4)]
     *  accountReferences: ["ACCOUNT_1"]
     *  appReferences: [123n, 1234n]
     *  assetReferences: [12345n]
     *  boxReferences: ["box1", {appId: 1234n, name: "box2"}]
     *  accessReferences: [{ appId: 1234n }]
     *  lease: 'lease',
     *  note: 'note',
     *  // You wouldn't normally set this field
     *  firstValidRound: 1000n,
     *  validityWindow: 10,
     *  extraFee: (1000).microAlgo(),
     *  staticFee: (1000).microAlgo(),
     *  // Max fee doesn't make sense with extraFee AND staticFee
     *  //  already specified, but here for completeness
     *  maxFee: (3000).microAlgo(),
     *  rejectVersion: 1,
     *})
     * ```
     */
    addAppUpdate(params: AppUpdateParams): TransactionComposer;
    /**
     * Add an application delete transaction to the transaction group.
     *
     * Note: we recommend using app clients to make it easier to make app calls.
     * @param params The application delete transaction parameters
     * @returns The composer so you can chain method calls
     * @example Basic example
     * ```typescript
     * composer.addAppDelete({ sender: 'CREATORADDRESS' })
     * ```
     * @example Advanced example
     * ```typescript
     * composer.addAppDelete({
     *  sender: 'CREATORADDRESS',
     *  onComplete: algosdk.OnApplicationComplete.DeleteApplicationOC,
     *  args: [new Uint8Array(1, 2, 3, 4)]
     *  accountReferences: ["ACCOUNT_1"]
     *  appReferences: [123n, 1234n]
     *  assetReferences: [12345n]
     *  boxReferences: ["box1", {appId: 1234n, name: "box2"}]
     *  accessReferences: [{ appId: 1234n }]
     *  lease: 'lease',
     *  note: 'note',
     *  // You wouldn't normally set this field
     *  firstValidRound: 1000n,
     *  validityWindow: 10,
     *  extraFee: (1000).microAlgo(),
     *  staticFee: (1000).microAlgo(),
     *  // Max fee doesn't make sense with extraFee AND staticFee
     *  //  already specified, but here for completeness
     *  maxFee: (3000).microAlgo(),
     *  rejectVersion: 1,
     *})
     * ```
     */
    addAppDelete(params: AppDeleteParams): TransactionComposer;
    /**
     * Add an application call transaction to the transaction group.
     *
     * If you want to create or update an app use `addAppCreate` or `addAppUpdate`.
     *
     * Note: we recommend using app clients to make it easier to make app calls.
     * @param params The application call transaction parameters
     * @returns The composer so you can chain method calls
     * @example Basic example
     * ```typescript
     * composer.addAppCall({ sender: 'CREATORADDRESS' })
     * ```
     * @example Advanced example
     * ```typescript
     * composer.addAppCall({
     *  sender: 'CREATORADDRESS',
     *  onComplete: algosdk.OnApplicationComplete.OptInOC,
     *  args: [new Uint8Array(1, 2, 3, 4)]
     *  accountReferences: ["ACCOUNT_1"]
     *  appReferences: [123n, 1234n]
     *  assetReferences: [12345n]
     *  boxReferences: ["box1", {appId: 1234n, name: "box2"}]
     *  accessReferences: [{ appId: 1234n }]
     *  lease: 'lease',
     *  note: 'note',
     *  // You wouldn't normally set this field
     *  firstValidRound: 1000n,
     *  validityWindow: 10,
     *  extraFee: (1000).microAlgo(),
     *  staticFee: (1000).microAlgo(),
     *  // Max fee doesn't make sense with extraFee AND staticFee
     *  //  already specified, but here for completeness
     *  maxFee: (3000).microAlgo(),
     *  rejectVersion: 1,
     *})
     * ```
     */
    addAppCall(params: AppCallParams): TransactionComposer;
    /**
     * Add an ABI method create application call transaction to the transaction group.
     *
     * Note: we recommend using app clients to make it easier to make app calls.
     * @param params The ABI create method application call transaction parameters
     * @returns The composer so you can chain method calls
     * @example Basic example
     * ```typescript
     * const method = new ABIMethod({
     *   name: 'method',
     *   args: [{ name: 'arg1', type: 'string' }],
     *   returns: { type: 'string' },
     * })
     * composer.addAppCreateMethodCall({ sender: 'CREATORADDRESS', approvalProgram: 'TEALCODE', clearStateProgram: 'TEALCODE', method: method, args: ["arg1_value"] })
     * ```
     * @example Advanced example
     * ```typescript
     * const method = new ABIMethod({
     *   name: 'method',
     *   args: [{ name: 'arg1', type: 'string' }],
     *   returns: { type: 'string' },
     * })
     * composer.addAppCreateMethodCall({
     *  sender: 'CREATORADDRESS',
     *  method: method,
     *  args: ["arg1_value"],
     *  approvalProgram: "TEALCODE",
     *  clearStateProgram: "TEALCODE",
     *  schema: {
     *    globalInts: 1,
     *    globalByteSlices: 2,
     *    localInts: 3,
     *    localByteSlices: 4
     *  },
     *  extraProgramPages: 1,
     *  onComplete: algosdk.OnApplicationComplete.OptInOC,
     *  args: [new Uint8Array(1, 2, 3, 4)]
     *  accountReferences: ["ACCOUNT_1"]
     *  appReferences: [123n, 1234n]
     *  assetReferences: [12345n]
     *  boxReferences: ["box1", {appId: 1234n, name: "box2"}]
     *  accessReferences: [{ appId: 1234n }]
     *  lease: 'lease',
     *  note: 'note',
     *  // You wouldn't normally set this field
     *  firstValidRound: 1000n,
     *  validityWindow: 10,
     *  extraFee: (1000).microAlgo(),
     *  staticFee: (1000).microAlgo(),
     *  // Max fee doesn't make sense with extraFee AND staticFee
     *  //  already specified, but here for completeness
     *  maxFee: (3000).microAlgo(),
     *  rejectVersion: 1,
     *})
     * ```
     */
    addAppCreateMethodCall(params: AppCreateMethodCall): this;
    /**
     * Add an ABI method update application call transaction to the transaction group.
     *
     * Note: we recommend using app clients to make it easier to make app calls.
     * @param params The ABI update method application call transaction parameters
     * @returns The composer so you can chain method calls
     * @example Basic example
     * ```typescript
     * const method = new ABIMethod({
     *   name: 'method',
     *   args: [{ name: 'arg1', type: 'string' }],
     *   returns: { type: 'string' },
     * })
     * composer.addAppUpdateMethodCall({ sender: 'CREATORADDRESS', approvalProgram: 'TEALCODE', clearStateProgram: 'TEALCODE', method: method, args: ["arg1_value"] })
     * ```
     * @example Advanced example
     * ```typescript
     * const method = new ABIMethod({
     *   name: 'method',
     *   args: [{ name: 'arg1', type: 'string' }],
     *   returns: { type: 'string' },
     * })
     * composer.addAppUpdateMethodCall({
     *  sender: 'CREATORADDRESS',
     *  method: method,
     *  args: ["arg1_value"],
     *  approvalProgram: "TEALCODE",
     *  clearStateProgram: "TEALCODE",
     *  onComplete: algosdk.OnApplicationComplete.UpdateApplicationOC,
     *  args: [new Uint8Array(1, 2, 3, 4)]
     *  accountReferences: ["ACCOUNT_1"]
     *  appReferences: [123n, 1234n]
     *  assetReferences: [12345n]
     *  boxReferences: ["box1", {appId: 1234n, name: "box2"}]
     *  accessReferences: [{ appId: 1234n }]
     *  lease: 'lease',
     *  note: 'note',
     *  // You wouldn't normally set this field
     *  firstValidRound: 1000n,
     *  validityWindow: 10,
     *  extraFee: (1000).microAlgo(),
     *  staticFee: (1000).microAlgo(),
     *  // Max fee doesn't make sense with extraFee AND staticFee
     *  //  already specified, but here for completeness
     *  maxFee: (3000).microAlgo(),
     *  rejectVersion: 1,
     *})
     * ```
     */
    addAppUpdateMethodCall(params: AppUpdateMethodCall): this;
    /**
     * Add an ABI method delete application call transaction to the transaction group.
     *
     * Note: we recommend using app clients to make it easier to make app calls.
     * @param params The ABI delete method application call transaction parameters
     * @returns The composer so you can chain method calls
     * @example Basic example
     * ```typescript
     * const method = new ABIMethod({
     *   name: 'method',
     *   args: [{ name: 'arg1', type: 'string' }],
     *   returns: { type: 'string' },
     * })
     * composer.addAppDeleteMethodCall({ sender: 'CREATORADDRESS', method: method, args: ["arg1_value"] })
     * ```
     * @example Advanced example
     * ```typescript
     * const method = new ABIMethod({
     *   name: 'method',
     *   args: [{ name: 'arg1', type: 'string' }],
     *   returns: { type: 'string' },
     * })
     * composer.addAppDeleteMethodCall({
     *  sender: 'CREATORADDRESS',
     *  method: method,
     *  args: ["arg1_value"],
     *  onComplete: algosdk.OnApplicationComplete.DeleteApplicationOC,
     *  args: [new Uint8Array(1, 2, 3, 4)]
     *  accountReferences: ["ACCOUNT_1"]
     *  appReferences: [123n, 1234n]
     *  assetReferences: [12345n]
     *  boxReferences: ["box1", {appId: 1234n, name: "box2"}]
     *  accessReferences: [{ appId: 1234n }]
     *  lease: 'lease',
     *  note: 'note',
     *  // You wouldn't normally set this field
     *  firstValidRound: 1000n,
     *  validityWindow: 10,
     *  extraFee: (1000).microAlgo(),
     *  staticFee: (1000).microAlgo(),
     *  // Max fee doesn't make sense with extraFee AND staticFee
     *  //  already specified, but here for completeness
     *  maxFee: (3000).microAlgo(),
     *  rejectVersion: 1,
     *})
     * ```
     */
    addAppDeleteMethodCall(params: AppDeleteMethodCall): this;
    /**
     * Add a non-create/non-update ABI method application call transaction to the transaction group.
     *
     * Note: we recommend using app clients to make it easier to make app calls.
     * @param params The ABI method application call transaction parameters
     * @returns The composer so you can chain method calls
     * @example Basic example
     * ```typescript
     * const method = new ABIMethod({
     *   name: 'method',
     *   args: [{ name: 'arg1', type: 'string' }],
     *   returns: { type: 'string' },
     * })
     * composer.addAppCallMethodCall({ sender: 'CREATORADDRESS', method: method, args: ["arg1_value"] })
     * ```
     * @example Advanced example
     * ```typescript
     * const method = new ABIMethod({
     *   name: 'method',
     *   args: [{ name: 'arg1', type: 'string' }],
     *   returns: { type: 'string' },
     * })
     * composer.addAppCallMethodCall({
     *  sender: 'CREATORADDRESS',
     *  method: method,
     *  args: ["arg1_value"],
     *  onComplete: algosdk.OnApplicationComplete.OptInOC,
     *  args: [new Uint8Array(1, 2, 3, 4)]
     *  accountReferences: ["ACCOUNT_1"]
     *  appReferences: [123n, 1234n]
     *  assetReferences: [12345n]
     *  boxReferences: ["box1", {appId: 1234n, name: "box2"}]
     *  accessReferences: [{ appId: 1234n }]
     *  lease: 'lease',
     *  note: 'note',
     *  // You wouldn't normally set this field
     *  firstValidRound: 1000n,
     *  validityWindow: 10,
     *  extraFee: (1000).microAlgo(),
     *  staticFee: (1000).microAlgo(),
     *  // Max fee doesn't make sense with extraFee AND staticFee
     *  //  already specified, but here for completeness
     *  maxFee: (3000).microAlgo(),
     *  rejectVersion: 1,
     *})
     * ```
     */
    addAppCallMethodCall(params: AppCallMethodCall): this;
    /**
     * Add an online key registration transaction to the transaction group.
     * @param params The online key registration transaction parameters
     * @returns The composer so you can chain method calls
     * @example Basic example
     * ```typescript
     * composer.addOnlineKeyRegistration({
     *   sender: 'SENDERADDRESS',
     *   voteKey: Uint8Array.from(Buffer.from("voteKeyBase64", 'base64')),
     *   selectionKey: Uint8Array.from(Buffer.from("selectionKeyBase64", 'base64')),
     *   stateProofKey: Uint8Array.from(Buffer.from("stateProofKeyBase64", 'base64')),
     *   voteFirst: 1n,
     *   voteLast: 1000n,
     *   voteKeyDilution: 1n,
     * })
     * ```
     * @example Advanced example
     * ```typescript
     * composer.addOnlineKeyRegistration({
     *   sender: 'SENDERADDRESS',
     *   voteKey: Uint8Array.from(Buffer.from("voteKeyBase64", 'base64')),
     *   selectionKey: Uint8Array.from(Buffer.from("selectionKeyBase64", 'base64')),
     *   stateProofKey: Uint8Array.from(Buffer.from("stateProofKeyBase64", 'base64')),
     *   voteFirst: 1n,
     *   voteLast: 1000n,
     *   voteKeyDilution: 1n,
     *   lease: 'lease',
     *   note: 'note',
     *   // Use this with caution, it's generally better to use algorand.account.rekeyAccount
     *   rekeyTo: 'REKEYTOADDRESS',
     *   // You wouldn't normally set this field
     *   firstValidRound: 1000n,
     *   validityWindow: 10,
     *   extraFee: (1000).microAlgo(),
     *   staticFee: (1000).microAlgo(),
     *   // Max fee doesn't make sense with extraFee AND staticFee
     *   //  already specified, but here for completeness
     *   maxFee: (3000).microAlgo(),
     * })
     * ```
     */
    addOnlineKeyRegistration(params: OnlineKeyRegistrationParams): TransactionComposer;
    /**
     * Add an offline key registration transaction to the transaction group.
     * @param params The offline key registration transaction parameters
     * @returns The composer so you can chain method calls
     * @example Basic example
     * ```typescript
     * composer.addOfflineKeyRegistration({
     *   sender: 'SENDERADDRESS',
     * })
     * ```
     * @example Advanced example
     * ```typescript
     * composer.addOfflineKeyRegistration({
     *   sender: 'SENDERADDRESS',
     *   lease: 'lease',
     *   note: 'note',
     *   // Use this with caution, it's generally better to use algorand.account.rekeyAccount
     *   rekeyTo: 'REKEYTOADDRESS',
     *   // You wouldn't normally set this field
     *   firstValidRound: 1000n,
     *   validityWindow: 10,
     *   extraFee: (1000).microAlgo(),
     *   staticFee: (1000).microAlgo(),
     *   // Max fee doesn't make sense with extraFee AND staticFee
     *   //  already specified, but here for completeness
     *   maxFee: (3000).microAlgo(),
     * })
     * ```
     */
    addOfflineKeyRegistration(params: OfflineKeyRegistrationParams): TransactionComposer;
    /**
     * Add the transactions within an `AtomicTransactionComposer` to the transaction group.
     * @param atc The `AtomicTransactionComposer` to build transactions from and add to the group
     * @returns The composer so you can chain method calls
     * @example
     * ```typescript
     * const atc = new AtomicTransactionComposer()
     *   .addPayment({ sender: 'SENDERADDRESS', receiver: 'RECEIVERADDRESS', amount: 1000n })
     * composer.addAtc(atc)
     * ```
     */
    addAtc(atc: algosdk.AtomicTransactionComposer): TransactionComposer;
    /** Build an ATC and return transactions ready to be incorporated into a broader set of transactions this composer is composing */
    private buildAtc;
    private commonTxnBuildStep;
    /**
     * Builds an ABI method call transaction and any other associated transactions represented in the ABI args.
     * @param includeSigner Whether to include the actual signer for the transactions.
     *  If you are just building transactions without signers yet then set this to `false`.
     */
    private buildMethodCall;
    private buildPayment;
    private buildAssetCreate;
    private buildAssetConfig;
    private buildAssetDestroy;
    private buildAssetFreeze;
    private buildAssetTransfer;
    private buildAppCall;
    private buildKeyReg;
    /** Builds all transaction types apart from `txnWithSigner`, `atc` and `methodCall` since those ones can have custom signers that need to be retrieved. */
    private buildTxn;
    private buildTxnWithSigner;
    /**
     * Compose all of the transactions without signers and return the transaction objects directly along with any ABI method calls.
     *
     * @returns The array of built transactions and any corresponding method calls
     * @example
     * ```typescript
     * const { transactions, methodCalls, signers } = await composer.buildTransactions()
     * ```
     */
    buildTransactions(): Promise<BuiltTransactions>;
    /**
     * Compose all of the transactions without signers, like `buildTransactions`, but valid from `firstValidRound` to
     * `lastValidRound`: transactions that set their own `firstValidRound` or `lastValidRound` keep them, the others get
     * this window. Use this to build transactions for a simulate at past rounds, which needs them valid at those rounds
     * (a simulate at round R runs the transactions in round R + 1).
     *
     * Transactions added already built (`addTransaction`, `addAtc`) keep their own validity.
     *
     * @param validity The validity window to build with
     * @returns The built transactions, method calls and signers
     * @example
     * ```typescript
     * const { transactions } = await composer.buildTransactionsWithValidity({ firstValidRound: 1001n, lastValidRound: 1011n })
     * ```
     */
    buildTransactionsWithValidity(validity: {
        firstValidRound: bigint;
        lastValidRound: bigint;
    }): Promise<BuiltTransactions>;
    /** Runs `build` with transactions valid at the given simulate round, unless it's 0 / undefined (the latest round). */
    private withValidityForSimulateRound;
    /**
     * Get the number of transactions currently added to this composer.
     * @returns The number of transactions currently added to this composer
     */
    count(): Promise<number>;
    /**
     * Compose all of the transactions in a single atomic transaction group and an atomic transaction composer.
     *
     * You can then use the transactions standalone, or use the composer to execute or simulate the transactions.
     *
     * Once this method is called, no further transactions will be able to be added.
     * You can safely call this method multiple times to get the same result.
     * @returns The built atomic transaction composer, the transactions and any corresponding method calls
     * @example
     * ```typescript
     * const { atc, transactions, methodCalls } = await composer.build()
     * ```
     */
    build(): Promise<{
        atc: algosdk.AtomicTransactionComposer;
        transactions: algosdk.TransactionWithSigner[];
        methodCalls: any;
    }>;
    /**
     * Rebuild the group, discarding any previously built transactions.
     * This will potentially cause new signers and suggested params to be used if the callbacks return a new value compared to the first build.
     * @returns The newly built atomic transaction composer and the transactions
     * @example
     * ```typescript
     * const { atc, transactions, methodCalls } = await composer.rebuild()
     * ```
     */
    rebuild(): Promise<{
        atc: algosdk.AtomicTransactionComposer;
        transactions: algosdk.TransactionWithSigner[];
        methodCalls: any;
    }>;
    /**
     * Compose the atomic transaction group and send it to the network.
     * @param params The parameters to control execution with
     * @returns The execution result
     * @example
     * ```typescript
     * const result = await composer.send()
     * ```
     */
    send(params?: SendParams): Promise<SendAtomicTransactionComposerResults>;
    /**
     * @deprecated Use `send` instead.
     *
     * Compose the atomic transaction group and send it to the network
     *
     * An alias for `composer.send(params)`.
     * @param params The parameters to control execution with
     * @returns The execution result
     */
    execute(params?: SendParams): Promise<SendAtomicTransactionComposerResults>;
    /**
     * Compose the atomic transaction group and simulate sending it to the network
     * @returns The simulation result
     * @example
     * ```typescript
     * const result = await composer.simulate()
     * ```
     */
    simulate(): Promise<SendAtomicTransactionComposerResults & {
        simulateResponse: SimulateResponse;
    }>;
    /**
     * Compose the atomic transaction group and simulate sending it to the network
     * @returns The simulation result
     * @example
     * ```typescript
     * const result = await composer.simulate({
     *   skipSignatures: true,
     * })
     * ```
     */
    simulate(options: SkipSignaturesSimulateOptions): Promise<SendAtomicTransactionComposerResults & {
        simulateResponse: SimulateResponse;
    }>;
    /**
     * Compose the atomic transaction group and simulate sending it to the network
     * @returns The simulation result
     * @example
     * ```typescript
     * const result = await composer.simulate({
     *   extraOpcodeBudget: 1000,
     * })
     * ```
     */
    simulate(options: RawSimulateOptions): Promise<SendAtomicTransactionComposerResults & {
        simulateResponse: SimulateResponse;
    }>;
    /**
     * Create an encoded transaction note that follows the ARC-2 spec.
     *
     * https://github.com/algorandfoundation/ARCs/blob/main/ARCs/arc-0002.md
     * @param note The ARC-2 transaction note data
     * @returns The binary encoded transaction note
     */
    static arc2Note(note: Arc2TransactionNote): Uint8Array;
}
