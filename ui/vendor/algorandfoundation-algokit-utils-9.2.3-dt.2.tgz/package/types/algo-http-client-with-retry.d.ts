import { BaseHTTPClientResponse, Query, URLTokenBaseHTTPClient } from 'algosdk/client';
/** A HTTP Client that wraps the Algorand SDK HTTP Client with retries */
export declare class AlgoHttpClientWithRetry extends URLTokenBaseHTTPClient {
    private static readonly MAX_TRIES;
    private static readonly MAX_BACKOFF_MS;
    private static readonly RETRY_STATUS_CODES;
    private static readonly RETRY_ERROR_CODES;
    /** The abort signal in fetch options passed as `customOptions`, if any. */
    private static signalOf;
    /** Waits `ms`, rejecting with the signal's reason as soon as it aborts. */
    private static sleep;
    private callWithRetry;
    get(relativePath: string, query?: Query<string>, requestHeaders?: Record<string, string>, customOptions?: Record<string, unknown>): Promise<BaseHTTPClientResponse>;
    post(relativePath: string, data: Uint8Array, query?: Query<string>, requestHeaders?: Record<string, string>, customOptions?: Record<string, unknown>): Promise<BaseHTTPClientResponse>;
    delete(relativePath: string, data: Uint8Array, query?: Query<string>, requestHeaders?: Record<string, string>, customOptions?: Record<string, unknown>): Promise<BaseHTTPClientResponse>;
}
