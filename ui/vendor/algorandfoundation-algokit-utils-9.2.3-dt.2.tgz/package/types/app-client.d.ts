import algosdk, { Address } from 'algosdk';
import { TransactionSignerAccount } from './account';
import { type AlgorandClient } from './algorand-client';
import { AlgoAmount } from './amount';
import { ABIAppCallArgs, ABIReturn, AppCallArgs, AppCallTransactionResult, AppCallType, AppCompilationResult, AppMetadata, AppReference, AppReturn, AppState, AppStorageSchema, BoxName, AppLookup as LegacyAppLookup, OnSchemaBreak, OnUpdate, RawAppCallArgs, SendAppTransactionResult, TealTemplateParams } from './app';
import { ABIStruct, Arc56Contract, Arc56Method, ProgramSourceInfo } from './app-arc56';
import { AppLookup } from './app-deployer';
import { AppManager, BoxIdentifier } from './app-manager';
import { AppSpec } from './app-spec';
import { AtRoundOptions, Round } from './dt-support';
import { AppCallMethodCall, AppDeleteMethodCall, AppMethodCall, AppMethodCallTransactionArgument, CommonAppCallParams, PaymentParams } from './composer';
import { Expand } from './expand';
import { SendParams, SendTransactionFrom, SendTransactionParams, TransactionNote } from './transaction';
import ABIMethod = algosdk.ABIMethod;
import ABIMethodParams = algosdk.ABIMethodParams;
import ABIType = algosdk.ABIType;
import ABIValue = algosdk.ABIValue;
import Algodv2 = algosdk.Algodv2;
import Indexer = algosdk.Indexer;
import OnApplicationComplete = algosdk.OnApplicationComplete;
import SourceMap = algosdk.ProgramSourceMap;
import SuggestedParams = algosdk.SuggestedParams;
import TransactionSigner = algosdk.TransactionSigner;
/** Configuration to resolve app by creator and name `getCreatorAppsByName` */
export type ResolveAppByCreatorAndNameBase = {
    /** The address of the app creator account to resolve the app by */
    creatorAddress: Address | string;
    /** The optional name override to resolve the app by within the creator account (default: uses the name in the ABI contract) */
    name?: string;
    /** The mechanism to find an existing app instance metadata for the given creator and name; either:
     *  * An indexer instance to search the creator account apps; or
     *  * The cached value of the existing apps for the given creator from `getCreatorAppsByName`
     */
    findExistingUsing: Indexer | LegacyAppLookup;
};
/** Configuration to resolve app by creator and name `getCreatorAppsByName` */
export type ResolveAppByCreatorAndName = ResolveAppByCreatorAndNameBase & {
    /** How the app ID is resolved, either by `'id'` or `'creatorAndName'`; must be `'creatorAndName'` if you want to use `deploy` */
    resolveBy: 'creatorAndName';
};
/** Configuration to resolve app by ID */
export interface ResolveAppByIdBase {
    /** The id of an existing app to call using this client, or 0 if the app hasn't been created yet */
    id: number | bigint;
    /** The optional name to use to mark the app when deploying `ApplicationClient.deploy` (default: uses the name in the ABI contract) */
    name?: string;
}
export interface ResolveAppById extends ResolveAppByIdBase {
    /** How the app ID is resolved, either by `'id'` or `'creatorAndName'`; must be `'creatorAndName'` if you want to use `deploy` */
    resolveBy: 'id';
}
/** The details of an AlgoKit Utils deployed app */
export type AppDetailsBase = {
    /** Default sender to use for transactions issued by this application client */
    sender?: SendTransactionFrom;
    /** Default suggested params object to use */
    params?: SuggestedParams;
    /** Optionally provide any deploy-time parameters to replace in the TEAL code; if specified here will get
     * used in calls to `deploy`, `create` and `update` unless overridden in those calls
     */
    deployTimeParams?: TealTemplateParams;
};
/** The details of an AlgoKit Utils deployed app */
export type AppDetails = AppDetailsBase & (ResolveAppById | ResolveAppByCreatorAndName);
/** The details of an ARC-0032 app spec specified, AlgoKit Utils deployed app */
export type AppSpecAppDetailsBase = {
    /** The ARC-0032 application spec as either:
     *  * Parsed JSON `AppSpec`
     *  * Raw JSON string
     */
    app: AppSpec | string;
};
/** The details of an ARC-0032 app spec specified, AlgoKit Utils deployed app by id*/
export type AppSpecAppDetailsById = AppSpecAppDetailsBase & AppDetailsBase & ResolveAppByIdBase;
/** The details of an ARC-0032 app spec specified, AlgoKit Utils deployed app by creator and name*/
export type AppSpecAppDetailsByCreatorAndName = AppSpecAppDetailsBase & AppDetailsBase & ResolveAppByCreatorAndNameBase;
/** The details of an ARC-0032 app spec specified, AlgoKit Utils deployed app */
export type AppSpecAppDetails = AppSpecAppDetailsBase & AppDetails;
/** Core parameters to pass into ApplicationClient.deploy */
export interface AppClientDeployCoreParams {
    /** The version of the contract, uses "1.0" by default */
    version?: string;
    /** The optional sender to send the transaction from, will use the application client's default sender by default if specified */
    sender?: SendTransactionFrom;
    /** Parameters to control transaction sending */
    sendParams?: Omit<SendTransactionParams, 'skipSending' | 'skipWaiting'>;
    /** Whether or not to allow updates in the contract using the deploy-time updatability control if present in your contract.
     * If this is not specified then it will automatically be determined based on the AppSpec definition
     **/
    allowUpdate?: boolean;
    /** Whether or not to allow deletes in the contract using the deploy-time deletability control if present in your contract.
     * If this is not specified then it will automatically be determined based on the AppSpec definition
     **/
    allowDelete?: boolean;
    /** What action to perform if a schema break is detected */
    onSchemaBreak?: 'replace' | 'fail' | 'append' | OnSchemaBreak;
    /** What action to perform if a TEAL update is detected */
    onUpdate?: 'update' | 'replace' | 'append' | 'fail' | OnUpdate;
}
/** Call interface parameters to pass into ApplicationClient.deploy */
export interface AppClientDeployCallInterfaceParams {
    /** Any deploy-time parameters to replace in the TEAL code */
    deployTimeParams?: TealTemplateParams;
    /** Any args to pass to any create transaction that is issued as part of deployment */
    createArgs?: AppClientCallArgs;
    /** Override the on-completion action for the create call; defaults to NoOp */
    createOnCompleteAction?: Exclude<AppCallType, 'clear_state'> | Exclude<OnApplicationComplete, OnApplicationComplete.ClearStateOC>;
    /** Any args to pass to any update transaction that is issued as part of deployment */
    updateArgs?: AppClientCallArgs;
    /** Any args to pass to any delete transaction that is issued as part of deployment */
    deleteArgs?: AppClientCallArgs;
}
/** Parameters to pass into ApplicationClient.deploy */
export interface AppClientDeployParams extends AppClientDeployCoreParams, AppClientDeployCallInterfaceParams {
    /** Any overrides for the storage schema to request for the created app; by default the schema indicated by the app spec is used. */
    schema?: Partial<AppStorageSchema>;
}
export type AppClientCallRawArgs = RawAppCallArgs;
export interface AppClientCallABIArgs extends Omit<ABIAppCallArgs, 'method'> {
    /** If calling an ABI method then either the name of the method, or the ABI signature */
    method: string;
}
/** The arguments to pass to an Application Client smart contract call */
export type AppClientCallArgs = AppClientCallRawArgs | AppClientCallABIArgs;
/** Common (core) parameters to construct a ApplicationClient contract call */
export interface AppClientCallCoreParams {
    /** The optional sender to send the transaction from, will use the application client's default sender by default if specified */
    sender?: SendTransactionFrom;
    /** The transaction note for the smart contract call */
    note?: TransactionNote;
    /** Parameters to control transaction sending */
    sendParams?: SendTransactionParams;
}
/** Parameters to construct a ApplicationClient contract call */
export type AppClientCallParams = AppClientCallArgs & AppClientCallCoreParams;
/** Parameters to construct a ApplicationClient clear state contract call */
export type AppClientClearStateParams = AppClientCallRawArgs & AppClientCallCoreParams;
export interface AppClientCompilationParams {
    /** Any deploy-time parameters to replace in the TEAL code */
    deployTimeParams?: TealTemplateParams;
    /** Whether or not the contract should have deploy-time immutability control set, undefined = ignore */
    updatable?: boolean;
    /** Whether or not the contract should have deploy-time permanence control set, undefined = ignore */
    deletable?: boolean;
}
/** On-complete action parameter for creating a contract using ApplicationClient */
export type AppClientCreateOnComplete = {
    /** Override the on-completion action for the create call; defaults to NoOp */
    onCompleteAction?: Exclude<AppCallType, 'clear_state'> | Exclude<OnApplicationComplete, OnApplicationComplete.ClearStateOC>;
};
/** Parameters for creating a contract using ApplicationClient */
export type AppClientCreateParams = AppClientCallParams & AppClientCompilationParams & AppClientCreateOnComplete & {
    /** Any overrides for the storage schema to request for the created app; by default the schema indicated by the app spec is used. */
    schema?: Partial<AppStorageSchema>;
};
/** Parameters for updating a contract using ApplicationClient */
export type AppClientUpdateParams = AppClientCallParams & AppClientCompilationParams;
/** Parameters for funding an app account */
export interface FundAppAccountParams {
    amount: AlgoAmount;
    /** The optional sender to send the transaction from, will use the application client's default sender by default if specified */
    sender?: SendTransactionFrom;
    /** The transaction note for the smart contract call */
    note?: TransactionNote;
    /** Parameters to control transaction sending */
    sendParams?: SendTransactionParams;
}
/** Source maps for an Algorand app */
export interface AppSourceMaps {
    /** The source map of the approval program */
    approvalSourceMap: SourceMapExport;
    /** The source map of the clear program */
    clearSourceMap: SourceMapExport;
}
export interface SourceMapExport {
    version: number;
    sources: string[];
    names: string[];
    mappings: string;
}
/**
 * The result of asking an `AppClient` to compile a program.
 *
 * Always contains the compiled bytecode, and may contain the result of compiling TEAL (including sourcemap) if it was available.
 */
export interface AppClientCompilationResult extends Partial<AppCompilationResult> {
    /** The compiled bytecode of the approval program, ready to deploy to algod */
    approvalProgram: Uint8Array;
    /** The compiled bytecode of the clear state program, ready to deploy to algod */
    clearStateProgram: Uint8Array;
}
/** Parameters to create an app client */
export interface AppClientParams {
    /** The ID of the app instance this client should make calls against. */
    appId: bigint;
    /** The ARC-56 or ARC-32 application spec as either:
     *  * Parsed JSON ARC-56 `Contract`
     *  * Parsed JSON ARC-32 `AppSpec`
     *  * Raw JSON string (in either ARC-56 or ARC-32 format)
     */
    appSpec: Arc56Contract | AppSpec | string;
    /** An `AlgorandClient` instance */
    algorand: AlgorandClient;
    /**
     * Optional override for the app name; used for on-chain metadata and lookups.
     * Defaults to the ARC-32/ARC-56 app spec name
     */
    appName?: string;
    /** Optional address to use for the account to use as the default sender for calls. */
    defaultSender?: Address | string;
    /** Optional signer to use as the default signer for default sender calls (if not specified then the signer will be resolved from `AlgorandClient`). */
    defaultSigner?: TransactionSigner;
    /** Optional source map for the approval program */
    approvalSourceMap?: SourceMap;
    /** Optional source map for the clear state program */
    clearSourceMap?: SourceMap;
    /**
     * Optional round to pin the client to (needs dtalgod time travel): state reads (`state.*`, `getGlobalState`,
     * `getBoxValue`, ...) read the state as of the end of this round, and readonly ABI calls are simulated at this round.
     * A pinned client can't send transactions. See `AppClient.atRound`.
     */
    round?: Round;
}
/** Parameters to clone an app client */
export type CloneAppClientParams = Expand<Partial<Omit<AppClientParams, 'algorand' | 'appSpec'>>>;
/** onComplete parameter for a non-update app call */
export type CallOnComplete = {
    /** On-complete of the call; defaults to no-op */
    onComplete?: Exclude<OnApplicationComplete, OnApplicationComplete.UpdateApplicationOC>;
};
/** AppClient common parameters for a bare app call */
export type AppClientBareCallParams = Expand<Omit<CommonAppCallParams, 'appId' | 'sender' | 'onComplete'> & {
    /** The address of the account sending the transaction, if undefined then the app client's defaultSender is used. */
    sender?: Address | string;
}>;
/** AppClient common parameters for an ABI method call */
export type AppClientMethodCallParams = Expand<Omit<CommonAppCallParams, 'appId' | 'sender' | 'method' | 'args'> & {
    /** The address of the account sending the transaction, if undefined then the app client's defaultSender is used. */
    sender?: Address | string;
    /** The method name or method signature to call if an ABI call is being emitted
     * @example Method name
     * `my_method`
     * @example Method signature
     * `my_method(unit64,string)bytes`
     */
    method: string;
    /** Arguments to the ABI method, either:
     * * An ABI value
     * * An ARC-56 struct
     * * A transaction with explicit signer
     * * A transaction (where the signer will be automatically assigned)
     * * An unawaited transaction (e.g. from algorand.createTransaction.transactionType())
     * * Another method call (via method call params object)
     * * undefined (this represents a placeholder for either a default argument or a transaction argument that is fulfilled by another method call argument)
     */
    args?: (ABIValue | ABIStruct | AppMethodCallTransactionArgument | undefined)[];
}>;
/** Parameters for funding an app account */
export type FundAppParams = Expand<Omit<PaymentParams, 'receiver' | 'sender'> & SendParams & {
    /** The optional sender to send the transaction from, will use the application client's default sender by default if specified */
    sender?: Address | string;
}>;
/** Resolve an app client instance by looking up an app created by the given creator with the given name */
export type ResolveAppClientByCreatorAndName = Expand<Omit<AppClientParams, 'appId'> & {
    /** The address of the creator account for the app */
    creatorAddress: Address | string;
    /** An optional cached app lookup that matches a name to on-chain details;
     * either this is needed or indexer is required to be passed in to this `ClientManager` on construction.
     */
    appLookupCache?: AppLookup;
    /** Whether or not to ignore the `AppDeployer` lookup cache and force an on-chain lookup, default: use any cached value */
    ignoreCache?: boolean;
}>;
/** Resolve an app client instance by looking up the current network. */
export type ResolveAppClientByNetwork = Expand<Omit<AppClientParams, 'appId'>>;
/** ARC-56/ARC-32 application client that allows you to manage calls and
 * state for a specific deployed instance of an app (with a known app ID). */
export declare class AppClient {
    private _appId;
    private _appAddress;
    private _appName;
    private _appSpec;
    private _algorand;
    private _defaultSender?;
    private _defaultSigner?;
    private _round?;
    private _approvalSourceMap;
    private _clearSourceMap;
    private _localStateMethods;
    private _globalStateMethods;
    private _boxStateMethods;
    private _paramsMethods;
    private _createTransactionsMethods;
    private _sendMethods;
    private _lastCompiled;
    /**
     * Create a new app client.
     * @param params The parameters to create the app client
     * @returns The `AppClient` instance
     * @example
     * ```typescript
     * const appClient = new AppClient({
     *   appId: 12345678n,
     *   appSpec: appSpec,
     *   algorand: AlgorandClient.mainNet(),
     * })
     */
    constructor(params: AppClientParams);
    /** Wraps send methods so that they throw on a client pinned to a round, except the `allowed` ones, which check themselves. */
    private guardPinnedSends;
    private assertNotPinned;
    /** The round reads use: the one in `options`, else the round this client is pinned to, if any. */
    private readOptions;
    /**
     * The round this client is pinned to, if any (see `atRound`).
     */
    get round(): bigint | undefined;
    /**
     * Returns a clone of this app client pinned to a past round (needs dtalgod time travel and the time-travel fork of
     * algosdk): state reads (`state.global|local|box`, `getGlobalState`, `getBoxValue`, ...) read the state as of the end
     * of that round, and readonly ABI calls are simulated at that round. The pinned client can't send transactions.
     *
     * Generated typed clients take an `AppClient`, so `new MyAppClient(myAppClient.appClient.atRound(round))` gives
     * typed state and readonly calls at that round.
     *
     * @param round The round to pin to, or `undefined` for a client that reads the latest state
     * @returns The pinned app client
     * @example
     * ```typescript
     * const past = appClient.atRound(45_000_000n)
     * const counter = await past.state.global.getValue('counter')
     * const result = await past.send.call({ method: 'get_counter' })
     * ```
     */
    atRound(round: Round | undefined): AppClient;
    /**
     * Clone this app client with different params
     *
     * @param params The params to use for the the cloned app client. Omit a param to keep the original value. Set a param to override the original value. Setting to undefined will clear the original value.
     * @returns A new app client with the altered params
     * @example
     * ```typescript
     * const appClient2 = appClient.clone({ defaultSender: 'NEW_SENDER_ADDRESS' })
     * ```
     */
    clone(params: CloneAppClientParams): AppClient;
    /**
     * Returns a new `AppClient` client, resolving the app by creator address and name
     * using AlgoKit app deployment semantics (i.e. looking for the app creation transaction note).
     * @param params The parameters to create the app client
     * @returns The `AppClient` instance
     * @example
     * ```typescript
     * const appClient = await AppClient.fromCreatorAndName({
     *   creatorAddress: 'CREATOR_ADDRESS',
     *   name: 'APP_NAME',
     *   appSpec: appSpec,
     *   algorand: AlgorandClient.mainNet(),
     * })
     */
    static fromCreatorAndName(params: ResolveAppClientByCreatorAndName): Promise<AppClient>;
    /**
     * Returns an `AppClient` instance for the current network based on
     * pre-determined network-specific app IDs specified in the ARC-56 app spec.
     *
     * If no IDs are in the app spec or the network isn't recognised, an error is thrown.
     * @param params The parameters to create the app client
     * @returns The `AppClient` instance
     * @example
     * ```typescript
     * const appClient = await AppClient.fromNetwork({
     *   appSpec: appSpec,
     *   algorand: AlgorandClient.mainNet(),
     * })
     */
    static fromNetwork(params: ResolveAppClientByNetwork): Promise<AppClient>;
    /**
     * Takes a string or parsed JSON object that could be ARC-32 or ARC-56 format and
     * normalises it into a parsed ARC-56 contract object.
     * @param spec The spec to normalise
     * @returns The normalised ARC-56 contract object
     * @example
     * ```typescript
     * const arc56AppSpec = AppClient.normaliseAppSpec(appSpec)
     * ```
     */
    static normaliseAppSpec(spec: Arc56Contract | AppSpec | string): Arc56Contract;
    /** The ID of the app instance this client is linked to. */
    get appId(): bigint;
    /** The app address of the app instance this client is linked to. */
    get appAddress(): algosdk.Address;
    /** The name of the app (from the ARC-32 / ARC-56 app spec or override). */
    get appName(): string;
    /** The ARC-56 app spec being used */
    get appSpec(): Arc56Contract;
    /** A reference to the underlying `AlgorandClient` this app client is using. */
    get algorand(): AlgorandClient;
    /** Get parameters to create transactions for the current app.
     *
     * A good mental model for this is that these parameters represent a deferred transaction creation.
     * @example Create a transaction in the future using Algorand Client
     * ```typescript
     * const myMethodCall = appClient.params.call({method: 'my_method', args: [123, 'hello']})
     * // ...
     * await algorand.send.AppMethodCall(myMethodCall)
     * ```
     * @example Define a nested transaction as an ABI argument
     * ```typescript
     * const myMethodCall = appClient.params.call({method: 'my_method', args: [123, 'hello']})
     * await appClient.send.call({method: 'my_method2', args: [myMethodCall]})
     * ```
     */
    get params(): {
        /**
         * Return params for a payment transaction to fund the app account
         * @param params The parameters for the fund app accont payment transaction
         * @returns The parameters which can be used to create a fund app account payment transaction
         */
        fundAppAccount: (params: FundAppParams) => {
            sender: algosdk.Address;
            signer: algosdk.TransactionSigner | TransactionSignerAccount | undefined;
            receiver: algosdk.Address;
            maxFee?: AlgoAmount | undefined;
            note?: (Uint8Array | string) | undefined;
            lease?: (Uint8Array | string) | undefined;
            rekeyTo?: (string | Address) | undefined;
            staticFee?: AlgoAmount | undefined;
            extraFee?: AlgoAmount | undefined;
            validityWindow?: number | bigint | undefined;
            firstValidRound?: bigint | undefined;
            lastValidRound?: bigint | undefined;
            amount: AlgoAmount;
            closeRemainderTo?: (string | Address) | undefined;
            maxRoundsToWaitForConfirmation?: number | undefined;
            suppressLog?: boolean | undefined;
            populateAppCallResources?: boolean | undefined;
            coverAppCallInnerTransactionFees?: boolean | undefined;
        };
        /**
         * Return params for an update ABI call, including deploy-time TEAL template replacements and compilation if provided
         * @param params The parameters for the update ABI method call
         * @returns The parameters which can be used to create an update ABI method call
         */
        update: (params: AppClientMethodCallParams & AppClientCompilationParams) => Promise<{
            /** The compiled bytecode of the approval program, ready to deploy to algod */
            approvalProgram: Uint8Array;
            /** The compiled bytecode of the clear state program, ready to deploy to algod */
            clearStateProgram: Uint8Array;
            compiledApproval?: import("./app").CompiledTeal | undefined;
            compiledClear?: import("./app").CompiledTeal | undefined;
            maxFee?: AlgoAmount | undefined;
            note?: (Uint8Array | string) | undefined;
            signer?: (algosdk.TransactionSigner | TransactionSignerAccount) | undefined;
            onComplete?: algosdk.OnApplicationComplete | undefined;
            rejectVersion?: number | undefined;
            lease?: (Uint8Array | string) | undefined;
            rekeyTo?: (string | Address) | undefined;
            staticFee?: AlgoAmount | undefined;
            extraFee?: AlgoAmount | undefined;
            validityWindow?: number | bigint | undefined;
            firstValidRound?: bigint | undefined;
            lastValidRound?: bigint | undefined;
            accountReferences?: (string | Address)[] | undefined;
            appReferences?: bigint[] | undefined;
            assetReferences?: bigint[] | undefined;
            boxReferences?: (import("./app-manager").BoxReference | BoxIdentifier)[];
            accessReferences?: import("./app-manager").ResourceReference[] | undefined;
            sender?: (Address | string) | undefined;
            method: string;
            args?: (ABIValue | ABIStruct | AppMethodCallTransactionArgument | undefined)[];
            /** Any deploy-time parameters to replace in the TEAL code */
            deployTimeParams?: TealTemplateParams;
            /** Whether or not the contract should have deploy-time immutability control set, undefined = ignore */
            updatable?: boolean;
            /** Whether or not the contract should have deploy-time permanence control set, undefined = ignore */
            deletable?: boolean;
        } & {
            appId: bigint;
            sender: algosdk.Address;
            signer: algosdk.TransactionSigner | TransactionSignerAccount | undefined;
            method: Arc56Method;
            onComplete: algosdk.OnApplicationComplete.UpdateApplicationOC;
            args: (algosdk.Transaction | algosdk.ABIValue | algosdk.TransactionWithSigner | Promise<algosdk.Transaction> | AppMethodCall<{
                sender: string | Address;
                maxFee?: AlgoAmount | undefined;
                note?: (Uint8Array | string) | undefined;
                args?: Uint8Array[] | undefined;
                signer?: (algosdk.TransactionSigner | TransactionSignerAccount) | undefined;
                onComplete?: algosdk.OnApplicationComplete.NoOpOC | algosdk.OnApplicationComplete.OptInOC | algosdk.OnApplicationComplete.CloseOutOC | algosdk.OnApplicationComplete.UpdateApplicationOC | algosdk.OnApplicationComplete.DeleteApplicationOC | undefined;
                rejectVersion?: number | undefined;
                lease?: (Uint8Array | string) | undefined;
                rekeyTo?: (string | Address) | undefined;
                staticFee?: AlgoAmount | undefined;
                extraFee?: AlgoAmount | undefined;
                validityWindow?: number | bigint | undefined;
                firstValidRound?: bigint | undefined;
                lastValidRound?: bigint | undefined;
                accountReferences?: (string | Address)[] | undefined;
                appReferences?: bigint[] | undefined;
                assetReferences?: bigint[] | undefined;
                boxReferences?: (import("./app-manager").BoxReference | BoxIdentifier)[] | undefined;
                accessReferences?: import("./app-manager").ResourceReference[] | undefined;
                approvalProgram: string | Uint8Array;
                clearStateProgram: string | Uint8Array;
                schema?: {
                    globalInts: number;
                    globalByteSlices: number;
                    localInts: number;
                    localByteSlices: number;
                } | undefined;
                extraProgramPages?: number | undefined;
            }> | AppMethodCall<{
                sender: string | Address;
                signer?: (algosdk.TransactionSigner | TransactionSignerAccount) | undefined;
                rekeyTo?: (string | Address) | undefined;
                note?: (Uint8Array | string) | undefined;
                lease?: (Uint8Array | string) | undefined;
                staticFee?: AlgoAmount | undefined;
                extraFee?: AlgoAmount | undefined;
                maxFee?: AlgoAmount | undefined;
                validityWindow?: number | bigint | undefined;
                firstValidRound?: bigint | undefined;
                lastValidRound?: bigint | undefined;
                appId: bigint;
                onComplete?: algosdk.OnApplicationComplete.UpdateApplicationOC | undefined;
                args?: Uint8Array[] | undefined;
                accountReferences?: (string | Address)[] | undefined;
                appReferences?: bigint[] | undefined;
                assetReferences?: bigint[] | undefined;
                boxReferences?: (import("./app-manager").BoxReference | BoxIdentifier)[] | undefined;
                accessReferences?: import("./app-manager").ResourceReference[] | undefined;
                rejectVersion?: number | undefined;
                approvalProgram: string | Uint8Array;
                clearStateProgram: string | Uint8Array;
            }> | AppMethodCall<import("./composer").AppMethodCallParams> | undefined)[] | undefined;
        }>;
        /**
         * Return params for an opt-in ABI call
         * @param params The parameters for the opt-in ABI method call
         * @returns The parameters which can be used to create an opt-in ABI method call
         */
        optIn: (params: AppClientMethodCallParams) => Promise<AppCallMethodCall>;
        /**
         * Return params for an delete ABI call
         * @param params The parameters for the delete ABI method call
         * @returns The parameters which can be used to create a delete ABI method call
         */
        delete: (params: AppClientMethodCallParams) => Promise<AppDeleteMethodCall>;
        /** Return params for an close out ABI call
         * @param params The parameters for the close out ABI method call
         * @returns The parameters which can be used to create a close out ABI method call
         */
        closeOut: (params: AppClientMethodCallParams) => Promise<AppCallMethodCall>;
        /** Return params for an ABI call
         * @param params The parameters for the ABI method call
         * @returns The parameters which can be used to create an ABI method call
         */
        call: (params: AppClientMethodCallParams & CallOnComplete) => Promise<AppCallMethodCall>;
    } & {
        /** Interact with bare (raw) call parameters */ bare: ReturnType<AppClient["getBareParamsMethods"]>;
    };
    /** Create transactions for the current app */
    get createTransaction(): {
        /** Return transaction for a payment transaction to fund the app account
         * @param params The parameters for the fund app account payment transaction
         * @returns A transaction which can be used to fund the app account
         */
        fundAppAccount: (params: FundAppParams) => Promise<algosdk.Transaction>;
        /**
         * Return transactions for an update ABI call, including deploy-time TEAL template replacements and compilation if provided
         * @param params The parameters for the update ABI method call
         * @returns The transactions which can be used to create an update ABI method call
         */
        update: (params: AppClientMethodCallParams & AppClientCompilationParams) => Promise<{
            transactions: algosdk.Transaction[];
            methodCalls: Map<number, algosdk.ABIMethod>;
            signers: Map<number, algosdk.TransactionSigner>;
        }>;
        /**
         * Return transactions for an opt-in ABI call
         * @param params The parameters for the opt-in ABI method call
         * @returns The transactions which can be used to create an opt-in ABI method call
         */
        optIn: (params: AppClientMethodCallParams) => Promise<{
            transactions: algosdk.Transaction[];
            methodCalls: Map<number, algosdk.ABIMethod>;
            signers: Map<number, algosdk.TransactionSigner>;
        }>;
        /**
         * Return transactions for a delete ABI call
         * @param params The parameters for the delete ABI method call
         * @returns The transactions which can be used to create a delete ABI method call
         */
        delete: (params: AppClientMethodCallParams) => Promise<{
            transactions: algosdk.Transaction[];
            methodCalls: Map<number, algosdk.ABIMethod>;
            signers: Map<number, algosdk.TransactionSigner>;
        }>;
        /**
         * Return transactions for a close out ABI call
         * @param params The parameters for the close out ABI method call
         * @returns The transactions which can be used to create a close out ABI method call
         */
        closeOut: (params: AppClientMethodCallParams) => Promise<{
            transactions: algosdk.Transaction[];
            methodCalls: Map<number, algosdk.ABIMethod>;
            signers: Map<number, algosdk.TransactionSigner>;
        }>;
        /**
         * Return transactions for an ABI call (defaults to no-op)
         * @param params The parameters for the ABI method call
         * @returns The transactions which can be used to create an ABI method call
         */
        call: (params: AppClientMethodCallParams & CallOnComplete) => Promise<{
            transactions: algosdk.Transaction[];
            methodCalls: Map<number, algosdk.ABIMethod>;
            signers: Map<number, algosdk.TransactionSigner>;
        }>;
    } & {
        /** Interact with bare (raw) call transactions */ bare: ReturnType<AppClient["getBareCreateTransactionMethods"]>;
    };
    /** Send transactions to the current app */
    get send(): {
        /** Sign and send transactions for a payment transaction to fund the app account
         * @param params The parameters for the fund app account payment transaction
         * @returns The result of send the fund app account payment transaction
         */
        fundAppAccount: (params: FundAppParams & SendParams) => Promise<{
            groupId: string;
            txIds: string[];
            returns?: ABIReturn[] | undefined;
            confirmations: algosdk.modelsv2.PendingTransactionResponse[];
            transactions: algosdk.Transaction[];
            confirmation: algosdk.modelsv2.PendingTransactionResponse;
            transaction: algosdk.Transaction;
        }>;
        /**
         * Sign and send transactions for an update ABI call, including deploy-time TEAL template replacements and compilation if provided
         * @param params The parameters for the update ABI method call
         * @returns The result of sending the update ABI method call
         */
        update: (params: AppClientMethodCallParams & AppClientCompilationParams & SendParams) => Promise<{
            compiledApproval?: import("./app").CompiledTeal | undefined;
            compiledClear?: import("./app").CompiledTeal | undefined;
            groupId: string;
            txIds: string[];
            returns?: ABIReturn[] | undefined;
            confirmations: algosdk.modelsv2.PendingTransactionResponse[];
            transactions: algosdk.Transaction[];
            confirmation: algosdk.modelsv2.PendingTransactionResponse;
            transaction: algosdk.Transaction;
            return?: Uint8Array<ArrayBufferLike> | algosdk.ABIValue | ABIStruct | undefined;
        }>;
        /**
         * Sign and send transactions for an opt-in ABI call
         * @param params The parameters for the opt-in ABI method call
         * @returns The result of sending the opt-in ABI method call
         */
        optIn: (params: AppClientMethodCallParams & SendParams) => Promise<Omit<{
            groupId: string;
            txIds: string[];
            returns?: ABIReturn[] | undefined;
            confirmations: algosdk.modelsv2.PendingTransactionResponse[];
            transactions: algosdk.Transaction[];
            confirmation: algosdk.modelsv2.PendingTransactionResponse;
            transaction: algosdk.Transaction;
            return?: ABIReturn | undefined;
        }, "return"> & AppReturn<Uint8Array<ArrayBufferLike> | algosdk.ABIValue | ABIStruct | undefined>>;
        /**
         * Sign and send transactions for a delete ABI call
         * @param params The parameters for the delete ABI method call
         * @returns The result of sending the delete ABI method call
         */
        delete: (params: AppClientMethodCallParams & SendParams) => Promise<Omit<{
            groupId: string;
            txIds: string[];
            returns?: ABIReturn[] | undefined;
            confirmations: algosdk.modelsv2.PendingTransactionResponse[];
            transactions: algosdk.Transaction[];
            confirmation: algosdk.modelsv2.PendingTransactionResponse;
            transaction: algosdk.Transaction;
            return?: ABIReturn | undefined;
        }, "return"> & AppReturn<Uint8Array<ArrayBufferLike> | algosdk.ABIValue | ABIStruct | undefined>>;
        /**
         * Sign and send transactions for a close out ABI call
         * @param params The parameters for the close out ABI method call
         * @returns The result of sending the close out ABI method call
         */
        closeOut: (params: AppClientMethodCallParams & SendParams) => Promise<Omit<{
            groupId: string;
            txIds: string[];
            returns?: ABIReturn[] | undefined;
            confirmations: algosdk.modelsv2.PendingTransactionResponse[];
            transactions: algosdk.Transaction[];
            confirmation: algosdk.modelsv2.PendingTransactionResponse;
            transaction: algosdk.Transaction;
            return?: ABIReturn | undefined;
        }, "return"> & AppReturn<Uint8Array<ArrayBufferLike> | algosdk.ABIValue | ABIStruct | undefined>>;
        /**
         * Sign and send transactions for a call (defaults to no-op)
         * @param params The parameters for the ABI method call
         * @returns The result of sending the ABI method call
         */
        call: (params: AppClientMethodCallParams & CallOnComplete & SendParams) => Promise<Omit<{
            groupId: string;
            txIds: string[];
            returns?: ABIReturn[] | undefined;
            confirmations: algosdk.modelsv2.PendingTransactionResponse[];
            transactions: algosdk.Transaction[];
            confirmation: algosdk.modelsv2.PendingTransactionResponse;
            transaction: algosdk.Transaction;
            return?: ABIReturn | undefined;
        }, "return"> & AppReturn<Uint8Array<ArrayBufferLike> | algosdk.ABIValue | ABIStruct | undefined>>;
    } & {
        /** Interact with bare (raw) calls */ bare: ReturnType<AppClient["getBareSendMethods"]>;
    };
    /** Get state (local, global, box) from the current app */
    get state(): {
        /**
         * Methods to access local state for the current app
         * @param address The address of the account to get the local state for
         */
        local: (address: string | Address) => ReturnType<AppClient["getStateMethods"]>;
        /**
         * Methods to access global state for the current app
         */
        global: {
            /**
             * Returns all single-key state values in a record keyed by the key name and the value a decoded ABI value.
             */
            getAll: () => Promise<Record<string, any>>;
            /**
             * Returns a single state value for the current app with the value a decoded ABI value.
             * @param name The name of the state value to retrieve the value for
             * @param appState Optional cached value of the current state
             * @returns
             */
            getValue: (name: string, appState?: AppState) => Promise<algosdk.ABIValue | ABIStruct | undefined>;
            /**
             * Returns a single value from the given map for the current app with the value a decoded ABI value.
             * @param mapName The name of the map to read from
             * @param key The key within the map (without any map prefix) as either a Buffer with the bytes or a value
             *  that will be converted to bytes by encoding it using the specified ABI key type
             *  in the ARC-56 spec
             * @param appState Optional cached value of the current state
             */
            getMapValue: (mapName: string, key: Uint8Array | any, appState?: AppState) => Promise<algosdk.ABIValue | ABIStruct | undefined>;
            /**
             * Returns all map values for the given map.
             * @param mapName The name of the map to read from
             * @param appState Optional cached value of the current state
             * @returns A map of all key-value pairs in the map as a `Record<string, ABIValue>`
             */
            getMap: (mapName: string) => Promise<Map<algosdk.ABIValue | ABIStruct, algosdk.ABIValue | ABIStruct>>;
        };
        /**
         * Methods to access box storage for the current app
         */
        box: {
            /**
             * Returns all single-key state values in a record keyed by the key name and the value a decoded ABI value.
             */
            getAll: () => Promise<Record<string, any>>;
            /**
             * Returns a single state value for the current app with the value a decoded ABI value.
             * @param name The name of the state value to retrieve the value for
             * @returns
             */
            getValue: (name: string) => Promise<algosdk.ABIValue | ABIStruct>;
            /**
             *
             * @param mapName The name of the map to read from
             * @param key The key within the map (without any map prefix) as either a Buffer with the bytes or a value
             *  that will be converted to bytes by encoding it using the specified ABI key type
             *  in the ARC-56 spec
             */
            getMapValue: (mapName: string, key: Uint8Array | any) => Promise<algosdk.ABIValue | ABIStruct>;
            /**
             *
             * @param mapName The name of the map to read from
             * @param key The key within the map as either a Buffer with the bytes or a value
             *  that will be converted to bytes by encoding it using the specified ABI key type
             *  in the ARC-56 spec
             * @param appState
             */
            getMap: (mapName: string) => Promise<Map<algosdk.ABIValue | ABIStruct, algosdk.ABIValue | ABIStruct>>;
        };
    };
    /**
     * Funds Algo into the app account for this app.
     *
     * An alias for `appClient.send.fundAppAccount(params)`.
     * @param params The parameters for the funding transaction
     * @returns The result of the funding
     * @example
     * ```typescript
     * await appClient.fundAppAccount({ amount: algo(1) })
     * ```
     */
    fundAppAccount(params: FundAppParams): Promise<{
        groupId: string;
        txIds: string[];
        returns?: ABIReturn[] | undefined;
        confirmations: algosdk.modelsv2.PendingTransactionResponse[];
        transactions: algosdk.Transaction[];
        confirmation: algosdk.modelsv2.PendingTransactionResponse;
        transaction: algosdk.Transaction;
    }>;
    /**
     * Returns raw global state for the current app.
     * @returns The global state
     * @example
     * ```typescript
     * const globalState = await appClient.getGlobalState()
     * ```
     * @param options Optional `round` to read the state as of the end of a past round (defaults to the client's pinned round, if any)
     */
    getGlobalState(options?: AtRoundOptions): Promise<AppState>;
    /**
     * Returns raw local state for the given account address.
     * @param address The address of the account to get the local state for
     * @param options Optional `round` to read the state as of the end of a past round (defaults to the client's pinned round, if any)
     * @returns The local state
     * @example
     * ```typescript
     * const localState = await appClient.getLocalState('ACCOUNT_ADDRESS')
     * ```
     */
    getLocalState(address: Address | string, options?: AtRoundOptions): Promise<AppState>;
    /**
     * Returns the names of all current boxes for the current app.
     * @returns The names of the boxes
     * @example
     * ```typescript
     * const boxNames = await appClient.getBoxNames()
     * ```
     * @param options Optional `round` to list the boxes as of the end of a past round (defaults to the client's pinned round, if any)
     */
    getBoxNames(options?: AtRoundOptions): Promise<BoxName[]>;
    /**
     * Returns the value of the given box for the current app.
     * @param name The identifier of the box to return
     * @param options Optional `round` to read the box as of the end of a past round (defaults to the client's pinned round, if any)
     * @returns The current box value as a byte array
     * @example
     * ```typescript
     * const boxValue = await appClient.getBoxValue('boxName')
     * ```
     */
    getBoxValue(name: BoxIdentifier, options?: AtRoundOptions): Promise<Uint8Array>;
    /**
     * Returns the value of the given box for the current app.
     * @param name The identifier of the box to return
     * @param type
     * @param options Optional `round` to read the box as of the end of a past round (defaults to the client's pinned round, if any)
     * @returns The current box value as a byte array
     * @example
     * ```typescript
     * const boxValue = await appClient.getBoxValueFromABIType('boxName', new ABIUintType(32))
     * ```
     */
    getBoxValueFromABIType(name: BoxIdentifier, type: ABIType, options?: AtRoundOptions): Promise<ABIValue>;
    /**
     * Returns the values of all current boxes for the current app.
     * Note: This will issue multiple HTTP requests (one per box) and it's not an atomic operation so values may be out of sync.
     * @param filter Optional filter to filter which boxes' values are returned
     * @param options Optional `round` to read the boxes as of the end of a past round (defaults to the client's pinned round, if any)
     * @returns The (name, value) pair of the boxes with values as raw byte arrays
     * @example
     * ```typescript
     * const boxValues = await appClient.getBoxValues()
     * ```
     */
    getBoxValues(filter?: (name: BoxName) => boolean, options?: AtRoundOptions): Promise<{
        name: BoxName;
        value: Uint8Array;
    }[]>;
    /**
     * Returns the values of all current boxes for the current app decoded using an ABI Type.
     * Note: This will issue multiple HTTP requests (one per box) and it's not an atomic operation so values may be out of sync.
     * @param type The ABI type to decode the values with
     * @param filter Optional filter to filter which boxes' values are returned
     * @param options Optional `round` to read the boxes as of the end of a past round (defaults to the client's pinned round, if any)
     * @returns The (name, value) pair of the boxes with values as the ABI Value
     * @example
     * ```typescript
     * const boxValues = await appClient.getBoxValuesFromABIType(new ABIUintType(32))
     * ```
     */
    getBoxValuesFromABIType(type: ABIType, filter?: (name: BoxName) => boolean, options?: AtRoundOptions): Promise<{
        name: BoxName;
        value: ABIValue;
    }[]>;
    /**
     * Takes an error that may include a logic error from a call to the current app and re-exposes the
     * error to include source code information via the source map and ARC-56 spec.
     * @param e The error to parse
     * @param isClearStateProgram Whether or not the code was running the clear state program (defaults to approval program)
     * @returns The new error, or if there was no logic error or source map then the wrapped error with source details
     */
    exposeLogicError(e: Error, isClearStateProgram?: boolean): Promise<Error>;
    /**
     * Export the current source maps for the app.
     * @returns The source maps
     */
    exportSourceMaps(): AppSourceMaps;
    /**
     * Import source maps for the app.
     * @param sourceMaps The source maps to import
     */
    importSourceMaps(sourceMaps: AppSourceMaps): void;
    /**
     * Returns the ABI Method spec for the given method string for the app represented by this application client instance
     * @param methodNameOrSignature The method name or method signature to call if an ABI call is being emitted.
     * e.g. `my_method` or `my_method(unit64,string)bytes`
     * @returns A tuple with: [ARC-56 `Method`, algosdk `ABIMethod`]
     */
    getABIMethod(methodNameOrSignature: string): Arc56Method;
    /**
     * Checks for decode errors on the SendAppTransactionResult and maps the return value to the specified type
     * on the ARC-56 method, replacing the `return` property with the decoded type.
     *
     * If the return type is an ARC-56 struct then the struct will be returned.
     *
     * @param result The SendAppTransactionResult to be mapped
     * @param method The method that was called
     * @returns The smart contract response with an updated return value
     */
    processMethodCallReturn<TReturn extends Uint8Array | ABIValue | ABIStruct | undefined, TResult extends SendAppTransactionResult = SendAppTransactionResult>(result: Promise<TResult> | TResult, method: Arc56Method): Promise<Omit<TResult, 'return'> & AppReturn<TReturn>>;
    /**
     * Compiles the approval and clear state programs (if TEAL templates provided),
     * performing any provided deploy-time parameter replacement and stores
     * the source maps.
     *
     * If no TEAL templates provided it will use any byte code provided in the app spec.
     *
     * Will store any generated source maps for later use in debugging.
     * @param compilation Any compilation parameters to use
     * @returns The compiled code and any compilation results (including source maps)
     */
    compile(compilation?: AppClientCompilationParams): Promise<AppClientCompilationResult>;
    /**
     * Takes an error that may include a logic error from a call to the current app and re-exposes the
     * error to include source code information via the source map and ARC-56 spec.
     * @param e The error to parse
     * @param appSpec The app spec for the app
     * @param details Additional information to inform the error
     * @returns The new error, or if there was no logic error or source map then the wrapped error with source details
     */
    static exposeLogicError(e: Error, appSpec: Arc56Contract, details: {
        /** Whether or not the code was running the clear state program (defaults to approval program) */ isClearStateProgram?: boolean;
        /** Approval program source map */ approvalSourceMap?: SourceMap;
        /** Clear state program source map */ clearSourceMap?: SourceMap;
        /** program bytes */ program?: Uint8Array;
        /** ARC56 approval source info */ approvalSourceInfo?: ProgramSourceInfo;
        /** ARC56 clear source info */ clearSourceInfo?: ProgramSourceInfo;
    }): Error;
    /**
     * Compiles the approval and clear state programs (if TEAL templates provided),
     * performing any provided deploy-time parameter replacement and returns
     * the compiled code and any compilation results (including source maps).
     *
     * If no TEAL templates provided it will use any byte code provided in the app spec.
     *
     * Will store any generated source maps for later use in debugging.
     * @param appSpec The app spec for the app
     * @param appManager The app manager to use for compilation
     * @param compilation Any compilation parameters to use
     * @returns The compiled code and any compilation results (including source maps)
     */
    static compile(appSpec: Arc56Contract, appManager: AppManager, compilation?: AppClientCompilationParams): Promise<AppClientCompilationResult>;
    /**
     * Returns ABI method arguments ready for a method call params object with default values populated
     * and structs replaced with tuples.
     *
     * It does this by replacing any `undefined` values with the equivalent default value from the given ARC-56 app spec.
     * @param methodNameOrSignature The method name or method signature to call if an ABI call is being emitted.
     * e.g. `my_method` or `my_method(unit64,string)bytes`
     * @param args The arguments to the method with `undefined` for any that should be populated with a default value
     */
    private getABIArgsWithDefaultValues;
    private getBareParamsMethods;
    private getBareCreateTransactionMethods;
    private getBareSendMethods;
    private getMethodCallParamsMethods;
    private getMethodCallSendMethods;
    private getMethodCallCreateTransactionMethods;
    /** Returns the sender for a call, using the provided sender or using the `defaultSender`
     * if none provided and throws an error if neither provided */
    private getSender;
    /** Returns the signer for a call, using the provided signer or the `defaultSigner`
     * if no signer was provided and the sender resolves to the default sender, the call will use default signer
     * or `undefined` otherwise (so the signer is resolved from `AlgorandClient`) */
    private getSigner;
    private getBareParams;
    private getABIParams;
    /** Make the given call and catch any errors, augmenting with debugging information before re-throwing. */
    private handleCallErrors;
    private getBoxMethods;
    private getStateMethods;
}
/**
 * @deprecated Use `AppClient` instead e.g. via `algorand.client.getAppClientById` or
 * `algorand.client.getAppClientByCreatorAndName`.
 * If you want to `create` or `deploy` then use `AppFactory` e.g. via `algorand.client.getAppFactory`,
 * which will in turn give you an `AppClient` instance against the created/deployed app to make other calls.
 *
 * Application client - a class that wraps an ARC-0032 app spec and provides high productivity methods to deploy and call the app */
export declare class ApplicationClient {
    private algod;
    private indexer?;
    private appSpec;
    private sender;
    private params;
    private existingDeployments;
    private deployTimeParams?;
    private _appId;
    private _appAddress;
    private _creator;
    private _appName;
    private _approvalSourceMap;
    private _clearSourceMap;
    /**
     * @deprecated Use `AppClient` instead e.g. via `algorand.client.getAppClientById` or
     * `algorand.client.getAppClientByCreatorAndName`.
     * If you want to `create` or `deploy` then use `AppFactory` e.g. via `algorand.client.getAppFactory`,
     * which will in turn give you an `AppClient` instance against the created/deployed app to make other calls.
     *
     * Create a new ApplicationClient instance
     * @param appDetails The details of the app
     * @param algod An algod instance
     */
    constructor(appDetails: AppSpecAppDetails, algod: Algodv2);
    /**
     * @deprecated Use `AppClient.compile()` instead.
     *
     * Compiles the approval and clear state programs and sets up the source map.
     * @param compilation The deploy-time parameters for the compilation
     * @returns The compiled approval and clear state programs
     */
    compile(compilation?: AppClientCompilationParams): Promise<{
        approvalCompiled: import("./app").CompiledTeal;
        clearCompiled: import("./app").CompiledTeal;
    }>;
    /**
     * Export the current source maps for the app.
     * @returns The source maps
     */
    exportSourceMaps(): AppSourceMaps;
    /**
     * Import source maps for the app.
     * @param sourceMaps The source maps to import
     */
    importSourceMaps(sourceMaps: AppSourceMaps): void;
    /**
     * @deprecated Use `deploy` from an `AppFactory` instance instead.
     *
     * Idempotently deploy (create, update/delete if changed) an app against the given name via the given creator account, including deploy-time template placeholder substitutions.
     *
     * To understand the architecture decisions behind this functionality please see https://github.com/algorandfoundation/algokit-cli/blob/main/docs/src/content/docs/architecture-decisions/2023-01-12_smart-contract-deployment.md
     *
     * **Note:** if there is a breaking state schema change to an existing app (and `onSchemaBreak` is set to `'replace'`) the existing app will be deleted and re-created.
     *
     * **Note:** if there is an update (different TEAL code) to an existing app (and `onUpdate` is set to `'replace'`) the existing app will be deleted and re-created.
     * @param deploy Deployment details
     * @returns The metadata and transaction result(s) of the deployment, or just the metadata if it didn't need to issue transactions
     */
    deploy(deploy?: AppClientDeployParams): Promise<(Partial<AppCompilationResult> & AppMetadata & {
        operationPerformed: "nothing";
    }) | {
        compiledApproval: import("./app").CompiledTeal;
        compiledClear: import("./app").CompiledTeal;
        confirmation: algosdk.modelsv2.PendingTransactionResponse;
        confirmations: algosdk.modelsv2.PendingTransactionResponse[];
        transaction: algosdk.Transaction;
        transactions: algosdk.Transaction[];
        createdRound: number;
        updatedRound: number;
        createdMetadata: import("./app").AppDeployMetadata;
        deleted: boolean;
        appId: number | bigint;
        appAddress: string;
        name: string;
        version: string;
        deletable?: boolean;
        updatable?: boolean;
        return?: ABIReturn;
        operationPerformed: "create" | "update";
    } | {
        compiledApproval: import("./app").CompiledTeal;
        compiledClear: import("./app").CompiledTeal;
        confirmation: algosdk.modelsv2.PendingTransactionResponse;
        confirmations: algosdk.modelsv2.PendingTransactionResponse[];
        transaction: algosdk.Transaction;
        transactions: algosdk.Transaction[];
        createdRound: number;
        updatedRound: number;
        createdMetadata: import("./app").AppDeployMetadata;
        deleted: boolean;
        appId: number | bigint;
        appAddress: string;
        name: string;
        version: string;
        deletable?: boolean;
        updatable?: boolean;
        return?: ABIReturn;
        deleteReturn?: ABIReturn;
        deleteResult: import("./transaction").ConfirmedTransactionResult;
        operationPerformed: "replace";
    }>;
    /**
     * @deprecated Use `create` from an `AppFactory` instance instead.
     *
     * Creates a smart contract app, returns the details of the created app.
     * @param create The parameters to create the app with
     * @returns The details of the created app, or the transaction to create it if `skipSending` and the compilation result
     */
    create(create?: AppClientCreateParams): Promise<{
        compiledApproval: import("./app").CompiledTeal;
        compiledClear: import("./app").CompiledTeal;
        return?: ABIReturn | undefined;
        transactions: algosdk.Transaction[];
        confirmations?: algosdk.modelsv2.PendingTransactionResponse[];
        transaction: algosdk.Transaction;
        confirmation?: algosdk.modelsv2.PendingTransactionResponse;
        appId: number | bigint;
        appAddress: string;
    }>;
    /**
     * @deprecated Use `appClient.send.update` or `appClient.createTransaction.update` from an `AppClient` instance instead.
     *
     * Updates the smart contract app.
     * @param update The parameters to update the app with
     * @returns The transaction send result and the compilation result
     */
    update(update?: AppClientUpdateParams): Promise<{
        compiledApproval: import("./app").CompiledTeal;
        compiledClear: import("./app").CompiledTeal;
        return?: ABIReturn | undefined;
        transactions: algosdk.Transaction[];
        confirmations?: algosdk.modelsv2.PendingTransactionResponse[];
        transaction: algosdk.Transaction;
        confirmation?: algosdk.modelsv2.PendingTransactionResponse;
    }>;
    /**
     * @deprecated Use `appClient.send.call` or `appClient.createTransaction.call` from an `AppClient` instance instead.
     *
     * Issues a no_op (normal) call to the app.
     * @param call The call details.
     * @returns The result of the call
     */
    call(call?: AppClientCallParams): Promise<AppCallTransactionResult>;
    /**
     * @deprecated Use `appClient.send.optIn` or `appClient.createTransaction.optIn` from an `AppClient` instance instead.
     *
     * Issues a opt_in call to the app.
     * @param call The call details.
     * @returns The result of the call
     */
    optIn(call?: AppClientCallParams): Promise<AppCallTransactionResult>;
    /**
     * @deprecated Use `appClient.send.closeOut` or `appClient.createTransaction.closeOut` from an `AppClient` instance instead.
     *
     * Issues a close_out call to the app.
     * @param call The call details.
     * @returns The result of the call
     */
    closeOut(call?: AppClientCallParams): Promise<AppCallTransactionResult>;
    /**
     * @deprecated Use `appClient.send.clearState` or `appClient.createTransaction.clearState` from an `AppClient` instance instead.
     *
     * Issues a clear_state call to the app.
     * @param call The call details.
     * @returns The result of the call
     */
    clearState(call?: AppClientClearStateParams): Promise<AppCallTransactionResult>;
    /**
     * @deprecated Use `appClient.send.delete` or `appClient.createTransaction.delete` from an `AppClient` instance instead.
     *
     * Issues a delete_application call to the app.
     * @param call The call details.
     * @returns The result of the call
     */
    delete(call?: AppClientCallParams): Promise<AppCallTransactionResult>;
    /**
     * @deprecated Use `appClient.send.call` or `appClient.createTransaction.call` from an `AppClient` instance instead.
     *
     * Issues a call to the app with the given call type.
     * @param call The call details.
     * @param callType The call type
     * @returns The result of the call
     */
    callOfType(call: AppClientCallParams | undefined, callType: Exclude<AppCallType, 'update_application'> | Exclude<OnApplicationComplete, OnApplicationComplete.UpdateApplicationOC>): Promise<AppCallTransactionResult>;
    /**
     * Funds Algo into the app account for this app.
     * @param fund The parameters for the funding or the funding amount
     * @returns The result of the funding
     */
    fundAppAccount(fund: FundAppAccountParams | AlgoAmount): Promise<(import("./transaction").SendTransactionResult | {
        groupId: string;
        txIds: string[];
        returns?: ABIReturn[] | undefined;
        confirmations: algosdk.modelsv2.PendingTransactionResponse[];
        transactions: algosdk.Transaction[];
        confirmation: algosdk.modelsv2.PendingTransactionResponse;
        transaction: algosdk.Transaction;
    }) & {
        transactions: algosdk.Transaction[];
    }>;
    /**
     * Returns global state for the current app.
     * @returns The global state
     */
    getGlobalState(): Promise<AppState>;
    /**
     * Returns local state for the given account / account address.
     * @returns The global state
     */
    getLocalState(account: string | SendTransactionFrom): Promise<AppState>;
    /**
     * Returns the names of all current boxes for the current app.
     * @returns The names of the boxes
     */
    getBoxNames(): Promise<BoxName[]>;
    /**
     * Returns the value of the given box for the current app.
     * @param name The name of the box to return either as a string, binary array or `BoxName`
     * @returns The current box value as a byte array
     */
    getBoxValue(name: BoxName | string | Uint8Array): Promise<Uint8Array>;
    /**
     * Returns the value of the given box for the current app.
     * @param name The name of the box to return either as a string, binary array or `BoxName`
     * @param type
     * @returns The current box value as a byte array
     */
    getBoxValueFromABIType(name: BoxName | string | Uint8Array, type: ABIType): Promise<ABIValue>;
    /**
     * Returns the values of all current boxes for the current app.
     * Note: This will issue multiple HTTP requests (one per box) and it's not an atomic operation so values may be out of sync.
     * @param filter Optional filter to filter which boxes' values are returned
     * @returns The (name, value) pair of the boxes with values as raw byte arrays
     */
    getBoxValues(filter?: (name: BoxName) => boolean): Promise<{
        name: BoxName;
        value: Uint8Array;
    }[]>;
    /**
     * Returns the values of all current boxes for the current app decoded using an ABI Type.
     * Note: This will issue multiple HTTP requests (one per box) and it's not an atomic operation so values may be out of sync.
     * @param type The ABI type to decode the values with
     * @param filter Optional filter to filter which boxes' values are returned
     * @returns The (name, value) pair of the boxes with values as the ABI Value
     */
    getBoxValuesFromABIType(type: ABIType, filter?: (name: BoxName) => boolean): Promise<{
        name: BoxName;
        value: ABIValue;
    }[]>;
    /**
     * @deprecated Use `appClient.params.*` from an `AppClient` instance instead.
     *
     * Returns the arguments for an app call for the given ABI method or raw method specification.
     * @param args The call args specific to this application client
     * @param sender The sender of this call. Will be used to fetch any default argument values if applicable
     * @returns The call args ready to pass into an app call
     */
    getCallArgs(args: AppClientCallArgs | undefined, sender: SendTransactionFrom): Promise<AppCallArgs | undefined>;
    /**
     * @deprecated Use `appClient.getABIMethod` instead.
     *
     * Returns the ABI Method parameters for the given method name string for the app represented by this application client instance
     * @param method Either the name of the method or the ABI method spec definition string
     * @returns The ABI method params for the given method
     */
    getABIMethodParams(method: string): ABIMethodParams | undefined;
    /**
     * Returns the ABI Method for the given method name string for the app represented by this application client instance
     * @param method Either the name of the method or the ABI method spec definition string
     * @returns The ABI method for the given method
     */
    getABIMethod(method: string): ABIMethod | undefined;
    /**
     * @deprecated Use `appClient.appId` and `appClient.appAddress` from an `AppClient` instance instead.
     *
     * Gets the reference information for the current application instance.
     * `appId` will be 0 if it can't find an app.
     * @returns The app reference, or if deployed using the `deploy` method, the app metadata too
     */
    getAppReference(): Promise<AppMetadata | AppReference>;
    /**
     * Takes an error that may include a logic error from a smart contract call and re-exposes the error to include source code information via the source map.
     * This is automatically used within `ApplicationClient` but if you pass `skipSending: true` e.g. if doing a group transaction
     *  then you can use this in a try/catch block to get better debugging information.
     * @param e The error to parse
     * @param isClear Whether or not the code was running the clear state program
     * @returns The new error, or if there was no logic error or source map then the wrapped error with source details
     */
    exposeLogicError(e: Error, isClear?: boolean): Error;
    private getABIMethodSignature;
}
