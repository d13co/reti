/** General purpose logger type, compatible with Winston and others. */
export type Logger = {
    error(message: string, ...optionalParams: unknown[]): void;
    warn(message: string, ...optionalParams: unknown[]): void;
    info(message: string, ...optionalParams: unknown[]): void;
    verbose(message: string, ...optionalParams: unknown[]): void;
    debug(message: string, ...optionalParams: unknown[]): void;
};
/** A logger implementation that writes to console */
export declare const consoleLogger: Logger;
export declare const infoConsoleLogger: Logger;
export declare const verboseConsoleLogger: Logger;
export declare const warningConsoleLogger: Logger;
/** A logger implementation that does nothing */
export declare const nullLogger: Logger;
