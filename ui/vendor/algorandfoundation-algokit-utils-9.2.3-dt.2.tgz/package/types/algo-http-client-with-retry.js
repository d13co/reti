Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_config = require("../config.js");
let algosdk = require("algosdk");
let algosdk_client = require("algosdk/client");
//#region src/types/algo-http-client-with-retry.ts
/** A HTTP Client that wraps the Algorand SDK HTTP Client with retries */
var AlgoHttpClientWithRetry = class AlgoHttpClientWithRetry extends algosdk_client.URLTokenBaseHTTPClient {
	static MAX_TRIES = 5;
	static MAX_BACKOFF_MS = 1e4;
	static RETRY_STATUS_CODES = [
		408,
		413,
		429,
		500,
		502,
		503,
		504
	];
	static RETRY_ERROR_CODES = [
		"ETIMEDOUT",
		"ECONNRESET",
		"EADDRINUSE",
		"ECONNREFUSED",
		"EPIPE",
		"ENOTFOUND",
		"ENETUNREACH",
		"EAI_AGAIN",
		"EPROTO"
	];
	/** The abort signal in fetch options passed as `customOptions`, if any. */
	static signalOf(customOptions) {
		const signal = customOptions?.signal;
		return signal && typeof signal === "object" && "aborted" in signal ? signal : void 0;
	}
	/** Waits `ms`, rejecting with the signal's reason as soon as it aborts. */
	static sleep(ms, signal) {
		return new Promise((resolve, reject) => {
			if (signal?.aborted) return reject(signal.reason);
			const onAbort = () => {
				clearTimeout(timer);
				reject(signal.reason);
			};
			const timer = setTimeout(() => {
				signal?.removeEventListener("abort", onAbort);
				resolve();
			}, ms);
			signal?.addEventListener("abort", onAbort, { once: true });
		});
	}
	async callWithRetry(func, signal) {
		let response;
		let numTries = 1;
		do {
			signal?.throwIfAborted();
			try {
				response = await func();
			} catch (err) {
				if (signal?.aborted) throw err;
				if (numTries >= AlgoHttpClientWithRetry.MAX_TRIES) throw err;
				if (!(AlgoHttpClientWithRetry.RETRY_ERROR_CODES.includes(err.code) || AlgoHttpClientWithRetry.RETRY_STATUS_CODES.includes(Number(err.status)) || "response" in err && AlgoHttpClientWithRetry.RETRY_STATUS_CODES.includes(Number(err.response.status)))) throw err;
				const delayTimeMs = numTries == 1 ? 0 : Math.min(1e3 * Math.pow(2, numTries - 1), AlgoHttpClientWithRetry.MAX_BACKOFF_MS);
				if (delayTimeMs > 0) await AlgoHttpClientWithRetry.sleep(delayTimeMs, signal);
				require_config.Config.logger.warn(`algosdk request failed ${numTries} times. Retrying in ${delayTimeMs}ms: ${err}`);
			}
		} while (!response && ++numTries <= AlgoHttpClientWithRetry.MAX_TRIES);
		return response;
	}
	async get(relativePath, query, requestHeaders = {}, customOptions) {
		const response = await this.callWithRetry(() => super.get(relativePath, query, requestHeaders, customOptions), AlgoHttpClientWithRetry.signalOf(customOptions));
		if (relativePath.startsWith("/v2/accounts/") && relativePath.endsWith("/created-applications") && response.status === 200 && query?.["include-all"]?.toString() === "true") try {
			const json = (0, algosdk.parseJSON)(Buffer.from(response.body).toString(), { intDecoding: algosdk.IntDecoding.MIXED });
			if (json.applications) {
				for (const app of json.applications) if (app.params) {
					if (app.params["approval-program"] === null) app.params["approval-program"] = "";
					if (app.params["clear-state-program"] === null) app.params["clear-state-program"] = "";
				}
				response.body = Buffer.from((0, algosdk.stringifyJSON)(json));
			}
		} catch (e) {
			require_config.Config.logger.warn("Failed to fix indexer response for created applications", e);
		}
		return response;
	}
	async post(relativePath, data, query, requestHeaders = {}, customOptions) {
		return await this.callWithRetry(() => super.post(relativePath, data, query, requestHeaders, customOptions), AlgoHttpClientWithRetry.signalOf(customOptions));
	}
	async delete(relativePath, data, query, requestHeaders = {}, customOptions) {
		return await this.callWithRetry(() => super.delete(relativePath, data, query, requestHeaders, customOptions), AlgoHttpClientWithRetry.signalOf(customOptions));
	}
};
//#endregion
exports.AlgoHttpClientWithRetry = AlgoHttpClientWithRetry;

//# sourceMappingURL=algo-http-client-with-retry.js.map