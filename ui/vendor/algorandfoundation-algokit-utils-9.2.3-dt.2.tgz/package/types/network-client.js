Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
//#region src/types/network-client.ts
/**
* Returns true if the given network genesisId is associated with a LocalNet network.
* @param genesisId The network genesis ID
* @returns Whether the given genesis ID is associated with a LocalNet network
*/
function genesisIdIsLocalNet(genesisId) {
	return genesisId === "devnet-v1" || genesisId === "sandnet-v1" || genesisId === "dockernet-v1";
}
//#endregion
exports.genesisIdIsLocalNet = genesisIdIsLocalNet;

//# sourceMappingURL=network-client.js.map