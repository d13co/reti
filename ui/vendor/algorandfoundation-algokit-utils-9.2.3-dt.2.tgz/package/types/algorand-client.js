Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_app_manager = require("./app-manager.js");
const require_composer = require("./composer.js");
const require_algorand_client_transaction_creator = require("./algorand-client-transaction-creator.js");
const require_algorand_client_transaction_sender = require("./algorand-client-transaction-sender.js");
const require_asset_manager = require("./asset-manager.js");
const require_app_deployer = require("./app-deployer.js");
const require_client_manager = require("./client-manager.js");
const require_account_manager = require("./account-manager.js");
const require_simulate_manager = require("./simulate-manager.js");
const require_dt_manager = require("./dt-manager.js");
//#region src/types/algorand-client.ts
/**
* A client that brokers easy access to Algorand functionality.
*/
var AlgorandClient = class AlgorandClient {
	_clientManager;
	_accountManager;
	_appManager;
	_appDeployer;
	_assetManager;
	_transactionSender;
	_transactionCreator;
	_dtManager;
	_simulateManager;
	_cachedSuggestedParams;
	_cachedSuggestedParamsExpiry;
	_cachedSuggestedParamsTimeout = 3e3;
	_defaultValidityWindow = void 0;
	/**
	* A set of error transformers to use when an error is caught in simulate or execute
	* `registerErrorTransformer` and `unregisterErrorTransformer` can be used to add and remove
	* error transformers from the set.
	*/
	_errorTransformers = /* @__PURE__ */ new Set();
	constructor(config) {
		this._clientManager = new require_client_manager.ClientManager(config, this);
		this._accountManager = new require_account_manager.AccountManager(this._clientManager);
		this._appManager = new require_app_manager.AppManager(this._clientManager.algod);
		this._assetManager = new require_asset_manager.AssetManager(this._clientManager.algod, () => this.newGroup());
		this._transactionSender = new require_algorand_client_transaction_sender.AlgorandClientTransactionSender(() => this.newGroup(), this._assetManager, this._appManager);
		this._transactionCreator = new require_algorand_client_transaction_creator.AlgorandClientTransactionCreator(() => this.newGroup());
		this._appDeployer = new require_app_deployer.AppDeployer(this._appManager, this._transactionSender, this._clientManager.indexerIfPresent);
		this._dtManager = new require_dt_manager.DTManager(this._clientManager);
		this._simulateManager = new require_simulate_manager.SimulateManager(this._clientManager);
	}
	/**
	* Sets the default validity window for transactions.
	* @param validityWindow The number of rounds between the first and last valid rounds
	* @returns The `AlgorandClient` so method calls can be chained
	* @example
	* ```typescript
	* const algorand = AlgorandClient.mainNet().setDefaultValidityWindow(1000);
	* ```
	*/
	setDefaultValidityWindow(validityWindow) {
		this._defaultValidityWindow = BigInt(validityWindow);
		return this;
	}
	/**
	* Sets the default signer to use if no other signer is specified.
	* @param signer The signer to use, either a `TransactionSigner` or a `TransactionSignerAccount`
	* @returns The `AlgorandClient` so method calls can be chained
	* @example
	* ```typescript
	* const signer = new SigningAccount(account, account.addr)
	* const algorand = AlgorandClient.mainNet().setDefaultSigner(signer)
	* ```
	*/
	setDefaultSigner(signer) {
		this._accountManager.setDefaultSigner(signer);
		return this;
	}
	/**
	* Tracks the given account (object that encapsulates an address and a signer) for later signing.
	* @param account The account to register, which can be a `TransactionSignerAccount` or
	*  a `algosdk.Account`, `algosdk.LogicSigAccount`, `SigningAccount` or `MultisigAccount`
	* @example
	* ```typescript
	* const accountManager = AlgorandClient.mainNet()
	*  .setSignerFromAccount(algosdk.generateAccount())
	*  .setSignerFromAccount(new algosdk.LogicSigAccount(program, args))
	*  .setSignerFromAccount(new SigningAccount(account, sender))
	*  .setSignerFromAccount(new MultisigAccount({version: 1, threshold: 1, addrs: ["ADDRESS1...", "ADDRESS2..."]}, [account1, account2]))
	*  .setSignerFromAccount({addr: "SENDERADDRESS", signer: transactionSigner})
	* ```
	* @returns The `AlgorandClient` so method calls can be chained
	*/
	setSignerFromAccount(account) {
		this._accountManager.setSignerFromAccount(account);
		return this;
	}
	/**
	* Tracks the given signer against the given sender for later signing.
	* @param sender The sender address to use this signer for
	* @param signer The signer to sign transactions with for the given sender
	* @returns The `AlgorandClient` so method calls can be chained
	* @example
	* ```typescript
	* const signer = new SigningAccount(account, account.addr)
	* const algorand = AlgorandClient.mainNet().setSigner(signer.addr, signer.signer)
	* ```
	*/
	setSigner(sender, signer) {
		this._accountManager.setSigner(sender, signer);
		return this;
	}
	/**
	* Sets a cache value to use for suggested transaction params.
	* @param suggestedParams The suggested params to use
	* @param until A date until which to cache, or if not specified then the timeout is used
	* @returns The `AlgorandClient` so method calls can be chained
	* @example
	* ```typescript
	* const algorand = AlgorandClient.mainNet().setSuggestedParamsCache(suggestedParams, new Date(+new Date() + 3_600_000))
	* ```
	*/
	setSuggestedParamsCache(suggestedParams, until) {
		this._cachedSuggestedParams = suggestedParams;
		this._cachedSuggestedParamsExpiry = until ?? new Date(+/* @__PURE__ */ new Date() + this._cachedSuggestedParamsTimeout);
		return this;
	}
	/**
	* Sets the timeout for caching suggested params.
	* @param timeout The timeout in milliseconds
	* @returns The `AlgorandClient` so method calls can be chained
	* @example
	* ```typescript
	* const algorand = AlgorandClient.mainNet().setSuggestedParamsCacheTimeout(10_000)
	* ```
	*/
	setSuggestedParamsCacheTimeout(timeout) {
		this._cachedSuggestedParamsTimeout = timeout;
		return this;
	}
	/**
	* Get suggested params for a transaction (either cached or from algod if the cache is stale or empty)
	* @returns The suggested transaction parameters.
	* @example
	* const params = await AlgorandClient.mainNet().getSuggestedParams();
	*/
	async getSuggestedParams() {
		if (this._cachedSuggestedParams && (!this._cachedSuggestedParamsExpiry || this._cachedSuggestedParamsExpiry > /* @__PURE__ */ new Date())) return { ...this._cachedSuggestedParams };
		this._cachedSuggestedParams = await this._clientManager.algod.getTransactionParams().do();
		this._cachedSuggestedParamsExpiry = new Date((/* @__PURE__ */ new Date()).getTime() + this._cachedSuggestedParamsTimeout);
		return { ...this._cachedSuggestedParams };
	}
	/**
	* Get clients, including algosdk clients and app clients.
	* @returns The `ClientManager` instance.
	* @example
	* const clientManager = AlgorandClient.mainNet().client;
	*/
	get client() {
		return this._clientManager;
	}
	/**
	* Get or create accounts that can sign transactions.
	* @returns The `AccountManager` instance.
	* @example
	* const accountManager = AlgorandClient.mainNet().account;
	*/
	get account() {
		return this._accountManager;
	}
	/**
	* Methods for interacting with assets.
	* @returns The `AssetManager` instance.
	* @example
	* const assetManager = AlgorandClient.mainNet().asset;
	*/
	get asset() {
		return this._assetManager;
	}
	/**
	* Methods for interacting with apps.
	* @returns The `AppManager` instance.
	* @example
	* const appManager = AlgorandClient.mainNet().app;
	*/
	get app() {
		return this._appManager;
	}
	/**
	* Methods for deploying apps and managing app deployment metadata.
	* @returns The `AppDeployer` instance.
	* @example
	* const deployer = AlgorandClient.mainNet().appDeployer;
	*/
	get appDeployer() {
		return this._appDeployer;
	}
	/**
	* Time travel on dtalgod (a time-travel algod): the rounds at which boxes, apps, assets and accounts changed.
	*
	* To read state at a past round, pass `{ round }` to the usual reads, or use `appClient.atRound(round)`.
	* Needs the time-travel fork of algosdk.
	* @returns The `DTManager` instance.
	* @example
	* const { versions } = await algorand.dt.getBoxVersions(appId, 'counter', { includeValues: true });
	*/
	get dt() {
		return this._dtManager;
	}
	/**
	* Extended simulate on dtalgod: several transaction groups per request, and the same groups at several rounds.
	* Needs the time-travel fork of algosdk.
	* @returns The `SimulateManager` instance.
	* @example
	* const outcomes = await algorand.simulate.rounds(composer, [45_000_000n, 45_001_000n]);
	*/
	get simulate() {
		return this._simulateManager;
	}
	/**
	* Register a function that will be used to transform an error caught when simulating or executing
	* composed transaction groups made from `newGroup`
	*/
	registerErrorTransformer(transformer) {
		this._errorTransformers.add(transformer);
	}
	unregisterErrorTransformer(transformer) {
		this._errorTransformers.delete(transformer);
	}
	/** Start a new `TransactionComposer` transaction group
	* @returns A new instance of `TransactionComposer`.
	* @example
	* const composer = AlgorandClient.mainNet().newGroup();
	* const result = await composer.addTransaction(payment).send()
	*/
	newGroup() {
		return new require_composer.TransactionComposer({
			algod: this.client.algod,
			getSigner: (addr) => this.account.getSigner(addr),
			getSuggestedParams: () => this.getSuggestedParams(),
			defaultValidityWindow: this._defaultValidityWindow,
			appManager: this._appManager,
			errorTransformers: [...this._errorTransformers]
		});
	}
	/**
	* Methods for sending a transaction.
	* @returns The `AlgorandClientTransactionSender` instance.
	* @example
	* const result = await AlgorandClient.mainNet().send.payment({
	*  sender: "SENDERADDRESS",
	*  receiver: "RECEIVERADDRESS",
	*  amount: algo(1)
	* })
	*/
	get send() {
		return this._transactionSender;
	}
	/**
	* Methods for creating a transaction.
	* @returns The `AlgorandClientTransactionCreator` instance.
	* @example
	* const payment = await AlgorandClient.mainNet().createTransaction.payment({
	*  sender: "SENDERADDRESS",
	*  receiver: "RECEIVERADDRESS",
	*  amount: algo(1)
	* })
	*/
	get createTransaction() {
		return this._transactionCreator;
	}
	/**
	* Creates an `AlgorandClient` pointing at default LocalNet ports and API token.
	* @returns An instance of the `AlgorandClient`.
	* @example
	* const algorand = AlgorandClient.defaultLocalNet();
	*/
	static defaultLocalNet() {
		return new AlgorandClient({
			algodConfig: require_client_manager.ClientManager.getDefaultLocalNetConfig("algod"),
			indexerConfig: require_client_manager.ClientManager.getDefaultLocalNetConfig("indexer"),
			kmdConfig: require_client_manager.ClientManager.getDefaultLocalNetConfig("kmd")
		});
	}
	/**
	* Creates an `AlgorandClient` pointing at TestNet using AlgoNode.
	* @returns An instance of the `AlgorandClient`.
	* @example
	* const algorand = AlgorandClient.testNet();
	*/
	static testNet() {
		return new AlgorandClient({
			algodConfig: require_client_manager.ClientManager.getAlgoNodeConfig("testnet", "algod"),
			indexerConfig: require_client_manager.ClientManager.getAlgoNodeConfig("testnet", "indexer"),
			kmdConfig: void 0
		});
	}
	/**
	* Creates an `AlgorandClient` pointing at MainNet using AlgoNode.
	* @returns An instance of the `AlgorandClient`.
	* @example
	* const algorand = AlgorandClient.mainNet();
	*/
	static mainNet() {
		return new AlgorandClient({
			algodConfig: require_client_manager.ClientManager.getAlgoNodeConfig("mainnet", "algod"),
			indexerConfig: require_client_manager.ClientManager.getAlgoNodeConfig("mainnet", "indexer"),
			kmdConfig: void 0
		});
	}
	/**
	* Creates an `AlgorandClient` pointing to the given client(s).
	* @param clients The clients to use.
	* @returns An instance of the `AlgorandClient`.
	* @example
	* const algorand = AlgorandClient.fromClients({ algod, indexer, kmd });
	*/
	static fromClients(clients) {
		return new AlgorandClient(clients);
	}
	/**
	* Creates an `AlgorandClient` loading the configuration from environment variables.
	*
	* Retrieve configurations from environment variables when defined or get default LocalNet configuration if they aren't defined.
	*
	* Expects to be called from a Node.js environment.
	*
	* If `process.env.ALGOD_SERVER` is defined it will use that along with optional `process.env.ALGOD_PORT` and `process.env.ALGOD_TOKEN`.
	*
	* If `process.env.INDEXER_SERVER` is defined it will use that along with optional `process.env.INDEXER_PORT` and `process.env.INDEXER_TOKEN`.
	*
	* If either aren't defined it will use the default LocalNet config.
	*
	* It will return a KMD configuration that uses `process.env.KMD_PORT` (or port 4002) if `process.env.ALGOD_SERVER` is defined,
	* otherwise it will use the default LocalNet config unless it detects testnet or mainnet.
	* @returns An instance of the `AlgorandClient`.
	* @example
	* const client = AlgorandClient.fromEnvironment();
	*/
	static fromEnvironment() {
		return new AlgorandClient(require_client_manager.ClientManager.getConfigFromEnvironmentOrLocalNet());
	}
	/**
	* Creates  an `AlgorandClient` from the given config.
	* @param config The config to use.
	* @returns An instance of the `AlgorandClient`.
	* @example
	* const client = AlgorandClient.fromConfig({ algodConfig, indexerConfig, kmdConfig });
	*/
	static fromConfig(config) {
		return new AlgorandClient(config);
	}
};
//#endregion
exports.AlgorandClient = AlgorandClient;

//# sourceMappingURL=algorand-client.js.map