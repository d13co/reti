import algosdk from 'algosdk';
import { AssetBulkOptInOutParams, AssetOptInParams, AssetOptOutParams, CreateAssetParams } from './types/asset';
import { SendTransactionResult } from './types/transaction';
import Algodv2 = algosdk.Algodv2;
/**
 * @deprecated use `algorand.send.assetCreate()` / `algorand.createTransaction.assetCreate()` instead
 *
 * Create an Algorand Standard Asset (ASA).
 * @param create The asset creation definition
 * @param algod An algod client
 * @returns The transaction object and optionally the confirmation if it was sent to the chain (`skipSending` is `false` or unset)
 *
 * @example Usage example
 * ```typescript
 * await algokit.createAsset({ creator: account, total: 1, decimals: 0, name: 'My asset' }, algod)
 * ```
 */
export declare function createAsset(create: CreateAssetParams, algod: Algodv2): Promise<SendTransactionResult & {
    confirmation?: {
        assetIndex: number | bigint;
    };
}>;
/**
 * @deprecated use `algorand.send.assetOptIn()` / `algorand.createTransaction.assetOptIn()` instead
 *
 * Opt-in an account to an asset.
 * @param optIn The opt-in definition
 * @param algod An algod client
 * @returns The transaction object and optionally the confirmation if it was sent to the chain (`skipSending` is `false` or unset)
 *
 * @example Usage example
 * ```typescript
 * await algokit.assetOptIn({ account, assetId }, algod)
 * ```
 */
export declare function assetOptIn(optIn: AssetOptInParams, algod: Algodv2): Promise<SendTransactionResult>;
/**
 * @deprecated use `algorand.send.assetOptOut()` / `algorand.createTransaction.assetOptOut()` instead
 *
 * Opt-out an account from an asset.
 * @param optOut The opt-in definition
 * @param algod An algod client
 * @returns The transaction object and optionally the confirmation if it was sent to the chain (`skipSending` is `false` or unset)
 *
 * @example Usage example
 * ```typescript
 * await algokit.assetOptOut({ account, assetId, assetCreatorAddress }, algod)
 * ```
 */
export declare function assetOptOut(optOut: AssetOptOutParams, algod: Algodv2): Promise<SendTransactionResult>;
/**
 * @deprecated use `algorand.asset.bulkOptIn()` instead
 *
 * Opt in to a list of assets on the Algorand blockchain.
 *
 * @param optIn - The bulk opt-in request.
 * @param algod - An instance of the Algodv2 class from the `algosdk` library.
 * @returns A record object where the keys are the asset IDs and the values are the corresponding transaction IDs for successful opt-ins.
 * @throws If there is an error during the opt-in process.
 * @example algokit.bulkOptIn({ account: account, assetIds: [12345, 67890] }, algod)
 */
export declare function assetBulkOptIn(optIn: AssetBulkOptInOutParams, algod: Algodv2): Promise<Record<number, string>>;
/**
 * @deprecated use `algorand.asset.bulkOptOut()` instead
 *
 * Opt out of multiple assets in Algorand blockchain.
 *
 * @param optOut The bulk opt-out request.
 * @param algod - An instance of the Algodv2 client used to interact with the Algorand blockchain.
 * @returns A record object containing asset IDs as keys and their corresponding transaction IDs as values.
 * @throws If there is an error during the opt-out process.
 * @example algokit.bulkOptOut({ account: account, assetIds: [12345, 67890] }, algod)
 */
export declare function assetBulkOptOut(optOut: AssetBulkOptInOutParams, algod: Algodv2): Promise<Record<number, string>>;
