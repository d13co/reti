import { AlgoAmount } from './types/amount';
declare global {
    interface Number {
        /**
         * Returns an `AlgoAmount` using this number of microAlgo.
         */
        microAlgos(this: number): AlgoAmount;
        /**
         * Returns an `AlgoAmount` using this number of Algo.
         */
        algos(this: number): AlgoAmount;
        /**
         * Returns an `AlgoAmount` using this number of microAlgo.
         */
        microAlgo(this: number): AlgoAmount;
        /**
         * Returns an `AlgoAmount` using this number of Algo.
         */
        algo(this: number): AlgoAmount;
    }
    interface BigInt {
        /**
         * Returns an `AlgoAmount` using this number of microAlgo.
         */
        microAlgo(this: bigint): AlgoAmount;
        /**
         * Returns an `AlgoAmount` using this number of Algo.
         */
        algo(this: bigint): AlgoAmount;
    }
}
/** Returns an amount of Algo using AlgoAmount
 * @param algos The amount of Algo
 */
export declare const algos: (algos: number | bigint) => AlgoAmount;
/** Returns an amount of Algo using AlgoAmount
 * @param algos The amount of Algo
 */
export declare const algo: (algos: number | bigint) => AlgoAmount;
/** Returns an amount of µAlgo using AlgoAmount
 * @param microAlgos The amount of µAlgo
 */
export declare const microAlgos: (microAlgos: number | bigint) => AlgoAmount;
/** Returns an amount of µAlgo using AlgoAmount
 * @param microAlgos The amount of µAlgo
 */
export declare const microAlgo: (microAlgos: number | bigint) => AlgoAmount;
/** Returns an amount of µAlgo to cover standard fees for the given number of transactions using AlgoAmount
 * @param numberOfTransactions The of standard transaction fees to return the amount of Algo
 */
export declare const transactionFees: (numberOfTransactions: number) => AlgoAmount;
export declare const ALGORAND_MIN_TX_FEE: AlgoAmount;
