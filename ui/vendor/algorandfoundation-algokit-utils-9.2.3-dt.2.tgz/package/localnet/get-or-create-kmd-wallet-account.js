const require_client_manager = require("../types/client-manager.js");
const require_kmd_account_manager = require("../types/kmd-account-manager.js");
//#region src/localnet/get-or-create-kmd-wallet-account.ts
/**
* @deprecated use `algorand.account.kmd.getOrCreateWalletAccount(name, fundWith)` or `new KMDAccountManager(clientManager).getOrCreateWalletAccount(name, fundWith)` instead.
*
* Gets an account with private key loaded from a KMD wallet of the given name, or alternatively creates one with funds in it via a KMD wallet of the given name.
*
* This is useful to get idempotent accounts from LocalNet without having to specify the private key (which will change when resetting the LocalNet).
*
* This significantly speeds up local dev time and improves experience since you can write code that *just works* first go without manual config in a fresh LocalNet.
*
* If this is used via `mnemonicAccountFromEnvironment`, then you can even use the same code that runs on production without changes for local development!
*
* @param walletAccount The wallet details with:
*   * `name`: The name of the wallet to retrieve / create
*   * `fundWith`: The number of Algo to fund the account with when it gets created, if not specified then 1000 ALGO will be funded from the dispenser account
* @param algod An algod client
* @param kmdClient A KMD client, if not specified then a default KMD client will be loaded from environment variables
*
* @returns An Algorand account with private key loaded - either one that already existed in the given KMD wallet, or a new one that is funded for you
*/
async function getOrCreateKmdWalletAccount(walletAccount, algod, kmdClient) {
	return (await new require_kmd_account_manager.KmdAccountManager(new require_client_manager.ClientManager({
		algod,
		kmd: kmdClient
	})).getOrCreateWalletAccount(walletAccount.name, walletAccount.fundWith)).account;
}
//#endregion
exports.getOrCreateKmdWalletAccount = getOrCreateKmdWalletAccount;

//# sourceMappingURL=get-or-create-kmd-wallet-account.js.map