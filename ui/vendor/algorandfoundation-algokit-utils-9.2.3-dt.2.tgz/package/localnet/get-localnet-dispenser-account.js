const require_client_manager = require("../types/client-manager.js");
const require_account_manager = require("../types/account-manager.js");
//#region src/localnet/get-localnet-dispenser-account.ts
/**
* @deprecated Use `algorand.account.kmd.getLocalNetDispenserAccount()` instead.
*
* Returns an Algorand account with private key loaded for the default LocalNet dispenser account (that can be used to fund other accounts)
*
* @param algod An algod client
* @param kmd A KMD client, if not specified then a default KMD client will be loaded from environment variables
*/
async function getLocalNetDispenserAccount(algod, kmd) {
	return (await new require_account_manager.AccountManager(new require_client_manager.ClientManager({
		algod,
		kmd
	})).kmd.getLocalNetDispenserAccount()).account;
}
//#endregion
exports.getLocalNetDispenserAccount = getLocalNetDispenserAccount;

//# sourceMappingURL=get-localnet-dispenser-account.js.map